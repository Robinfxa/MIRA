import type { AudioProgressRequest, CreateSessionResponse, EffectView, InputRequest, MicrophoneComplete, MicrophoneStart, ReceiptRequest, ReviewedAudioStatusResponse, SessionView, StopRequest } from '../../shared/generated/contracts.js';
import type { CapturedAudio } from '../audio/types.js';

export type { VoiceCapabilities } from '../../shared/generated/contracts.js';
import type { VoiceCapabilities } from '../../shared/generated/contracts.js';
export type MicrophoneOrigin = Pick<MicrophoneStart, 'stream_id' | 'activity_seq' | 'input_epoch'>;
export type FinalTranscript = Pick<MicrophoneComplete, 'text' | 'had_final'>;
export interface MicrophoneTranscriptRevision {
  readonly stream_id: string;
  readonly revision: number;
  readonly text: string;
  readonly is_final: boolean;
}
/** Per-client monotonic elapsed timings from press-to-talk start; never persisted. */
export interface MicrophoneTimingSnapshot {
  readonly stream_id: string;
  readonly dispatch_ms: number;
  readonly first_revision_ms?: number;
  readonly first_final_revision_ms?: number;
  readonly client_finish_ms?: number;
  readonly stream_close_ms?: number;
  readonly revision_count: number;
  readonly final_revision_count: number;
}
export interface MicrophoneObservers {
  readonly timingOriginMs?: number;
  readonly onRevision?: (revision: MicrophoneTranscriptRevision | null) => void;
  readonly onTiming?: (timing: MicrophoneTimingSnapshot) => void;
}
export interface MicrophoneStream {
  readonly ready: Promise<void>;
  readonly completion: Promise<FinalTranscript>;
  send(chunk: CapturedAudio): void;
  finish(clientFinishAtMs?: number): Promise<FinalTranscript>;
  cancel(): void;
}
/** Session use cases depend on ports, not fetch or a provider SDK. */
export interface SessionTransport {
  create(clientInstanceId: string, signal?: AbortSignal): Promise<CreateSessionResponse>;
  capabilities(signal?: AbortSignal): Promise<VoiceCapabilities>;
  snapshot(signal?: AbortSignal): Promise<SessionView>;
  input(request: InputRequest, signal?: AbortSignal): Promise<SessionView>;
  stop(request: StopRequest, signal?: AbortSignal): Promise<SessionView>;
  receipt(request: ReceiptRequest): Promise<SessionView>;
  audioProgress(request: AudioProgressRequest): Promise<SessionView>;
  reviewedAudioStatus?(signal?: AbortSignal): Promise<ReviewedAudioStatusResponse>;
  speech(effect: EffectView, signal: AbortSignal, onPcm: (pcm: Int16Array) => void | Promise<void>): Promise<void>;
  microphone(origin: MicrophoneOrigin, signal: AbortSignal, observers?: MicrophoneObservers): MicrophoneStream;
  /** Optional for older test/client transports; when available it shares the microphone timer. */
  monotonicNow?(): number;
  close(): Promise<void>;
}
