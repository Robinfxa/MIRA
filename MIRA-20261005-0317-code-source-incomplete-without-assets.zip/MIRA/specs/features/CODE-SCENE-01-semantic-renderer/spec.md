# CODE-SCENE-01 semantic character renderer

Owner: web lane, existing tests/web/*.test.mjs ownership in tests/quality.toml.
Baseline: public source mira-character-integration-next-20261005T0146Z.
Consumers: SceneEffectExecutor, SessionController's existing prepare/gate/apply/receipt boundary.
Resources: local editable semantic face/body code, Canvas2D at 192×320, one animation frame loop. No renderer provider, auth, database, network, or new dependency.

## CODE-SCENE-001 explicit review mode
Given default startup, the existing static renderer is unchanged. Given body data-character-renderer=code-native-review, draw semantic vectors on a 192×320 canvas with nearest-neighbor CSS scaling and a persistent unapproved-art notice. Source pins and readiness catalog describe only actual capabilities.

## CODE-SCENE-002 atomic visible state
Given a permitted effect, prepare an invisible complete candidate, revalidate the existing gate, and synchronously commit the character before DOM facts or receipt. Unsupported camera/face/emotion/accessory states fail visibly; they do not become label-only success. All three drawn outfits are independent of phase and emotion.

## CODE-SCENE-003 lifecycle cancellation
Stop closes the mouth, resets phase/time, invalidates stale frame/preparation callbacks, and preserves displayed wardrobe/media/history. Close destroys resources. Hidden, Pause and reduced-motion changes cancel scheduled frames and invalidate pending work. New phase after Stop can restart only current motion; no whole-canvas CSS animation.

## CODE-SCENE-004 honest capabilities
Readiness distinguishes review_only geometry from unavailable capabilities and unapproved likeness. Four phase channels are not four implemented emotions. Camera clip is drawn; star clip is unavailable. Browser pixels, visual likeness and real audio lip sync remain unverified.


## CODE-SCENE-005 editable connection drafts
Given startup or a failed connection, the text field stays editable, Send and voice actions stay disabled, and explicit status plus Retry explain what can happen. Retry is single-flight, never silently deletes another session, and preserves the draft. Close keeps the draft editable and fences a pending successful callback. Only the API client's fixed safe error text and validated request ID are shown.

## Executable coverage
The existing traceability CLI accepts Python tests only. These Node test mappings are explicit here, not fabricated pytest nodes:
- 001/004: tests/web/code-native-renderer.test.mjs source-pin/catalog/composition checks; tests/web/controller-main.test.mjs composition check.
- 002: code-native-renderer.test.mjs prepare-vs-copy, unsupported state, failed-copy DOM, actual-controller receipt tests.
- 003: code-native-renderer.test.mjs Stop/hidden/reduced-motion/Close and actual uncooperative preparation gate tests.
- 005: controller-main.test.mjs connection failure/retry/Close tests; error-locators.test.mjs real controller/API integration.

All tests remain owned by the existing web wildcard in tests/quality.toml. Backend/config/bootstrap consumers are handled in the integration parent's separate work. Evidence is held outside the source checkout.

## CODE-SCENE-006 explicit software capability composition
Given the review renderer is explicitly selected, the shipped catalogue maps implemented geometry to software readiness with source revision, while unimplemented slots stay unavailable. Static mode does not inherit these new slots. The HTTP marker selects the same renderer as the launcher, and the wheel preserves the nested catalogue and emitted vendor code. `tests/contracts/test_renderer_readiness_bootstrap.py::test_selected_review_renderer_binds_software_readiness_without_art_approval` and `tests/contracts/test_renderer_readiness_bootstrap.py::test_selected_renderer_is_explicit_in_real_http_entry_and_static_catalog` are executable Python coverage under the existing providers wildcard.
