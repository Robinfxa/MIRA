"""Bind the explicitly selected software renderer to its shipped capability map.

READY means implemented geometry in this review mode, not approved likeness or a
presentation. The client still prepares, draws and acknowledges each effect.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

from mira.config.loader import project_root
from mira.domain.story import CapabilityRecord, CapabilityState, ReadinessCatalog


def renderer_readiness(renderer: str, *, web_root: Path | None = None) -> ReadinessCatalog:
    if renderer == 'static-pixi':
        return ReadinessCatalog('mira-character-assets-unregistered-v1')
    if renderer != 'code-native-review':
        raise ValueError('character_renderer_invalid')
    root = web_root if web_root is not None else project_root() / 'apps/web'
    try:
        raw = (root / 'public/scene/code-native/readiness-catalog.json').read_bytes()
        if len(raw) > 32768:
            raise ValueError('size')
        data = json.loads(raw)
        if (type(data['schemaVersion']) is not int or data['schemaVersion'] != 1
                or data['renderer'] != renderer or data['visualAcceptance'] != 'pending'
                or data['likenessApproved'] is not False):
            raise ValueError('schema')
        sources = data['sources']
        if set(sources) != {'face', 'body'}:
            raise ValueError('sources')
        for source in sources.values():
            if not isinstance(source, dict) or not re.fullmatch('[0-9a-f]{64}', source['sha256']):
                raise ValueError('source revision')
        revision = 'code-native-review:' + hashlib.sha256(raw).hexdigest()
        records = []
        assets = data['assets']
        if not isinstance(assets, dict) or not 1 <= len(assets) <= 64:
            raise ValueError('assets')
        for identifier, item in assets.items():
            if not re.fullmatch(r'mira\.(outfit|emotion|accessory|pose|face|phase)\.[a-z_]+', identifier):
                raise ValueError('asset ID')
            if item['status'] not in ('review_only', 'unavailable'):
                raise ValueError('asset status')
            ready = item['status'] == 'review_only'
            parts = ('outer.amber', 'inner.cream') if identifier == 'mira.outfit.amber_raincoat' else (identifier,)
            records.append(CapabilityRecord(identifier,
                CapabilityState.READY if ready else CapabilityState.UNAVAILABLE,
                revision if ready else None, parts if ready else (),
                'software-review:' + hashlib.sha256(raw).hexdigest() if ready else None))
        return ReadinessCatalog(revision, tuple(records))
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        raise ValueError('character_readiness_catalog_invalid') from None
