"""Small single-Actor bridge: reviewed suggestions, compiled grants, real receipts.

No filesystem, provider, HTTP, automatic recording or presentation authority.
The Actor holds its transition lock when mutating this pure coordinator.
"""
from __future__ import annotations

from dataclasses import dataclass,replace
import hashlib
import json
from collections.abc import Awaitable, Callable

from mira.application.contracts import (CandidateRange,EffectProposal,GenerationContext,
    CharacterSemanticEvidence,CharacterSemanticValue as V,ReviewObservation,ReviewVerdict)
from mira.application.decision_contracts import evidence_digest
from mira.application.character_controls import CHARACTER_CAPABILITIES
from mira.application.story import StoryRuntime, RuntimeSnapshot
from mira.domain.models import Effect,EffectKind,Receipt
from mira.domain.errors import DomainError
from mira.domain.story import (AffectState,AffectSignal,CapabilityState,EvidenceLabel,EpisodeCandidate,
    JevEvidence,PresentationReceipt,ReadinessCatalog,ReceiptComponent,ReceiptKind,
    ReceiptRequirement,ResultCode,Relevance,StoryState,StoryTurn,Stop,Will,
    begin_story_input,bind_compiled_effect,parse_story_proposal,parse_affect_proposal,
    affect_turn_from_jev,reduce_affect,reduce_story)

RAINCOAT_CONTROL='outfit_amber_raincoat'


@dataclass(frozen=True,slots=True)
class PreparedCharacterUpdate:
    story: StoryState
    affect: AffectState
    admitted_effects: tuple[Effect, ...]
    control_grants: tuple[tuple[Effect, str], ...]


class SessionCharacterRuntime:
    def __init__(self,runtime:StoryRuntime,readiness:ReadinessCatalog,
                 checkpoint: Callable[[RuntimeSnapshot], Awaitable[None]] | None = None):
        if type(runtime) is not StoryRuntime or type(readiness) is not ReadinessCatalog:
            raise ValueError('character_runtime_invalid')
        self.runtime=runtime
        self.readiness=readiness
        self._checkpoint=checkpoint
        self._definition_digest=evidence_digest(runtime.definition)
        # Receipt reconciliation metadata, never presentation authority. Kept
        # only for this Actor's bounded issued-effect budget, not checkpointed.
        self._control_grants: dict[str, tuple[Effect, str]] = {}
        self._last_presentation_seq: dict[str, int] = {}

    def begin_input(self,input_id:str,epoch:int):
        self.runtime.story=begin_story_input(self.runtime.story,input_id,epoch,self.runtime.definition)
        return self.runtime.project().projection

    def ensure_definition(self,context:GenerationContext):
        projection=context.character_story
        current=self.runtime.project().projection
        if (projection is None or evidence_digest(self.runtime.definition)!=self._definition_digest
                or projection.scope_binding_hash!=current.scope_binding_hash
                or projection.graph_hash!=current.graph_hash
                or projection.canon_revision!=current.canon_revision
                or context.character_assets!=self.readiness
                or context.output_epoch!=self.runtime.story.epoch):
            raise DomainError('review_uncertain','Character context changed; keep this story step pending.')
        # The captured turn-start projection stays identical for generation/review.
        # Causally acknowledged local receipts may advance current state in this turn;
        # they remain separate actual presentation facts, not rewritten old context.

    def _proposal(self,candidate:CandidateRange,input_id:str,epoch:int):
        if candidate.story_proposal_json is None:return None
        try:return parse_story_proposal(json.loads(candidate.story_proposal_json),input_id=input_id,epoch=epoch)
        except (ValueError,TypeError,KeyError):
            raise DomainError('invalid_response','Invalid character suggestion.') from None

    def prepare_candidate(self,context:GenerationContext,candidate:CandidateRange,input_id:str):
        self.ensure_definition(context)
        proposal=self._proposal(candidate,input_id,context.output_epoch)
        wardrobe=tuple(effect for effect in candidate.effects if effect.kind is EffectKind.POSE
                       and effect.value.startswith('outfit_'))
        if proposal is not None and proposal.transition_id=='t.yes':
            record=self.readiness.get('mira.outfit.amber_raincoat')
            if record is None or record.state is not CapabilityState.READY:
                # Still review the text/proposal and let the reducer close an
                # explicitly unavailable invitation. Never compile its outfit.
                candidate=replace(candidate,effects=tuple(effect for effect in candidate.effects
                    if not (effect.kind is EffectKind.POSE and effect.value==RAINCOAT_CONTROL)))
            elif not any(effect.value==RAINCOAT_CONTROL for effect in wardrobe):
                candidate=replace(candidate,effects=candidate.effects+(EffectProposal(EffectKind.POSE,RAINCOAT_CONTROL),))
        if proposal is not None and proposal.transition_id=='t.offer':
            if not proposal.draft_cue or not any(effect.kind is EffectKind.SUBTITLE
                    and effect.value==proposal.draft_cue for effect in candidate.effects):
                raise DomainError('invalid_response','Invitation text does not bind to a subtitle.')
        # A newly named pose is not evidence that either the active renderer or
        # its registered local assets can show it. Remove unsupported optional
        # controls before independent content review; never emit a false receipt.
        candidate=replace(candidate,effects=tuple(effect for effect in candidate.effects
            if not self._is_character_control(effect)
            or self.readiness.state_for(CHARACTER_CAPABILITIES.get(effect.value, '')) is CapabilityState.READY))
        if not candidate.effects:
            raise DomainError('review_uncertain','No available character effect remains.')
        return candidate

    def prepare_accept(self,context:GenerationContext,candidate:CandidateRange,observation:ReviewObservation,
                       effects:tuple[Effect,...],input_id:str)->PreparedCharacterUpdate:
        self.ensure_definition(context)
        if observation.verdict is not ReviewVerdict.ALLOW:
            raise DomainError('review_uncertain', 'Complete output review is required.')
        if (len(effects) != len(candidate.effects)
                or any((effect.kind, effect.value, effect.output_epoch) !=
                       (proposed.kind, proposed.value, context.output_epoch)
                       for effect, proposed in zip(effects, candidate.effects))):
            raise DomainError('invalid_response', 'Compiled effects differ from reviewed effects.')
        evidence=observation.character_evidence
        if (type(evidence) is not CharacterSemanticEvidence
                or evidence.context_digest!=evidence_digest(context)
                or evidence.candidate_digest!=evidence_digest(candidate)):
            evidence=None
        proposal=self._proposal(candidate,input_id,context.output_epoch)
        if proposal is not None and proposal.transition_id!='t.chat' and evidence is None:
            raise DomainError('review_uncertain','The story suggestion is uncertain; keep the current scene.')
        will=Will.UNKNOWN
        if evidence is not None:
            if evidence.refusal is V.YES:will=Will.NO
            elif evidence.willingness is V.YES and evidence.refusal is V.NO:will=Will.YES
        relevance=(Relevance.RELEVANT if evidence and evidence.relevance is V.YES else
                   Relevance.IRRELEVANT if evidence and evidence.relevance is V.NO else Relevance.UNKNOWN)
        jev=JevEvidence(input_id,context.output_epoch,self.runtime.story.active_offer_id,will,relevance,
                        refusal=bool(evidence and evidence.refusal is V.YES))
        reduction=reduce_story(self.runtime.story,StoryTurn(input_id,context.output_epoch,proposal,jev,
            self.readiness,True),self.runtime.definition)
        if proposal is not None and proposal.transition_id!='t.chat' and reduction.effect_plan is None:
            self.runtime.story=reduction.state
            raise DomainError('review_uncertain','The story suggestion is uncertain; keep the current scene.')
        story=reduction.state
        plan=reduction.effect_plan
        if plan is not None:
            if plan.transition_id=='t.offer':
                effect=next((effect for effect in effects if effect.kind is EffectKind.SUBTITLE
                             and effect.value==proposal.draft_cue),None)
                if effect is None:raise DomainError('invalid_response','No compiled invitation cue.')
                cue=hashlib.sha256(effect.value.encode()).hexdigest()
                requirement=ReceiptRequirement(ReceiptComponent.SUBTITLE,effect.id,cue,cue)
            else:
                effect=next((effect for effect in effects if effect.kind is EffectKind.POSE
                             and effect.value==RAINCOAT_CONTROL),None)
                if effect is None:raise DomainError('invalid_response','No compiled wardrobe effect.')
                cue=None
                requirement=ReceiptRequirement(ReceiptComponent.WARDROBE,effect.id,effect.digest)
            story,_=bind_compiled_effect(story,plan,compiled_effect_id=effect.id,
                compiled_effect_digest=effect.digest,requirement=requirement,actual_cue_digest=cue)
        affect=self.runtime.affect
        if input_id not in affect.seen_input_ids:
            affect_proposal=None;signal=AffectSignal.UNCERTAIN
            if candidate.affect_proposal_json is not None:
                try:
                    ids=tuple(turn.input_id for turn in affect.recent_turns if turn.reliable)[-3:]+(input_id,)
                    affect_proposal=parse_affect_proposal(json.loads(candidate.affect_proposal_json),
                        trusted_evidence_ids=ids,approved_canon_ids=context.character_story.canon_entry_ids)
                    signal=affect_proposal.signal
                except (ValueError,TypeError,KeyError):
                    raise DomainError('invalid_response','Invalid affect suggestion.') from None
            turn=affect_turn_from_jev(input_id,signal,
                sufficient_evidence=bool(evidence and evidence.affect_supported is V.YES),
                specific_notice=bool(evidence and evidence.specific_notice is V.YES))
            affect=reduce_affect(affect,turn,affect_proposal,self.runtime.definition)
        # Only remove optional POSEs from the exact reviewed/compiled range.
        # Speech/subtitle IDs, digests and cue linkage remain untouched.
        admitted = tuple(effect for effect in effects
            if not self._is_character_control(effect)
            or (self.readiness.state_for(CHARACTER_CAPABILITIES.get(effect.value, '')) is CapabilityState.READY
                and (not effect.value.startswith('emotion_')
                     or effect.value == 'emotion_' + affect.emotion.value)))
        if not admitted:
            # The allowed evidence still counts once toward hysteresis, but no
            # grant (including an invented normal-emotion grant) is produced.
            self.runtime.story, self.runtime.affect = story, affect
            raise DomainError('review_uncertain', 'No admitted character effect remains.')
        grants = tuple((effect, self.readiness.get(CHARACTER_CAPABILITIES[effect.value]).asset_revision)
                       for effect in admitted if effect.kind is EffectKind.POSE
                       and effect.value in CHARACTER_CAPABILITIES)
        return PreparedCharacterUpdate(story, affect, admitted, grants)

    @staticmethod
    def _is_character_control(effect):
        return effect.kind is EffectKind.POSE and effect.value.startswith(('outfit_', 'accessory_', 'emotion_'))

    def commit(self,update:PreparedCharacterUpdate):
        self.runtime.story,self.runtime.affect=update.story,update.affect
        self._control_grants.update((effect.id, (effect, revision))
                                    for effect, revision in update.control_grants)

    def stop(self,epoch:int):
        self.runtime.apply_story(Stop(epoch))

    def checkpoint_snapshot(self):
        return self.runtime.snapshot() if self._checkpoint is not None else None

    async def persist(self,snapshot:RuntimeSnapshot | None):
        if snapshot is not None and self._checkpoint is not None:
            try:
                await self._checkpoint(snapshot)
            except Exception:
                # An already-started write may have succeeded. The same receipt
                # can reconcile, but no new provider turn is automatically tried.
                raise DomainError('story_checkpoint_pending',
                    'Character history save is pending or unavailable; retry the same receipt.') from None

    def acknowledge(self,receipt:Receipt,effect:Effect):
        """Called only after the Actor validates issued identity and Stop cutoff.

        Late pre-fence facts can reconcile history; they cannot advance a graph
        or recreate a grant. A new browser has no old compiled-control ledger.
        """
        if ((receipt.effect_id, receipt.digest, receipt.output_epoch, receipt.activity_seq) !=
                (effect.id, effect.digest, effect.output_epoch, effect.activity_seq)):
            return
        pending=self.runtime.story.pending
        if pending is not None and pending.compiled_effect_id==effect.id:
            requirement=pending.receipt_requirement
            if requirement is None:return
            current=self.runtime.story
            value=PresentationReceipt('visual.'+effect.id+'.'+str(receipt.presentation_seq),current.scope_id,
                current.story_id,current.graph_revision,current.canon_revision,receipt.output_epoch,
                pending.grant_id,pending.transition_id,pending.receipt_kind,EvidenceLabel.CLIENT_REPORT,'complete',
                offer_id=pending.offer_id,before_outfit=current.current_outfit,
                after_outfit='amber_raincoat' if pending.receipt_kind is ReceiptKind.WARDROBE_COMPLETED else None,
                capability_revision=pending.capability_revision,
                compiled_effect_id=effect.id,compiled_effect_digest=effect.digest,
                component=requirement.component,component_id=requirement.component_id,
                component_digest=requirement.component_digest,cue_digest=requirement.cue_digest)
            result=self.runtime.apply_story(value)
            if result.code is ResultCode.RECEIPT_ACCEPTED:
                if effect.value == RAINCOAT_CONTROL:
                    self._last_presentation_seq['outfit'] = receipt.presentation_seq
                self._control_grants.pop(effect.id, None)
                return
        grant=self._control_grants.get(effect.id)
        if grant is None or grant[0] != effect:
            return
        current=self.runtime.story
        slot, target=effect.value.split('_',1)
        receipt_id='visual.'+effect.id+'.'+str(receipt.presentation_seq)
        if receipt_id in current.receipt_ids:
            self._control_grants.pop(effect.id,None)
            return
        # Presentation sequence is the validated within-browser ordering, not
        # network arrival order. A late older receipt never overwrites newer
        # acknowledged appearance. All valid facts remain qualified episodes.
        latest=receipt.presentation_seq > self._last_presentation_seq.get(slot,0)
        episode=EpisodeCandidate(
            candidate_id='episode.character_control:'+receipt_id,
            event_code='mira_'+effect.value+'_presented', receipt_id=receipt_id,
            compiled_effect_id=effect.id, compiled_effect_digest=effect.digest,
            component_id=effect.id, component_digest=effect.digest,
            evidence=EvidenceLabel.CLIENT_REPORT, story_id=current.story_id,
            graph_revision=current.graph_revision, canon_revision=current.canon_revision,
            character_state=((slot+'_after',target),
                             ('asset_revision',grant[1]),('history_scope','fictional_software_presentation'),
                             ('presentation_order','latest' if latest else 'earlier_than_acknowledged')))
        changes={}
        if latest:
            changes['last_acknowledged_'+slot]=target
            if slot=='outfit':changes['current_outfit']=target
            self._last_presentation_seq[slot]=receipt.presentation_seq
        self.runtime.story=replace(current, **changes,
            receipt_ids=(current.receipt_ids+(receipt_id,))[-64:],
            episodes=(current.episodes+(episode,))[-32:],revision=current.revision+1)
        self._control_grants.pop(effect.id,None)
