"""Typed provider events needed only by a continuous microphone lease.

Offsets are integer samples from the beginning of one lease's 16 kHz mono stream.
A final text result is not an utterance endpoint; only a matched speech-activity END
and a stable final result in that activity interval may produce a user-committable
utterance.
"""
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Literal, Protocol, TypeAlias

from mira.application.ports.media import AudioPacket


@dataclass(frozen=True, slots=True)
class ContinuousTranscriptResult:
    text: str
    is_final: bool
    result_end_offset_samples: int | None


@dataclass(frozen=True, slots=True)
class ContinuousSpeechActivity:
    kind: Literal["begin", "end"]
    speech_event_offset_samples: int


ContinuousRecognitionEvent: TypeAlias = ContinuousTranscriptResult | ContinuousSpeechActivity


class ContinuousSpeechRecognitionBackend(Protocol):
    """One bounded streaming RPC; adapters must retain provider offsets and VAD events."""
    def transcribe_events(self, packets: AsyncIterator[AudioPacket]
                          ) -> AsyncIterator[ContinuousRecognitionEvent]: ...
