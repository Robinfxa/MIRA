"""Bounded session-level microphone leases, independent of reply-turn epochs.

A lease owns one finite PCM queue and one recognition stream. It is never registered
as an ordinary SessionActor MediaOperation, since those are intentionally bound to
turn activity/input/output epochs. User Stop, lease replacement, disconnect and
session teardown revoke it explicitly through the registry.
"""
from __future__ import annotations

import asyncio
import re
import time
from collections import deque
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass, field
from typing import Literal

from mira.application.ports.continuous_speech import (
    ContinuousRecognitionEvent, ContinuousSpeechActivity, ContinuousSpeechRecognitionBackend,
    ContinuousTranscriptResult,
)
from mira.application.ports.media import AudioPacket
from mira.application.ports.diagnostics import Diagnostics
from mira.application.diagnostic_errors import classify_failure
from mira.application.diagnostic_events import (
    CancellationReason, DiagnosticCode, DiagnosticOutcome, DiagnosticSpan, DiagnosticStage,
    diagnostic_context, failure_diagnostic_id,
)
from mira.application.media_runtime import media_error
from mira.domain.errors import DomainError

SAMPLE_RATE_HZ = 16_000
MAX_CHUNK_BYTES = 12_000
MAX_TEXT_CHARS = 2_000
MAX_REVISION_COUNT = 10_000
MAX_LISTENING_LEASES_PER_SESSION = 4
MAX_UTTERANCES_PER_LEASE = 12
QUEUE_CAPACITY = 8
OUTPUT_CAPACITY = 32
# Provider event offsets are not guaranteed to be byte-for-byte identical. Bound the
# acceptable delay between the last final result and VAD END instead of requiring equality.
MAX_FINAL_TO_END_SECONDS = 3.0
_CANCELLATION_REASONS = {
    "user_stop": CancellationReason.USER_STOP,
    "disconnect": CancellationReason.DISCONNECT,
    "replaced": CancellationReason.SUPERSEDED,
    "session_closed": CancellationReason.SESSION_CLOSED,
    "permission_lost": CancellationReason.PERMIT_REVOKED,
}
_DECLARED_LIMIT_REASONS = frozenset({"max_duration", "max_samples", "utterance_limit"})


@dataclass(frozen=True, slots=True)
class ListeningLimits:
    # ``max_seconds == max_samples == 0`` is an explicit disabled state. It is used
    # when an admitted STT policy allows a positive sub-second call (for ordinary
    # PTT) but cannot safely authorize the minimum one-second continuous lease.
    max_seconds: int = 120
    max_samples: int = SAMPLE_RATE_HZ * 120
    max_utterances: int = MAX_UTTERANCES_PER_LEASE
    max_streams_per_session: int = MAX_LISTENING_LEASES_PER_SESSION
    max_total_streams: int = 8
    queue_capacity: int = QUEUE_CAPACITY
    output_capacity: int = OUTPUT_CAPACITY
    max_final_to_end_seconds: float = MAX_FINAL_TO_END_SECONDS

    def __post_init__(self) -> None:
        disabled = self.max_seconds == 0 and self.max_samples == 0
        enabled = (type(self.max_seconds) is int and 1 <= self.max_seconds <= 290
                   and type(self.max_samples) is int and
                   1 <= self.max_samples <= SAMPLE_RATE_HZ * self.max_seconds)
        if (type(self.max_seconds) is not int or type(self.max_samples) is not int
                or not (disabled or enabled)
                or type(self.max_utterances) is not int or not 1 <= self.max_utterances <= 32
                or type(self.max_streams_per_session) is not int or not 1 <= self.max_streams_per_session <= 16
                or type(self.max_total_streams) is not int or not 1 <= self.max_total_streams <= 100
                or type(self.queue_capacity) is not int or not 1 <= self.queue_capacity <= 32
                or type(self.output_capacity) is not int or not 1 <= self.output_capacity <= 128
                or type(self.max_final_to_end_seconds) not in (int, float)
                or not 0.1 <= self.max_final_to_end_seconds <= 10):
            raise ValueError("continuous_listening_limits_invalid")


@dataclass(frozen=True, slots=True)
class ListeningEvent:
    type: Literal["transcript", "stopped", "endpoint_pending"]
    lease_id: str
    revision: int | None = None
    text: str | None = None
    is_final: bool | None = None
    endpoint: str | None = None
    reason: str | None = None
    diagnostic_id: str | None = None


@dataclass(frozen=True, slots=True)
class _FinalResult:
    text: str
    offset: int | None
    revision: int
    activity_index: int


@dataclass(frozen=True, slots=True)
class _PendingEnd:
    offset: int
    activity_index: int
    begin_offset: int


@dataclass(slots=True)
class _ActivityInterval:
    index: int
    begin_offset: int
    end_offset: int | None = None


@dataclass(slots=True)
class _UtteranceBinding:
    lease_id: str
    text: str
    segment_seq: int
    status: Literal["pending", "reserved", "accepted", "revoked"] = "pending"
    request_id: str | None = None
    delivered: bool = False


@dataclass(frozen=True, slots=True)
class ListeningCommitResult:
    lease_id: str
    commit_id: str
    segment_seq: int
    revision: int
    text: str


class ListeningAudioBuffer:
    """Finite, paced, contiguous mono PCM16 stream with an eight-packet default queue."""
    def __init__(self, lease_id: str, *, limits: ListeningLimits):
        self.lease_id = lease_id
        self._queue: asyncio.Queue[AudioPacket | None] = asyncio.Queue(maxsize=limits.queue_capacity)
        self._limits = limits
        self._samples = 0
        self._sequence = 0
        self._started = time.monotonic()
        self._finished = False
        self._closed = False

    @property
    def samples(self) -> int:
        return self._samples

    @property
    def finished(self) -> bool:
        return self._finished

    @property
    def elapsed_seconds(self) -> float:
        return time.monotonic() - self._started

    @property
    def remaining_seconds(self) -> float:
        return max(0.0, self._limits.max_seconds - self.elapsed_seconds)

    def push(self, *, lease_id: str, sequence: int, first_sample: int, pcm: bytes) -> None:
        if self._closed or self._finished:
            raise DomainError("media_cancelled", "Listening lease is no longer active.")
        if lease_id != self.lease_id:
            raise DomainError("stale_stream", "Audio belongs to another listening lease.")
        if type(sequence) is not int or sequence != self._sequence + 1:
            raise DomainError("invalid_input", "Audio chunks must be sequential.")
        if type(first_sample) is not int or first_sample != self._samples:
            raise DomainError("invalid_input", "Audio samples must be contiguous.")
        if (not isinstance(pcm, bytes) or not pcm or len(pcm) % 2 or len(pcm) > MAX_CHUNK_BYTES
                or (first_sample == 0 and pcm[:4] == b"RIFF" and pcm[8:12] == b"WAVE")):
            raise DomainError("invalid_audio", "Expected bounded headerless PCM16 audio.")
        samples = len(pcm) // 2
        elapsed = self.elapsed_seconds
        if (self._samples + samples > self._limits.max_samples
                or self._samples + samples > SAMPLE_RATE_HZ * self._limits.max_seconds):
            raise DomainError("input_limit", "Listening lease reached its sample budget.")
        if self._samples + samples > SAMPLE_RATE_HZ * (elapsed + 1.0):
            raise DomainError("input_limit", "Audio exceeds the listening pace limit.")
        try:
            self._queue.put_nowait(AudioPacket(self.lease_id, self._samples, SAMPLE_RATE_HZ, pcm))
        except asyncio.QueueFull:
            raise DomainError("input_limit", "Listening audio queue is full.") from None
        self._samples += samples
        self._sequence = sequence

    def finish(self) -> None:
        if self._finished:
            return
        self._finished = True
        if not self._queue.full():
            self._queue.put_nowait(None)

    def clear(self) -> None:
        self._closed = True
        self._finished = True
        while not self._queue.empty():
            self._queue.get_nowait()

    async def packets(self):
        while True:
            if self._closed:
                return
            if self._finished and self._queue.empty():
                return
            packet = await self._queue.get()
            if packet is None:
                return
            yield packet


class ListeningLease:
    """One finite stream lease; transcripts stay provisional until explicit UI commit."""
    def __init__(self, session_id: str, lease_id: str, *, limits: ListeningLimits,
                 diagnostics: Diagnostics | None = None):
        self.session_id, self.lease_id, self.limits = session_id, lease_id, limits
        self._diagnostics_sink = diagnostics
        self._diagnostic_context = diagnostic_context(session_id=session_id)
        self._diagnostic_span: DiagnosticSpan | None = None
        self.audio = ListeningAudioBuffer(lease_id, limits=limits)
        self.active = True
        self.reason: str | None = None
        self.started_at = time.monotonic()
        self.events: asyncio.Queue[ListeningEvent] = asyncio.Queue(maxsize=limits.output_capacity)
        self._revision = 0
        self._activity_index = 0
        self._in_activity = False
        self._intervals: deque[_ActivityInterval] = deque(maxlen=16)
        self._ends: deque[_PendingEnd] = deque(maxlen=16)
        self._finals: deque[_FinalResult] = deque(maxlen=32)
        self._seen_offsets: set[tuple[int, str]] = set()
        self._recognized_chars = 0
        self._commit_count = 0
        self._commit_results: dict[str, ListeningCommitResult] = {}
        self._state_lock = asyncio.Lock()
        self._recognition_task: asyncio.Task | None = None
        self._terminal_sent = False
        self._stable_transcript = ""
        self._interim_transcript = ""
        self._latest_preview = ""
        self._endpoint_hint_by_activity: dict[int, str] = {}

    @property
    def diagnostic_id(self) -> str | None:
        return (failure_diagnostic_id(self._diagnostic_context)
                if self._diagnostic_span is not None else None)

    @property
    def active_duration_seconds(self) -> float:
        return time.monotonic() - self.started_at

    @property
    def revision(self) -> int:
        return self._revision

    @property
    def stable_text(self) -> str:
        return self._stable_transcript.strip()

    async def emit(self, event: ListeningEvent) -> bool:
        if not self.active and event.type != "stopped":
            return False
        try:
            self.events.put_nowait(event)
        except asyncio.QueueFull:
            self.stop("output_limit")
            await self._emit_stopped("output_limit")
            return False
        return True

    async def recognize(self, backend: ContinuousSpeechRecognitionBackend,
                        *, is_current,
                        register_utterance: Callable[["ListeningLease", str, str, int], Awaitable[None]]) -> None:
        """Consume one provider stream. It never creates an Actor input or generation turn."""
        stream = None
        error = None
        cancelled = False
        cleanup_failed = False
        span = None
        try:
            if not self.active or not is_current(self):
                return
            span = DiagnosticSpan(self._diagnostics_sink, DiagnosticStage.STT,
                                  self._diagnostic_context)
            self._diagnostic_span = span
            stream = backend.transcribe_events(self.audio.packets())
            while self.active and is_current(self):
                try:
                    event = await anext(stream)
                except StopAsyncIteration:
                    break
                if not self.active or not is_current(self):
                    return
                if isinstance(event, ContinuousTranscriptResult):
                    await self._on_transcript(event)
                    span.observe(DiagnosticStage.STT_FIRST_REVISION)
                    if event.is_final:
                        span.observe(DiagnosticStage.STT_FIRST_FINAL_REVISION)
                elif isinstance(event, ContinuousSpeechActivity):
                    await self._on_activity(event)
                else:
                    raise DomainError("invalid_response", "Invalid continuous recognition event.")
        except asyncio.CancelledError:
            cancelled = True
            raise
        except Exception as failure:
            try:
                error = media_error(failure)  # Existing fixed safe codes only; never exception text.
            except Exception:
                error = DomainError("unavailable", "Recognition did not complete.")
            self.stop(error.code)
            await self._emit_stopped(error.code)
        else:
            if self.active and is_current(self):
                self.stop("provider_stream_ended")
                await self._emit_stopped("provider_stream_ended")
        finally:
            if stream is not None:
                close = getattr(stream, "aclose", None)
                if close is not None:
                    try:
                        await close()
                    except Exception:
                        cleanup_failed = True
            if span is not None:
                reason = _CANCELLATION_REASONS.get(self.reason)
                if reason is not None:
                    outcome, code = DiagnosticOutcome.CANCELLED, DiagnosticCode.CANCELLED
                elif error is not None:
                    outcome, code = DiagnosticOutcome.FAILED, classify_failure(error).code
                elif self.reason in _DECLARED_LIMIT_REASONS:
                    outcome, code = DiagnosticOutcome.SUCCEEDED, DiagnosticCode.LIMIT_REACHED
                elif cancelled:
                    outcome, code = DiagnosticOutcome.CANCELLED, DiagnosticCode.CANCELLED
                    reason = CancellationReason.UNKNOWN
                elif cleanup_failed:
                    outcome, code = DiagnosticOutcome.FAILED, DiagnosticCode.UNAVAILABLE
                else:
                    outcome, code = DiagnosticOutcome.SUCCEEDED, None
                # These server times start at the recognition consumer, not network dispatch.
                span.observe(DiagnosticStage.STT_STREAM_END,
                             DiagnosticOutcome.FAILED if cleanup_failed else outcome)
                span.finish(outcome, code=code, reason=reason)

    async def _on_transcript(self, event: ContinuousTranscriptResult) -> None:
        if (not isinstance(event.text, str) or len(event.text) > MAX_TEXT_CHARS
                or type(event.is_final) is not bool
                or (event.result_end_offset_samples is not None and (
                    type(event.result_end_offset_samples) is not int
                    or event.result_end_offset_samples < 0
                    or event.result_end_offset_samples > self.limits.max_samples))):
            raise DomainError("invalid_response", "Invalid continuous transcript result.")
        async with self._state_lock:
            self._revision += 1
            if self._revision > MAX_REVISION_COUNT:
                raise DomainError("input_limit", "Listening revision budget reached.")
            if event.is_final:
                offset = event.result_end_offset_samples
                seen_key = None if offset is None else (offset, event.text)
                duplicate = seen_key is not None and seen_key in self._seen_offsets
                if not duplicate:
                    self._recognized_chars += len(event.text)
                    if self._recognized_chars > MAX_TEXT_CHARS * self.limits.max_utterances:
                        raise DomainError("input_limit", "Listening transcript budget reached.")
                    if len(self._stable_transcript) + len(event.text) > MAX_TEXT_CHARS:
                        raise DomainError("input_limit", "Current transcript reached its text budget.")
                    self._stable_transcript += event.text
                    self._interim_transcript = ""
                    if seen_key is not None:
                        self._seen_offsets.add(seen_key)
                        interval = next((item for item in reversed(self._intervals)
                            if item.begin_offset <= offset and (item.end_offset is None or offset <= item.end_offset)), None)
                        self._finals.append(_FinalResult(event.text, offset, self._revision,
                            interval.index if interval is not None else 0))
                self._interim_transcript = ""
                missing_offset = offset is None and not duplicate
            else:
                self._interim_transcript = event.text
                missing_offset = False
            self._latest_preview = self._stable_transcript + self._interim_transcript
            if len(self._latest_preview) > MAX_TEXT_CHARS:
                raise DomainError("input_limit", "Current transcript reached its text budget.")
            revision, preview = self._revision, self._latest_preview
        await self.emit(ListeningEvent(type="transcript", lease_id=self.lease_id,
            revision=revision, text=preview, is_final=event.is_final))
        if missing_offset:
            await self.emit(ListeningEvent(type="endpoint_pending", lease_id=self.lease_id,
                revision=revision, text=preview, is_final=True, reason="missing_result_offset"))
        else:
            await self._emit_endpoint_hints()

    async def _on_activity(self, event: ContinuousSpeechActivity) -> None:
        if (event.kind not in ("begin", "end") or type(event.speech_event_offset_samples) is not int
                or event.speech_event_offset_samples < 0
                or event.speech_event_offset_samples > self.limits.max_samples):
            raise DomainError("invalid_response", "Invalid speech activity event.")
        if event.kind == "begin":
            if self._in_activity:
                raise DomainError("invalid_response", "Repeated speech activity BEGIN without END.")
            self._activity_index += 1
            self._in_activity = True
            self._intervals.append(_ActivityInterval(self._activity_index,
                event.speech_event_offset_samples))
            return
        if not self._in_activity:
            # Orphan END has no manual-input or commit authority.
            return
        interval = next((item for item in reversed(self._intervals)
                         if item.index == self._activity_index), None)
        if interval is None or event.speech_event_offset_samples < interval.begin_offset:
            raise DomainError("invalid_response", "Speech activity offsets moved backwards.")
        interval.end_offset = event.speech_event_offset_samples
        self._ends.append(_PendingEnd(event.speech_event_offset_samples,
                                      self._activity_index, interval.begin_offset))
        self._in_activity = False
        await self._emit_endpoint_hints()

    async def _emit_endpoint_hints(self) -> None:
        """Emit only a UI hint. It never creates a committable input or an Actor turn."""
        threshold = int(self.limits.max_final_to_end_seconds * SAMPLE_RATE_HZ)
        async with self._state_lock:
            pending = self._stable_transcript.strip()
            revision = self._revision
            ends = tuple(self._ends)
            finals = tuple(self._finals)
        if not pending:
            return
        for end in ends:
            covered = [result for result in finals
                if result.offset is not None
                and end.begin_offset <= result.offset <= end.offset]
            if not covered:
                continue
            latest = max(covered, key=lambda result: (result.offset, result.revision))
            if end.offset - latest.offset > threshold:
                continue
            if self._endpoint_hint_by_activity.get(end.activity_index) == pending:
                continue
            self._endpoint_hint_by_activity[end.activity_index] = pending
            await self.emit(ListeningEvent(type="endpoint_pending", lease_id=self.lease_id,
                revision=revision, text=pending, is_final=True,
                reason="unmatched_activity_end"))

    async def manual_commit(self, *, commit_id: str, revision: int,
                            registry: "ContinuousListeningRegistry") -> ListeningCommitResult:
        if not re.fullmatch(r"[A-Fa-f0-9-]{36}", commit_id):
            raise DomainError("invalid_input", "Invalid listening commit identity.")
        async with self._state_lock:
            prior = self._commit_results.get(commit_id)
            if prior is not None:
                if prior.revision == revision:
                    return prior
                raise DomainError("request_conflict", "Commit identity was reused with different data.")
            if not self.active or not registry.is_current(self):
                raise DomainError("media_cancelled", "Listening lease was revoked.")
            if type(revision) is not int or revision != self._revision:
                raise DomainError("transcript_stale", "Transcript changed before the manual commit.")
            text = self._stable_transcript.strip()
            if not text:
                raise DomainError("transcript_empty", "No stable final transcript is ready to send.")
            if self._commit_count >= self.limits.max_utterances:
                raise DomainError("session_capacity", "Listening commit budget reached.")
            segment_seq = self._commit_count + 1
            await registry.register_utterance(self, commit_id, text, segment_seq)
            result = ListeningCommitResult(self.lease_id, commit_id, segment_seq, revision, text)
            self._commit_results[commit_id] = result
            self._commit_count += 1
            self._stable_transcript = ""
            self._latest_preview = self._interim_transcript
            self._revision += 1
            next_revision = self._revision
            preview = self._latest_preview
            exhausted = self._commit_count >= self.limits.max_utterances
            if exhausted:
                # The commit snapshot is returned directly to the client before the
                # WebSocket drains this visible finite lease-stop event.
                self.stop("utterance_limit")
        await self.emit(ListeningEvent(type="transcript", lease_id=self.lease_id,
            revision=next_revision, text=preview, is_final=False))
        if exhausted:
            await self._emit_stopped("utterance_limit")
        return result

    def stop(self, reason: str = "user_stop") -> None:
        if not self.active:
            return
        self.active = False
        self.reason = reason
        # Record the observed local stop immediately; provider cleanup may lag or fail.
        if self._diagnostic_span is not None:
            cancel_reason = _CANCELLATION_REASONS.get(reason)
            if cancel_reason is not None:
                self._diagnostic_span.finish(DiagnosticOutcome.CANCELLED,
                    code=DiagnosticCode.CANCELLED, reason=cancel_reason)
            elif reason in _DECLARED_LIMIT_REASONS:
                self._diagnostic_span.finish(DiagnosticOutcome.SUCCEEDED,
                    code=DiagnosticCode.LIMIT_REACHED)
        self.audio.clear()
        task = self._recognition_task
        if task is not None and not task.done() and task is not asyncio.current_task():
            task.cancel()
        while not self.events.empty():
            try:
                self.events.get_nowait()
            except asyncio.QueueEmpty:
                break

    async def _emit_stopped(self, reason: str) -> None:
        if self._terminal_sent:
            return
        self._terminal_sent = True
        try:
            self.events.put_nowait(ListeningEvent(type="stopped", lease_id=self.lease_id,
                                                   reason=reason, diagnostic_id=self.diagnostic_id))
        except asyncio.QueueFull:
            pass

    async def aclose(self, reason: str = "session_closed") -> None:
        self.stop(reason)
        task = self._recognition_task
        if task is not None:
            await asyncio.wait({task}, timeout=.25)


class ContinuousListeningRegistry:
    """One active lease per session plus bounded one-use input authority."""
    def __init__(self, *, limits: ListeningLimits | None = None,
                 diagnostics: Diagnostics | None = None):
        self.limits = limits or ListeningLimits()
        self._diagnostics = diagnostics
        self._lock = asyncio.Lock()
        self._active: dict[str, ListeningLease] = {}
        self._lease_count: dict[str, int] = {}
        self._utterances: dict[tuple[str, str], _UtteranceBinding] = {}
        self._used_lease_ids: set[tuple[str, str]] = set()
        self._total_leases = 0
        self._closed = False

    async def start(self, session_id: str, lease_id: str) -> ListeningLease:
        if not isinstance(session_id, str) or not session_id or not re.fullmatch(
                r"[A-Fa-f0-9-]{36}", lease_id):
            raise DomainError("invalid_input", "Invalid listening lease identity.")
        replaced = None
        async with self._lock:
            if self._closed:
                raise DomainError("session_closed", "Listening service has closed.")
            if self._lease_count.get(session_id, 0) >= self.limits.max_streams_per_session:
                raise DomainError("session_capacity", "Listening lease request budget reached.")
            if self._total_leases >= self.limits.max_total_streams:
                raise DomainError("session_capacity", "Application STT lease budget reached.")
            key = (session_id, lease_id)
            if key in self._used_lease_ids:
                raise DomainError("stream_consumed", "Listening lease identity has already been used.")
            replaced = self._active.get(session_id)
            lease = ListeningLease(session_id, lease_id, limits=self.limits, diagnostics=self._diagnostics)
            self._active[session_id] = lease
            self._used_lease_ids.add(key)
            self._lease_count[session_id] = self._lease_count.get(session_id, 0) + 1
            self._total_leases += 1
        if replaced is not None:
            await self.stop_lease(replaced, "replaced")
        return lease

    def is_current(self, lease: ListeningLease) -> bool:
        return lease.active and self._active.get(lease.session_id) is lease

    async def current(self, session_id: str) -> ListeningLease | None:
        async with self._lock:
            return self._active.get(session_id)

    def lease_starts_for_session(self, session_id: str) -> int:
        return self._lease_count.get(session_id, 0)

    @property
    def total_lease_starts(self) -> int:
        return self._total_leases

    async def stop_session(self, session_id: str, reason: str = "user_stop") -> None:
        async with self._lock:
            lease = self._active.pop(session_id, None)
        if lease is not None:
            await self._stop(lease, reason)

    async def stop_lease(self, lease: ListeningLease, reason: str = "user_stop") -> None:
        async with self._lock:
            if self._active.get(lease.session_id) is lease:
                self._active.pop(lease.session_id, None)
        await self._stop(lease, reason)

    async def _stop(self, lease: ListeningLease, reason: str) -> None:
        revoke = reason in {"user_stop", "permission_lost", "replaced", "disconnect",
                            "session_closed", "invalid_input"}
        async with self._lock:
            if revoke:
                for (session_id, _commit_id), binding in self._utterances.items():
                    if session_id == lease.session_id and binding.lease_id == lease.lease_id:
                        if binding.status in ("pending", "reserved"):
                            binding.status = "revoked"
        lease.stop(reason)
        await lease._emit_stopped(reason)

    async def register_utterance(self, lease: ListeningLease, utterance_id: str,
                                 text: str, segment_seq: int) -> None:
        if not self.is_current(lease):
            raise DomainError("media_cancelled", "Listening lease was revoked.")
        if (not re.fullmatch(r"[A-Fa-f0-9-]{36}", utterance_id) or not text
                or len(text) > MAX_TEXT_CHARS or type(segment_seq) is not int or segment_seq < 1):
            raise DomainError("invalid_input", "Invalid listening utterance.")
        async with self._lock:
            if not self.is_current(lease):
                raise DomainError("media_cancelled", "Listening lease was revoked.")
            key = (lease.session_id, utterance_id)
            existing = self._utterances.get(key)
            if existing is not None:
                if (existing.lease_id, existing.text, existing.segment_seq) == (
                        lease.lease_id, text.strip(), segment_seq):
                    return
                raise DomainError("request_conflict", "Listening commit identity was reused.")
            session_records = sum(1 for (sid, _), binding in self._utterances.items()
                                  if sid == lease.session_id and binding.status != "revoked")
            if session_records >= self.limits.max_streams_per_session * self.limits.max_utterances:
                raise DomainError("session_capacity", "Listening input budget reached.")
            self._utterances[key] = _UtteranceBinding(lease.lease_id, text.strip(), segment_seq)

    async def mark_delivered(self, session_id: str, lease_id: str, commit_id: str) -> bool:
        async with self._lock:
            binding = self._utterances.get((session_id, commit_id))
            if (binding is None or binding.lease_id != lease_id or binding.status != "pending"):
                return False
            binding.delivered = True
            return True

    async def mark_accepted(self, session_id: str, utterance_id: str, request_id: str,
                            text: str) -> None:
        """Record that Actor.submit committed this exact input; Stop cannot undo it."""
        async with self._lock:
            binding = self._utterances.get((session_id, utterance_id))
            if (binding is None or binding.text != text.strip()
                    or binding.request_id != request_id
                    or binding.status not in ("reserved", "revoked", "accepted")):
                raise DomainError("request_conflict", "Listening input was not reserved.")
            binding.status = "accepted"

    async def validate_submission(self, session_id: str, utterance_id: str, request_id: str,
                                  text: str) -> bool:
        """Bind explicit UI commit to one standard input request, idempotent on exact retry."""
        async with self._lock:
            binding = self._utterances.get((session_id, utterance_id))
            if binding is None or binding.text != text.strip():
                raise DomainError("request_conflict", "Listening transcript does not match its lease.")
            if binding.status == "accepted":
                if binding.request_id == request_id:
                    return True
                raise DomainError("request_conflict", "Listening commit was already consumed.")
            if binding.status == "revoked":
                raise DomainError("request_conflict", "Listening commit was revoked by Stop.")
            if not binding.delivered:
                raise DomainError("request_conflict", "Listening commit has not been delivered.")
            if binding.status == "reserved":
                if binding.request_id == request_id:
                    return True
                raise DomainError("request_conflict", "Listening commit is reserved for another request.")
            binding.request_id = request_id
            binding.status = "reserved"
            return True

    async def close_session(self, session_id: str) -> None:
        await self.stop_session(session_id, "session_closed")
        async with self._lock:
            self._lease_count.pop(session_id, None)
            self._used_lease_ids = {key for key in self._used_lease_ids if key[0] != session_id}
            for key in [key for key in self._utterances if key[0] == session_id]:
                self._utterances.pop(key, None)

    async def aclose(self) -> None:
        async with self._lock:
            self._closed = True
            leases = tuple(self._active.values())
            self._active.clear()
        for lease in leases:
            await self._stop(lease, "session_closed")
        async with self._lock:
            self._lease_count.clear()
            self._used_lease_ids.clear()
            self._utterances.clear()
            self._total_leases = 0
