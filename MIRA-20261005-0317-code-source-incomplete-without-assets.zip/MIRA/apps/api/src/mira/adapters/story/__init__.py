"""Authored character data adapters."""
