"""Bounded untrusted character suggestions, separate from effects and authority."""
from __future__ import annotations

import hashlib

from mira.application.contracts import GenerationContext
from mira.domain.story import Affect, AffectSignal, parse_story_proposal
from mira.domain.models import EffectKind
from mira.application.character_controls import CHARACTER_POSES
from .payload import canonical, parse_effects, strict_json, POSES
from .types import CodexGenerationError


def offered_id(context: GenerationContext) -> str:
    if context.character_story is None:
        raise CodexGenerationError('codex_character_context_missing')
    raw=context.character_story.projection_id+':'+str(context.output_epoch)
    return 'offer.'+hashlib.sha256(raw.encode()).hexdigest()[:24]


def character_proposal_contract(context: GenerationContext) -> dict:
    return {
        'schema':'mira.character-proposals.v1',
        'next_offer_id':offered_id(context),
        'active_offer_id':context.character_story.active_offer_id,
        'story_proposal':{
            'fields':['transition_id','signal','offer_id','target_capabilities','draft_cue'],
            'transitions':{'t.chat':'chat','t.offer':'offer_rain','t.yes':'accept_raincoat'},
            'raincoat_capability':'mira.outfit.amber_raincoat',
            'rule':'Use next_offer_id for a new offer and active_offer_id for accepting an existing offer. t.yes only accepts the exact presented rain invitation. Direct user wardrobe/accessory requests may propose the matching authored pose without a story transition. Every control still needs full independent output review and an exact ready entry in facts.character_assets. Unknown or unavailable means stay naturally in the current scene. These suggestions do not grant actions. last_acknowledged_appearance is historical software presentation, not proof the current browser restored it; never claim automatic restoration.',
        },
        'affect_proposal':{
            'fields':['candidate','signal','canon_reason_id'],
            'candidates':[item.value for item in Affect],
            'signals':[item.value for item in AffectSignal],
            'rule':'Propose only; do not supply confidence or source IDs. Independent semantic evidence and recent-turn smoothing decide internal affect, independently of story progress and idle/listening/thinking/speaking phase. A visible emotion needs its own optional authored emotion pose in effects, full review, a ready asset, and agreement with the resulting internal affect. Mismatching optional emotion effects may be dropped; no unproposed emotion is added. Only a successful exact presentation receipt establishes visual history.',
        },
    }


def parse_character_candidate(texts, limits, context, *, speech_enabled=True):
    if context.character_story is None:
        return parse_effects(texts,limits,speech_enabled=speech_enabled),None,None
    if len(texts)!=1 or len(texts[0].encode('utf-8'))>limits.max_output_bytes:
        raise CodexGenerationError('codex_output_limit')
    obj=strict_json(texts[0])
    if (type(obj) is not dict or 'effects' not in obj
            or set(obj)-{'effects','story_proposal','affect_proposal'}):
        raise CodexGenerationError('codex_effects_invalid')
    effects=parse_effects([canonical({'effects':obj['effects']}).decode()],limits,
                         speech_enabled=speech_enabled,allowed_poses=POSES+CHARACTER_POSES)
    encoded=[]
    for name in ('story_proposal','affect_proposal'):
        value=obj.get(name)
        if value is None:
            encoded.append(None);continue
        if type(value) is not dict or len(canonical(value))>4096:
            raise CodexGenerationError('codex_character_proposal_invalid')
        try:
            if name=='story_proposal':
                parsed=parse_story_proposal(value,input_id='untrusted-candidate',epoch=context.output_epoch)
                if parsed.transition_id=='t.offer' and parsed.offer_id!=offered_id(context):
                    raise ValueError('offer_binding')
                if parsed.transition_id=='t.offer' and (not parsed.draft_cue
                        or not any(effect.kind is EffectKind.SUBTITLE and effect.value==parsed.draft_cue
                                   for effect in effects)):
                    raise ValueError('offer_cue_binding')
                if parsed.transition_id=='t.yes' and (not context.character_story.active_offer_id
                        or parsed.offer_id!=context.character_story.active_offer_id):
                    raise ValueError('offer_binding')
            else:
                if (set(value)-{'candidate','signal','canon_reason_id'}
                        or not {'candidate','signal'}<=set(value)):
                    raise ValueError('affect_fields')
                Affect(value['candidate']);AffectSignal(value['signal'])
                reason=value.get('canon_reason_id')
                if reason is not None and (type(reason) is not str
                        or reason not in context.character_story.canon_entry_ids):
                    raise ValueError('affect_canon')
        except (ValueError,TypeError,KeyError):
            raise CodexGenerationError('codex_character_proposal_invalid') from None
        encoded.append(canonical(value).decode())
    return effects,*encoded
