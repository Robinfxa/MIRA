"""Provider-direct OpenAI Responses transports for MIRA candidate generation.

Both supported routes are fixed endpoints selected explicitly by the caller. The
ChatGPT Codex subscription endpoint is an undocumented/private compatibility target;
this module makes no claim that it is a public OpenAI API contract. Credentials are
injected as opaque SecretStr values, and all provider output remains an untrusted
candidate until the existing independent review/application path accepts it.
"""
from __future__ import annotations

import asyncio
import json
import math
import re
import uuid
from collections.abc import AsyncIterator
from dataclasses import dataclass
from enum import StrEnum
from typing import Protocol

import httpx

from mira.application.contracts import CandidateRange, GenerationContext
from mira.domain.errors import DomainError

from .codex_support.payload import author_instructions, build_prompt, strict_json
from .codex_support.character_payload import parse_character_candidate

SUBSCRIPTION_ENDPOINT = "https://chatgpt.com/backend-api/codex/responses"
OPENAI_API_ENDPOINT = "https://api.openai.com/v1/responses"
_MODEL_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}\Z")
_SAFE_HEADER_VALUE = re.compile(r"[\x21-\x7e]{1,256}\Z")
_MIME_TOKEN = r"[!#$%&'*+\-.^_`|~0-9A-Za-z]+"
_MIME_QUOTED_VALUE = r'"(?:[\t\x20-\x21\x23-\x5b\x5d-\x7e]|\\[\t\x20-\x7e])*"'
_SSE_CONTENT_TYPE = re.compile(
    rf"\A[ \t]*text/event-stream[ \t]*(?:;[ \t]*{_MIME_TOKEN}[ \t]*=[ \t]*"
    rf"(?:{_MIME_TOKEN}|{_MIME_QUOTED_VALUE})[ \t]*)*\Z", re.IGNORECASE | re.ASCII)
_TOOL_ITEM_TYPES = frozenset({
    "function_call", "computer_call", "web_search_call", "file_search_call",
    "mcp_call", "code_interpreter_call", "image_generation_call", "shell_call",
})


class ResponsesRoute(StrEnum):
    """Explicit route selection; each value resolves only to a hard-coded endpoint."""

    CHATGPT_SUBSCRIPTION = "chatgpt_subscription"
    OPENAI_API = "openai_api"


class SecretToken(Protocol):
    """Small structural view of pydantic.SecretStr; never stringify a credential."""

    def get_secret_value(self) -> str: ...


class CredentialRecord(Protocol):
    access_token: SecretToken
    account_id: str | None
    residency: str | None


class CodexCredentialSource(Protocol):
    """Auth owner supplies credentials; the generation adapter never opens auth storage."""

    async def get_credentials(self) -> CredentialRecord: ...


@dataclass(frozen=True, slots=True)
class DirectResponsesLimits:
    startup_seconds: float = 10.0
    turn_seconds: float = 60.0
    max_line_bytes: int = 131_072
    max_wire_bytes: int = 1_048_576
    max_request_bytes: int = 131_072
    max_output_bytes: int = 16_384
    max_prompt_bytes: int = 65_536
    max_events: int = 1_024

    def __post_init__(self) -> None:
        for value in (self.startup_seconds, self.turn_seconds):
            if (type(value) not in (int, float) or not math.isfinite(value)
                    or not 0 < value <= 120):
                raise ValueError("direct_responses_timeout_limit_invalid")
        bounds = (
            (self.max_line_bytes, 128, 262_144),
            (self.max_wire_bytes, 1_024, 4_194_304),
            (self.max_request_bytes, 1_024, 262_144),
            (self.max_output_bytes, 128, 65_536),
            (self.max_prompt_bytes, 1_024, 131_072),
            (self.max_events, 1, 4_096),
        )
        if any(type(value) is not int or not low <= value <= high
               for value, low, high in bounds):
            raise ValueError("direct_responses_size_limit_invalid")


class DirectResponsesError(DomainError):
    """Fixed safe code plus local stage/status; never contains provider strings."""

    def __init__(self, code: str, stage: str, *, http_status: int | None = None) -> None:
        super().__init__(code, code)
        self.stage = stage
        self.http_status = http_status


@dataclass(frozen=True, slots=True)
class _SSEEvent:
    name: str
    data: str


@dataclass(frozen=True, slots=True)
class _CompletedOutput:
    output_index: int
    item_id: str | None
    text: str


def _payload_error_code(error: RuntimeError) -> str | None:
    """Recognize only fixed local payload/parser codes; never stringify error objects."""
    try:
        args = error.args
    except Exception:
        return None
    if len(args) == 1 and type(args[0]) is str and args[0] in {
            "codex_prompt_limit", "codex_context_invalid", "codex_capability_invalid",
            "codex_output_limit", "codex_json_invalid", "codex_effects_invalid",
            "codex_effects_unsupported"}:
        return args[0]
    return None


class DirectCodexResponsesGenerationBackend:
    """Default-OFF, bounded provider-direct `GenerationBackend` implementation.

    `transport` is an optional HTTPX transport injection for offline tests. Omit it for
    the normal HTTPX client, which keeps TLS verification and the environment's default
    proxy/network policy. Redirects are always disabled and the destination is fixed.
    """

    def __init__(self, route: ResponsesRoute, model: str,
                 credential_source: CodexCredentialSource, *, admitted: bool = False,
                 request_limit: int = 0, limits: DirectResponsesLimits | None = None,
                 transport: httpx.AsyncBaseTransport | None = None,
                 speech_enabled: bool = True) -> None:
        if type(route) is not ResponsesRoute:
            raise ValueError("direct_responses_route_invalid")
        if type(model) is not str or not _MODEL_PATTERN.fullmatch(model):
            raise ValueError("direct_responses_model_invalid")
        if (credential_source is None
                or not callable(getattr(credential_source, "get_credentials", None))):
            raise ValueError("direct_responses_credentials_unavailable")
        if type(admitted) is not bool or type(speech_enabled) is not bool:
            raise ValueError("direct_responses_admission_invalid")
        if type(request_limit) is not int or not 0 <= request_limit <= 100:
            raise ValueError("direct_responses_request_limit_invalid")
        if limits is not None and type(limits) is not DirectResponsesLimits:
            raise ValueError("direct_responses_limits_invalid")
        if transport is not None and not isinstance(transport, httpx.AsyncBaseTransport):
            raise ValueError("direct_responses_transport_invalid")
        self._route = route
        self._endpoint = (SUBSCRIPTION_ENDPOINT if route is ResponsesRoute.CHATGPT_SUBSCRIPTION
                          else OPENAI_API_ENDPOINT)
        self._model = model
        self._credential_source = credential_source
        self._admitted = admitted
        self._remaining = request_limit
        self._limits = limits or DirectResponsesLimits()
        self._transport = transport
        self._speech_enabled = speech_enabled

    async def generate(self, context: GenerationContext) -> AsyncIterator[CandidateRange]:
        if not self._admitted:
            raise DirectResponsesError("blocked", "admission")
        if not self._remaining:
            raise DirectResponsesError("response_limit", "admission")

        try:
            prompt = build_prompt(context, self._limits, speech_enabled=self._speech_enabled)
        except RuntimeError as error:
            code = _payload_error_code(error)
            mapped = "input_limit" if code == "codex_prompt_limit" else "invalid_input"
            raise DirectResponsesError(mapped, "prompt") from None
        except Exception:
            raise DirectResponsesError("invalid_input", "prompt") from None

        body = {
            "model": self._model,
            "instructions": author_instructions(
                speech_enabled=self._speech_enabled,
                memory_enabled=context.memory_packet is not None,
                character_story_enabled=context.character_story is not None,
            ),
            "input": [{"role": "user", "content": [{"type": "input_text", "text": prompt}]}],
            "store": False,
            "stream": True,
        }
        try:
            request_body = json.dumps(body, ensure_ascii=False, separators=(",", ":"),
                                      allow_nan=False).encode("utf-8")
        except (TypeError, ValueError, UnicodeError, RecursionError):
            raise DirectResponsesError("invalid_input", "request") from None
        if len(request_body) > self._limits.max_request_bytes:
            raise DirectResponsesError("input_limit", "request")

        # Reserve before the first await; every attempt, including auth/transport errors,
        # consumes one admitted request. There is deliberately no retry or route fallback.
        self._remaining -= 1
        try:
            async with asyncio.timeout(self._limits.startup_seconds):
                credentials = await self._credential_source.get_credentials()
                headers = self._headers(credentials)
        except asyncio.CancelledError:
            raise
        except TimeoutError:
            raise DirectResponsesError("timeout", "credentials") from None
        except DirectResponsesError:
            raise
        except Exception:
            raise DirectResponsesError("unauthenticated", "credentials") from None

        candidates: tuple | None = None
        client_timeout = httpx.Timeout(
            connect=self._limits.startup_seconds,
            read=self._limits.turn_seconds,
            write=self._limits.startup_seconds,
            pool=self._limits.startup_seconds,
        )
        try:
            async with httpx.AsyncClient(
                    transport=self._transport, follow_redirects=False,
                    timeout=client_timeout, headers={"Accept-Encoding": "identity"}) as client:
                async with asyncio.timeout(self._limits.turn_seconds):
                    async with client.stream(
                            "POST", self._endpoint, content=request_body,
                            headers=headers) as response:
                        self._check_status(response)
                        self._check_content_length(response)
                        if not _SSE_CONTENT_TYPE.fullmatch(
                                response.headers.get("content-type", "")):
                            raise DirectResponsesError("invalid_response", "response_headers",
                                                       http_status=response.status_code)
                        assembler = _ResponseAssembler(self._limits)
                        async for event in _iter_sse_events(response, self._limits):
                            assembler.consume(event)
                        texts = assembler.finish()
                        try:
                            candidates,story_proposal,affect_proposal = parse_character_candidate(
                                texts,self._limits,context,speech_enabled=self._speech_enabled)
                        except RuntimeError as error:
                            code = _payload_error_code(error)
                            mapped = ("output_limit" if code == "codex_output_limit"
                                      else "invalid_response")
                            raise DirectResponsesError(mapped, "validation") from None
        except asyncio.CancelledError:
            raise
        except DirectResponsesError:
            raise
        except (TimeoutError, httpx.TimeoutException):
            raise DirectResponsesError("timeout", "stream") from None
        except httpx.HTTPStatusError as error:
            # Status is known and safe. The provider body and headers are not retained.
            raise DirectResponsesError("unavailable", "http_status",
                                       http_status=error.response.status_code) from None
        except httpx.HTTPError:
            raise DirectResponsesError("unavailable", "transport") from None
        except (UnicodeError, json.JSONDecodeError):
            raise DirectResponsesError("invalid_response", "sse") from None
        except Exception:
            # Never stringify network exceptions: they may include request details.
            raise DirectResponsesError("unavailable", "transport") from None

        assert candidates is not None
        yield CandidateRange(candidates, f"direct-codex-responses-origin:{uuid.uuid4().hex}",
                             story_proposal,affect_proposal)

    def _headers(self, credentials: CredentialRecord) -> dict[str, str]:
        if credentials is None:
            raise DirectResponsesError("unauthenticated", "credentials")
        secret = getattr(credentials, "access_token", None)
        getter = getattr(secret, "get_secret_value", None)
        if not callable(getter):
            raise DirectResponsesError("unauthenticated", "credentials")
        try:
            token = getter()
        except Exception:
            raise DirectResponsesError("unauthenticated", "credentials") from None
        if (type(token) is not str or not token
                or any(ord(char) < 33 or ord(char) > 126 for char in token)):
            raise DirectResponsesError("unauthenticated", "credentials")

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "Originator": "mira",
            "User-Agent": "MIRA/0.4.1",
        }
        if self._route is ResponsesRoute.CHATGPT_SUBSCRIPTION:
            account_id = getattr(credentials, "account_id", None)
            residency = getattr(credentials, "residency", None)
            if account_id is not None:
                if type(account_id) is not str or not _SAFE_HEADER_VALUE.fullmatch(account_id):
                    raise DirectResponsesError("unauthenticated", "credentials")
                headers["ChatGPT-Account-ID"] = account_id
            if residency is not None:
                if type(residency) is not str or not _SAFE_HEADER_VALUE.fullmatch(residency):
                    raise DirectResponsesError("unauthenticated", "credentials")
                headers["x-openai-internal-codex-residency"] = residency
        return headers

    @staticmethod
    def _check_status(response: httpx.Response) -> None:
        status = response.status_code
        if status < 300:
            return
        if status == 401:
            code, stage = "unauthenticated", "auth"
        elif status == 403:
            code, stage = "permission_denied", "authorization"
        elif status == 429:
            code, stage = "quota_exhausted", "quota"
        elif status in (408, 504):
            code, stage = "timeout", "http_status"
        elif status in (400, 422):
            code, stage = "invalid_input", "http_status"
        elif 300 <= status < 400:
            code, stage = "unavailable", "redirect"
        elif status >= 500:
            code, stage = "unavailable", "http_status"
        else:
            code, stage = "invalid_response", "http_status"
        raise DirectResponsesError(code, stage, http_status=status)

    def _check_content_length(self, response: httpx.Response) -> None:
        raw = response.headers.get("content-length")
        if raw is None:
            return
        if not raw.isdecimal():
            raise DirectResponsesError("invalid_response", "response_headers",
                                       http_status=response.status_code)
        if int(raw) > self._limits.max_wire_bytes:
            raise DirectResponsesError("response_limit", "sse",
                                       http_status=response.status_code)


async def _iter_sse_events(response: httpx.Response,
                           limits: DirectResponsesLimits) -> AsyncIterator[_SSEEvent]:
    """Incrementally decode bounded UTF-8 SSE records, including CR/LF and multiline data."""
    pending = bytearray()
    data_lines: list[str] = []
    event_name = ""
    event_count = 0
    wire_bytes = 0
    first_line = True

    def process_line(raw: bytes) -> None:
        nonlocal event_name, first_line
        if len(raw) > limits.max_line_bytes:
            raise DirectResponsesError("response_limit", "sse")
        try:
            line = raw.decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            raise DirectResponsesError("invalid_response", "sse") from None
        if first_line:
            first_line = False
            if line.startswith("\ufeff"):
                line = line[1:]
        if not line:
            return
        if line.startswith(":"):
            return
        field, separator, value = line.partition(":")
        if not separator:
            value = ""
        elif value.startswith(" "):
            value = value[1:]
        if field == "data":
            data_lines.append(value)
        elif field == "event":
            # Event names are opaque until dispatch; the line bound constrains storage.
            event_name = value

    def dispatch() -> _SSEEvent | None:
        nonlocal event_name, event_count, data_lines
        if not data_lines and not event_name:
            return None
        event_count += 1
        if event_count > limits.max_events:
            raise DirectResponsesError("response_limit", "sse")
        event = _SSEEvent(event_name, "\n".join(data_lines))
        event_name = ""
        data_lines = []
        return event

    async for chunk in response.aiter_raw():
        wire_bytes += len(chunk)
        if wire_bytes > limits.max_wire_bytes:
            raise DirectResponsesError("response_limit", "sse")
        pending.extend(chunk)
        while True:
            lf = pending.find(b"\n")
            cr = pending.find(b"\r")
            separators = [index for index in (lf, cr) if index >= 0]
            if not separators:
                if len(pending) > limits.max_line_bytes:
                    raise DirectResponsesError("response_limit", "sse")
                break
            index = min(separators)
            if pending[index] == 13 and index == len(pending) - 1:
                if index > limits.max_line_bytes:
                    raise DirectResponsesError("response_limit", "sse")
                break
            raw_line = bytes(pending[:index])
            delim_size = 2 if pending[index] == 13 and pending[index + 1] == 10 else 1
            del pending[:index + delim_size]
            process_line(raw_line)
            if not raw_line:
                emitted = dispatch()
                if emitted is not None:
                    yield emitted

    if pending:
        if pending.endswith(b"\r"):
            raw_line = bytes(pending[:-1])
        else:
            raw_line = bytes(pending)
        process_line(raw_line)
        pending.clear()
    if data_lines or event_name:
        emitted = dispatch()
        if emitted is not None:
            yield emitted


class _ResponseAssembler:
    """Private bounded state: done message items win; deltas are fallback only."""

    _JSON_EVENT_NAMES = frozenset({
        "response.output_item.done", "response.output_item.added",
        "response.output_text.delta", "response.completed", "response.failed",
        "response.incomplete", "response.cancelled", "response.canceled",
        "response.error", "error",
    })
    _FAILURE_EVENTS = frozenset({"response.failed", "response.error", "error"})
    _INCOMPLETE_EVENTS = frozenset({
        "response.incomplete", "response.cancelled", "response.canceled",
    })

    def __init__(self, limits: DirectResponsesLimits) -> None:
        self._limits = limits
        self._completed: dict[int, _CompletedOutput] = {}
        self._deltas: dict[int, dict[int, str]] = {}
        self._delta_ids: dict[int, str] = {}
        self._terminal = False
        self._failed = False
        self._done_sentinel_seen = False

    def consume(self, sse: _SSEEvent) -> None:
        if self._done_sentinel_seen:
            raise DirectResponsesError("invalid_response", "terminal")
        if not sse.name and sse.data == "[DONE]":
            if not self._terminal:
                raise DirectResponsesError("invalid_response", "terminal")
            self._done_sentinel_seen = True
            return
        kind = sse.name
        obj: object | None = None
        if kind in self._JSON_EVENT_NAMES or not kind:
            try:
                obj = strict_json(sse.data)
            except RuntimeError:
                # Unknown named metadata events are opaque and deliberately discarded.
                if kind and kind not in self._JSON_EVENT_NAMES:
                    return
                raise DirectResponsesError("invalid_response", "sse") from None
            if not kind:
                if type(obj) is not dict or type(obj.get("type")) is not str:
                    return
                kind = obj["type"]
            if kind not in self._JSON_EVENT_NAMES and kind not in (
                    "response.created", "response.in_progress", "response.queued",
                    "response.output_text.done", "response.content_part.added",
                    "response.content_part.done", "response.refusal.delta",
                    "response.refusal.done", "response.reasoning_summary_text.delta",
                    "response.reasoning_summary_text.done", "response.reasoning_text.delta",
                    "response.reasoning_text.done", "response.output_text.annotation.added"):
                # Future event types may carry benign metadata. Count/bytes stay bounded,
                # and no event is allowed to create a candidate without a known text event.
                return
        else:
            # Opaque named events do not need a JSON shape and are safely discarded.
            return

        if type(obj) is not dict:
            raise DirectResponsesError("invalid_response", "sse")
        data_type = obj.get("type")
        if type(data_type) is str and kind in self._JSON_EVENT_NAMES and data_type != kind:
            raise DirectResponsesError("invalid_response", "sse")
        if self._terminal and kind in (
                "response.output_item.added", "response.output_item.done",
                "response.output_text.delta", "response.completed", "response.failed",
                "response.incomplete", "response.cancelled", "response.canceled",
                "response.error", "error"):
            raise DirectResponsesError("invalid_response", "terminal")
        if kind in self._FAILURE_EVENTS:
            self._failed = True
            raise DirectResponsesError("unavailable", "provider")
        if kind in self._INCOMPLETE_EVENTS:
            self._failed = True
            raise DirectResponsesError("invalid_response", "terminal")
        if kind == "response.output_item.added":
            item = obj.get("item")
            if type(item) is dict and item.get("type") in _TOOL_ITEM_TYPES:
                raise DirectResponsesError("invalid_response", "tool_forbidden")
            return
        if kind == "response.output_text.delta":
            self._consume_delta(obj)
            return
        if kind == "response.output_item.done":
            self._consume_completed_item(obj)
            return
        if kind == "response.completed":
            if self._terminal:
                raise DirectResponsesError("invalid_response", "terminal")
            response_data = obj.get("response")
            if type(response_data) is not dict:
                raise DirectResponsesError("invalid_response", "terminal")
            status = response_data.get("status")
            if status in ("failed", "error"):
                raise DirectResponsesError("unavailable", "provider")
            if status == "incomplete":
                raise DirectResponsesError("invalid_response", "terminal")
            if status not in (None, "completed"):
                raise DirectResponsesError("invalid_response", "terminal")
            if response_data.get("error") is not None:
                raise DirectResponsesError("unavailable", "provider")
            if response_data.get("output") is not None:
                snapshot_text = self._terminal_snapshot_text(response_data["output"])
                if snapshot_text != self._assembled_candidate_text():
                    raise DirectResponsesError("invalid_response", "terminal_output")
            self._terminal = True
            return

    def _consume_delta(self, obj: dict) -> None:
        index = self._output_index(obj.get("output_index"))
        content_index = obj.get("content_index", 0)
        if (type(content_index) is not int or content_index < 0 or content_index > 1_000_000
                or type(obj.get("delta")) is not str):
            raise DirectResponsesError("invalid_response", "sse")
        item_id = obj.get("item_id")
        if item_id is not None:
            self._check_item_id(item_id)
            old_id = self._delta_ids.setdefault(index, item_id)
            if old_id != item_id:
                raise DirectResponsesError("invalid_response", "sse")
        parts = self._deltas.setdefault(index, {})
        parts[content_index] = parts.get(content_index, "") + obj["delta"]
        size = sum(len(part.encode("utf-8")) for groups in self._deltas.values()
                   for part in groups.values())
        if size > self._limits.max_output_bytes:
            raise DirectResponsesError("output_limit", "sse")

    def _consume_completed_item(self, obj: dict) -> None:
        index = self._output_index(obj.get("output_index"))
        item = obj.get("item")
        if type(item) is not dict:
            raise DirectResponsesError("invalid_response", "sse")
        if item.get("type") == "reasoning":
            self._validate_reasoning_item(item, stage="output_item")
            return
        full_text = self._message_item_text(item, stage="output_item")
        item_id = item.get("id")
        if item_id is not None:
            self._check_item_id(item_id)
            delta_id = self._delta_ids.get(index)
            if delta_id is not None and delta_id != item_id:
                raise DirectResponsesError("invalid_response", "output_item")
        if index in self._completed:
            raise DirectResponsesError("invalid_response", "output_item")
        self._completed[index] = _CompletedOutput(index, item_id, full_text)

    def _terminal_snapshot_text(self, output: object) -> str:
        if type(output) is not list:
            raise DirectResponsesError("invalid_response", "terminal_output")
        if len(output) > self._limits.max_events:
            raise DirectResponsesError("response_limit", "terminal_output")
        messages = []
        for item in output:
            if type(item) is not dict:
                raise DirectResponsesError("invalid_response", "terminal_output")
            if item.get("type") == "reasoning":
                self._validate_reasoning_item(item, stage="terminal_output")
                continue
            messages.append(self._message_item_text(item, stage="terminal_output"))
        if len(messages) != 1:
            raise DirectResponsesError("invalid_response", "terminal_output")
        return messages[0]

    def _message_item_text(self, item: dict, *, stage: str) -> str:
        item_type = item.get("type")
        if item_type in _TOOL_ITEM_TYPES:
            raise DirectResponsesError("invalid_response", "tool_forbidden")
        if item_type != "message":
            raise DirectResponsesError("invalid_response", stage)
        if item.get("role") not in (None, "assistant"):
            raise DirectResponsesError("invalid_response", stage)
        if item.get("status") not in (None, "completed"):
            raise DirectResponsesError("invalid_response", stage)
        item_id = item.get("id")
        if item_id is not None:
            self._check_item_id(item_id)
        content = item.get("content")
        if type(content) is not list:
            raise DirectResponsesError("invalid_response", stage)
        if len(content) > self._limits.max_events:
            raise DirectResponsesError("response_limit", stage)
        texts = []
        for part in content:
            if type(part) is not dict:
                raise DirectResponsesError("invalid_response", stage)
            if part.get("type") != "output_text" or type(part.get("text")) is not str:
                raise DirectResponsesError("invalid_response", stage)
            texts.append(part["text"])
        full_text = "".join(texts)
        if not full_text:
            raise DirectResponsesError("invalid_response", stage)
        if len(full_text.encode("utf-8")) > self._limits.max_output_bytes:
            raise DirectResponsesError("output_limit", stage)
        return full_text

    def _validate_reasoning_item(self, item: dict, *, stage: str) -> None:
        """Validate known non-candidate reasoning structure, without retaining its text."""
        if item.get("status") not in (None, "completed"):
            raise DirectResponsesError("invalid_response", stage)
        item_id = item.get("id")
        if item_id is not None:
            self._check_item_id(item_id)
        encrypted_content = item.get("encrypted_content")
        if encrypted_content is not None and type(encrypted_content) is not str:
            raise DirectResponsesError("invalid_response", stage)
        for field, allowed_types in (
                ("summary", frozenset({"summary_text"})),
                ("content", frozenset({"reasoning_text", "summary_text"}))):
            parts = item.get(field)
            if parts is None:
                continue
            if type(parts) is not list:
                raise DirectResponsesError("invalid_response", stage)
            if len(parts) > self._limits.max_events:
                raise DirectResponsesError("response_limit", stage)
            for part in parts:
                if (type(part) is not dict or part.get("type") not in allowed_types
                        or type(part.get("text")) is not str):
                    raise DirectResponsesError("invalid_response", stage)

    def _assembled_candidate_text(self) -> str:
        if self._completed:
            if len(self._completed) != 1 or set(self._deltas) - set(self._completed):
                raise DirectResponsesError("invalid_response", "terminal_output")
            return next(iter(self._completed.values())).text
        if len(self._deltas) != 1:
            raise DirectResponsesError("invalid_response", "terminal_output")
        index, parts = next(iter(self._deltas.items()))
        text = "".join(parts[part] for part in sorted(parts))
        if not text:
            raise DirectResponsesError("invalid_response", "terminal_output")
        return text

    @staticmethod
    def _output_index(value: object) -> int:
        if type(value) is not int or not 0 <= value <= 1_000_000:
            raise DirectResponsesError("invalid_response", "sse")
        return value

    @staticmethod
    def _check_item_id(value: object) -> None:
        if (type(value) is not str or not value or len(value) > 256
                or any(ord(char) < 33 or ord(char) > 126 for char in value)):
            raise DirectResponsesError("invalid_response", "sse")

    def finish(self) -> list[str]:
        if not self._terminal:
            raise DirectResponsesError("invalid_response", "incomplete_stream")
        if self._failed:
            raise DirectResponsesError("invalid_response", "terminal")
        if self._completed:
            # A complete item is authoritative. Every text delta seen must refer to one of
            # those completed item indexes; no unfinished second answer is accepted.
            if set(self._deltas) - set(self._completed):
                raise DirectResponsesError("invalid_response", "incomplete_output")
            ordered = [self._completed[key].text for key in sorted(self._completed)]
        else:
            if not self._deltas:
                raise DirectResponsesError("invalid_response", "output_missing")
            ordered = ["".join(self._deltas[index][part]
                               for part in sorted(self._deltas[index]))
                       for index in sorted(self._deltas)]
        if len(ordered) != 1 or not ordered[0]:
            raise DirectResponsesError("invalid_response", "output_multiple")
        if len(ordered[0].encode("utf-8")) > self._limits.max_output_bytes:
            raise DirectResponsesError("output_limit", "validation")
        return ordered
