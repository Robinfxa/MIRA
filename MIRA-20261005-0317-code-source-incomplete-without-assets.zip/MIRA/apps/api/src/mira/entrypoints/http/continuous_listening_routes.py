"""Authenticated, one-stream-per-lease continuous listening WebSocket."""
import asyncio
import base64
from dataclasses import replace
import binascii
import json
from urllib.parse import urlsplit
from uuid import UUID, uuid4

from fastapi import APIRouter, WebSocket
from pydantic import ValidationError
from starlette.websockets import WebSocketDisconnect

from mira.application.continuous_listening import ListeningEvent, ListeningLease
from mira.application.diagnostic_events import request_correlation
from mira.domain.errors import DomainError
from mira.entrypoints.http.schemas import (
    ContinuousListeningAudio, ContinuousListeningEndpointPending,
    ContinuousListeningReady, ContinuousListeningStart, ContinuousListeningStop,
    ContinuousListeningStopped, ContinuousListeningTranscript,
    ContinuousListeningCommit, ContinuousListeningCommitReady,
    ContinuousListeningCommitRejected,
)

router = APIRouter()


def _no_duplicate_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON field")
        result[key] = value
    return result


async def _message(websocket: WebSocket, *, timeout: float = 10) -> dict:
    async with asyncio.timeout(timeout):
        raw = await websocket.receive()
    if raw["type"] == "websocket.disconnect":
        raise WebSocketDisconnect(raw.get("code", 1000))
    text = raw.get("text")
    if not isinstance(text, str) or len(text) > 20_000:
        raise DomainError("invalid_input", "Expected a bounded JSON listening message.")
    try:
        value = json.loads(text, object_pairs_hook=_no_duplicate_pairs)
    except (ValueError, RecursionError):
        raise DomainError("invalid_input", "Invalid listening message.") from None
    if not isinstance(value, dict):
        raise DomainError("invalid_input", "Invalid listening message.")
    return value


def _origin_host_allowed(websocket: WebSocket) -> bool:
    container = websocket.app.state.container
    origin = websocket.headers.get("origin")
    host = websocket.headers.get("host")
    if not isinstance(origin, str) or not isinstance(host, str):
        return False
    if origin not in container.settings.http.allowed_origins:
        return False
    try:
        expected_host = urlsplit(origin).netloc
    except ValueError:
        return False
    allowed_hosts = {urlsplit(value).netloc for value in container.settings.http.allowed_origins}
    # TestClient's host is accepted only for offline ASGI tests, not configured deployments.
    if host.lower() == "testserver":
        return container.settings.environment == "test" and origin.startswith("http://")
    return host.lower() == expected_host.lower() and host.lower() in {item.lower() for item in allowed_hosts}


def _usage_budget(websocket: WebSocket) -> tuple[int | None, int | None]:
    container = websocket.app.state.container
    budget = getattr(container, "stt_request_budget", None)
    if budget is None:
        return None, None
    snapshot = budget.snapshot()
    declaration = getattr(websocket.app.state, "usage_declaration", None)
    declared_limit = getattr(declaration, "stt_requests", None)
    if declared_limit is not None and declared_limit != snapshot.limit:
        raise DomainError("unavailable", "STT request declaration does not match its shared budget.")
    current = getattr(websocket.app.state, "usage_snapshot", None)
    if declaration is not None and current is not None:
        try:
            websocket.app.state.usage_snapshot = replace(current, stt_requests_used=snapshot.used)
        except (TypeError, ValueError):
            # A malformed optional telemetry snapshot never weakens the actual request counter.
            pass
    return snapshot.used, snapshot.remaining


def _wire_event(event: ListeningEvent):
    if event.type == "transcript":
        return ContinuousListeningTranscript(lease_id=UUID(event.lease_id), revision=event.revision,
            text=event.text or "", is_final=bool(event.is_final))
    if event.type == "endpoint_pending":
        reason = event.reason if event.reason in {"missing_result_offset", "unmatched_activity_end"} else "missing_result_offset"
        return ContinuousListeningEndpointPending(lease_id=UUID(event.lease_id),
            revision=event.revision, text=event.text or "", reason=reason,
            can_submit_manually=True)
    if event.type == "stopped":
        allowed = {"user_stop", "permission_lost", "replaced", "max_duration", "max_samples",
            "queue_limit", "revision_limit", "utterance_limit", "provider_stream_ended",
            "unavailable", "invalid_input", "invalid_response", "session_closed", "disconnect",
            "output_limit", "session_capacity", "microphone_unavailable", "input_limit", "invalid_audio",
            "timeout", "unauthenticated", "permission_denied", "quota_exhausted", "media_cancelled",
            "incomplete_stream", "blocked", "response_limit"}
        reason = event.reason if event.reason in allowed else "unavailable"
        return ContinuousListeningStopped(lease_id=UUID(event.lease_id), reason=reason,
                                          diagnostic_id=event.diagnostic_id)
    raise DomainError("invalid_response", "Invalid listening event.")


@router.websocket("/api/v1/sessions/{session_id}/continuous-listening")
async def continuous_listening(websocket: WebSocket, session_id: str) -> None:
    """Begin one authorized stream only after a session-scoped start frame is validated."""
    if not _origin_host_allowed(websocket) or websocket.query_params or len(session_id) > 64:
        await websocket.close(code=1008)
        return
    try:
        parsed_session_id = str(UUID(session_id))
    except ValueError:
        await websocket.close(code=1008)
        return
    await websocket.accept()
    correlation = request_correlation.set(str(uuid4()))
    container = websocket.app.state.container
    registry = container.listening_leases
    lease: ListeningLease | None = None
    receive_task: asyncio.Task | None = None
    event_task: asyncio.Task | None = None
    close_reason = "disconnect"
    try:
        try:
            start = ContinuousListeningStart.model_validate(await _message(websocket, timeout=5))
        except (DomainError, ValidationError, TimeoutError):
            await websocket.close(code=1008)
            return
        # Token is in the first frame, never URL/query/logs. Authentication and capability
        # checks happen before the recognition task can open a provider stream.
        try:
            container.sessions.get(parsed_session_id, start.session_token)
        except DomainError:
            await websocket.close(code=1008)
            return
        backend = container.continuous_speech_recognition
        if backend is None or registry.limits.max_seconds < 1:
            await websocket.send_text(ContinuousListeningStopped(
                lease_id=start.lease_id, reason="microphone_unavailable").model_dump_json())
            await websocket.close(code=1008)
            return
        try:
            stt_used, stt_remaining = _usage_budget(websocket)
            if stt_remaining == 0:
                await websocket.send_text(ContinuousListeningStopped(
                    lease_id=start.lease_id, reason="input_limit").model_dump_json())
                await websocket.close(code=1008)
                return
            lease = await registry.start(parsed_session_id, str(start.lease_id))
        except DomainError as error:
            reason = "session_capacity" if error.code == "session_capacity" else "invalid_input"
            await websocket.send_text(ContinuousListeningStopped(
                lease_id=start.lease_id, reason=reason).model_dump_json())
            await websocket.close(code=1008)
            return

        limits = registry.limits
        effective_seconds = limits.max_seconds
        backend_seconds = getattr(backend, "max_stream_seconds", None)
        declaration = getattr(websocket.app.state, "usage_declaration", None)
        declared_seconds = getattr(declaration, "stt_max_stream_seconds", None)
        caps = [value for value in (backend_seconds, declared_seconds)
                if type(value) in (int, float) and value > 0]
        if caps:
            effective_seconds = min(effective_seconds, int(min(caps)))
        if effective_seconds < 1:
            await registry.stop_lease(lease, "microphone_unavailable")
            await websocket.send_text(ContinuousListeningStopped(
                lease_id=start.lease_id, reason="microphone_unavailable").model_dump_json())
            return
        effective_samples = min(limits.max_samples, effective_seconds * 16_000)
        endpoint_mode = "google_vad_offsets_manual_commit" if getattr(
            backend, "endpoint_mode", None) == "google_vad_offsets" else "unavailable_manual"
        await websocket.send_text(ContinuousListeningReady(
            lease_id=start.lease_id,
            max_seconds=effective_seconds,
            max_samples=effective_samples,
            max_utterances=limits.max_utterances,
            max_streams_per_session=limits.max_streams_per_session,
            max_total_streams=limits.max_total_streams,
            session_lease_starts_used=registry.lease_starts_for_session(parsed_session_id),
            total_lease_starts_used=registry.total_lease_starts,
            stt_requests_used=stt_used,
            stt_requests_remaining=stt_remaining,
            endpoint_mode=endpoint_mode,
            manual_commit_required=True,
        ).model_dump_json())
        lease._recognition_task = asyncio.create_task(lease.recognize(backend,
            is_current=registry.is_current, register_utterance=registry.register_utterance))
        loop = asyncio.get_running_loop()
        deadline = loop.time() + effective_seconds
        while True:
            remaining = deadline - loop.time()
            if remaining <= 0 and lease.active:
                close_reason = "max_duration"
                await registry.stop_lease(lease, close_reason)
                continue
            receive_task = asyncio.create_task(_message(websocket))
            event_task = asyncio.create_task(lease.events.get())
            done, pending = await asyncio.wait((receive_task, event_task), timeout=max(0.1, remaining),
                                               return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
            completed_receive, completed_event = receive_task, event_task
            receive_task = event_task = None
            if not done:
                close_reason = "max_duration"
                await registry.stop_lease(lease, close_reason)
                continue
            if completed_event in done:
                event = completed_event.result()
                if event.type != "stopped" and not registry.is_current(lease):
                    continue
                _usage_budget(websocket)
                await websocket.send_text(_wire_event(event).model_dump_json())
                if event.type == "stopped":
                    close_reason = event.reason or close_reason
                    break
            if completed_receive in done:
                try:
                    raw = completed_receive.result()
                    if raw.get("type") == "audio":
                        chunk = ContinuousListeningAudio.model_validate(raw)
                        if str(chunk.lease_id) != lease.lease_id:
                            raise DomainError("stale_stream", "Audio belongs to another listening lease.")
                        try:
                            pcm = base64.b64decode(chunk.pcm_base64, validate=True)
                        except (ValueError, binascii.Error):
                            raise DomainError("invalid_audio", "Invalid PCM encoding.") from None
                        try:
                            lease.audio.push(lease_id=lease.lease_id, sequence=chunk.sequence,
                                first_sample=chunk.first_sample, pcm=pcm)
                            _usage_budget(websocket)
                        except DomainError as error:
                            close_reason = "max_samples" if error.code == "input_limit" and (
                                lease.audio.samples + len(pcm) // 2 > limits.max_samples) else (
                                    "queue_limit" if "queue" in error.message.lower() else error.code)
                            await registry.stop_lease(lease, close_reason)
                    elif raw.get("type") == "stop":
                        control = ContinuousListeningStop.model_validate(raw)
                        if str(control.lease_id) != lease.lease_id:
                            raise DomainError("stale_stream", "Stop belongs to another listening lease.")
                        close_reason = control.reason
                        await registry.stop_lease(lease, close_reason)
                    elif raw.get("type") == "commit":
                        control = ContinuousListeningCommit.model_validate(raw)
                        if str(control.lease_id) != lease.lease_id:
                            raise DomainError("stale_stream", "Commit belongs to another listening lease.")
                        try:
                            result = await lease.manual_commit(commit_id=str(control.commit_id),
                                revision=control.revision, registry=registry)
                            delivered = await registry.mark_delivered(parsed_session_id,
                                lease.lease_id, result.commit_id)
                            if not delivered:
                                raise DomainError("media_cancelled", "Listening commit was revoked.")
                            await websocket.send_text(ContinuousListeningCommitReady(
                                lease_id=UUID(result.lease_id), commit_id=UUID(result.commit_id),
                                segment_seq=result.segment_seq, revision=result.revision,
                                text=result.text).model_dump_json())
                        except DomainError as error:
                            reasons = {"transcript_stale": "stale_revision",
                                       "transcript_empty": "no_final_text",
                                       "session_capacity": "request_limit",
                                       "media_cancelled": "lease_revoked",
                                       "request_conflict": "identity_conflict"}
                            await websocket.send_text(ContinuousListeningCommitRejected(
                                lease_id=UUID(lease.lease_id), commit_id=control.commit_id,
                                reason=reasons.get(error.code, "lease_revoked"),
                                current_revision=lease.revision).model_dump_json())
                            if error.code == "session_capacity":
                                close_reason = "utterance_limit"
                                await registry.stop_lease(lease, close_reason)
                    else:
                        raise DomainError("invalid_input", "Unsupported listening control message.")
                except (ValidationError, DomainError):
                    close_reason = "invalid_input"
                    await registry.stop_lease(lease, close_reason)
    except WebSocketDisconnect:
        close_reason = "disconnect"
    except asyncio.CancelledError:
        close_reason = "session_closed"
        raise
    except Exception:
        close_reason = "unavailable"
    finally:
        for task in (receive_task, event_task):
            if task is not None and not task.done():
                task.cancel()
        if receive_task is not None or event_task is not None:
            await asyncio.gather(*(task for task in (receive_task, event_task) if task is not None),
                                 return_exceptions=True)
        if lease is not None:
            if lease.active:
                await registry.stop_lease(lease, close_reason)
            if lease._recognition_task is not None:
                await asyncio.wait({lease._recognition_task}, timeout=.25)
        try:
            await websocket.close(code=1000)
        except Exception:
            pass
        request_correlation.reset(correlation)
