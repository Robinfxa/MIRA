import { loadPublicConfig } from '../shared/config.js';
import { SceneEffectExecutor } from '../features/presentation/scene-executor.js';
import { MiraApiClient, MiraHttpError } from '../features/session/api-client.js';
import { SessionController } from '../features/session/controller.js';
import { ContinuousListeningController } from '../features/session/continuous-listening.js';
import type { MicrophoneTimingSnapshot, MicrophoneTranscriptRevision } from '../features/session/ports.js';
import type { ContinuousListeningView } from '../features/session/continuous-listening.js';
import { recordingNotice, safeSessionError, watchDiagnosticsStatus } from '../features/diagnostics/status.js';
import { ReviewedAudioPanel } from '../features/diagnostics/reviewed-audio.js';
import { mountOperatorPairing } from '../features/session/operator-pairing.js';
import type { OperatorPairingApp, OperatorPairingGate } from '../features/session/operator-pairing.js';
import { mountMemoryManagement } from '../features/session/memory-management.js';
import type { MemoryManagementApp } from '../features/session/memory-management.js';

let operatorGate: OperatorPairingGate | null = null;
let memoryManagement: MemoryManagementApp | null = null;

function startSessionApp(): OperatorPairingApp {
if (document.body?.dataset['operatorPairing'] === 'required'
  && document.body.dataset['memoryManagement'] === 'enabled') {
  memoryManagement = mountMemoryManagement(document);
}
function element<T extends HTMLElement>(selector: string): T {
  const value = document.querySelector<T>(selector);
  if (!value) throw new Error(`Missing application element ${selector}`);
  return value;
}
const microphonePreview = element<HTMLElement>('[data-microphone-preview]');
const microphoneTimingPanel = element<HTMLDetailsElement>('[data-microphone-timing-panel]');
const microphoneTiming = element<HTMLOutputElement>('[data-microphone-timing]');
const config = loadPublicConfig();
const status = element('[data-status]');
const diagnostic = element('[data-diagnostic]');
const error = element('[data-error]');
const stage = element<HTMLElement>('[data-stage]');
const backgroundChoice = document.querySelector<HTMLSelectElement>('[data-background-choice]');
if (backgroundChoice) {
  const applyBackgroundChoice = (): void => {
    stage.dataset['backgroundVersion'] = backgroundChoice.value === 'painterly-v3' ? 'painterly-v3' : 'classic';
  };
  backgroundChoice.addEventListener('change', applyBackgroundChoice);
  applyBackgroundChoice();
}
const systemNoticeRegion = document.querySelector<HTMLElement>('[data-system-notice]');
const systemNoticeBody = document.querySelector<HTMLElement>('[data-system-notice-body]');
const ptt = element<HTMLButtonElement>('[data-ptt]');
const continuousButton = element<HTMLButtonElement>('[data-continuous-listening]');
const continuousPanel = element<HTMLElement>('[data-continuous-panel]');
const continuousStatus = element<HTMLElement>('[data-continuous-status]');
const continuousPreview = element<HTMLElement>('[data-continuous-preview]');
const continuousSend = element<HTMLButtonElement>('[data-continuous-send]');
const continuousInterrupt = element<HTMLButtonElement>('[data-continuous-interrupt]');
const continuousSentText = element<HTMLOListElement>('[data-continuous-sent-text]');
const continuousRecordingLimit = element<HTMLElement>('[data-continuous-recording-limit]');
const continuousReviewBlock = element<HTMLElement>('[data-continuous-review-block]');
const messageInput = element<HTMLInputElement>('[name=message]');
const sendMessage = element<HTMLButtonElement>('[data-send-message]');
const connectRetry = element<HTMLButtonElement>('[data-connect-retry]');
const connectionStatus = element<HTMLElement>('[data-connection-status]');
const voiceHint = element('[data-voice-hint]');
const recordingBanner = element('[data-recording-notice]');
const rehearsalButton = element<HTMLButtonElement>('[data-rehearsal-input]');
const rehearsalHint = element('[data-rehearsal-hint]');
let rehearsalAvailable = false;
let rehearsalHeld: string | null = null;
let gestureReviewFence: (() => void) | null = null;
let rehearsalReviewFence: (() => void) | null = null;
const diagnosticsWatcher = watchDiagnosticsStatus(config, value => {
  const notice = recordingNotice(value);
  recordingBanner.hidden = !notice.visible;
  recordingBanner.textContent = notice.text;
  recordingBanner.dataset['recordingState'] = notice.state;
});
let microphoneAvailable = false;
let continuousAvailable = false;
let reviewCanEnable = false;
let continuous: ContinuousListeningController | null = null;
let held: string | null = null;
let gestureInputRevision = 0;
let rehearsalInputRevision = 0;
let messageRevision = 0;
let messageCompositionActive = false;
let closed = false;
let connected = false;
let connecting = false;
function showConnection(state: 'connecting' | 'ready' | 'failed' | 'closed'): void {
  connected = state === 'ready';
  element<HTMLFieldSetElement>('fieldset').disabled = false;
  messageInput.disabled = false;
  sendMessage.disabled = !connected;
  connectRetry.disabled = state === 'connecting' || connected || state === 'closed';
  connectRetry.hidden = connected;
  connectionStatus.dataset['connectionState'] = state;
  connectionStatus.textContent = {
    connecting: '正在连接本地服务。可以先写草稿，连接后才能发送。',
    ready: '已连接，可以发送。',
    failed: '连接未成功。草稿仍保留；处理下面的问题后点击重试连接。',
    closed: '会话已关闭。草稿仍保留在当前页面。',
  }[state];
  for (const button of document.querySelectorAll<HTMLButtonElement>('[data-command]')) button.disabled = !connected;
  if (!connected) {
    ptt.disabled = true; rehearsalButton.disabled = true; continuousButton.disabled = true;
    continuousSend.disabled = true; continuousInterrupt.disabled = true;
  }
}
let reviewPanel: ReviewedAudioPanel | null = null;
const api = new MiraApiClient(config);
messageInput.addEventListener('input', () => { messageRevision++; });
messageInput.addEventListener('compositionstart', () => { messageCompositionActive = true; });
messageInput.addEventListener('compositionend', () => { messageCompositionActive = false; });
messageInput.addEventListener('keydown', event => {
  if (event.key === 'Enter' && (messageCompositionActive || event.isComposing || event.keyCode === 229)) {
    event.preventDefault();
  }
});
function restoreNotSent(outcome: {status?: string; text?: string} | undefined, revision: number,
    expectedText?: string): void {
  if (outcome?.status !== 'not-sent' || typeof outcome.text !== 'string'
    || messageRevision !== revision || messageInput.value !== '') return;
  if (expectedText !== undefined && outcome.text !== expectedText) return;
  messageInput.value = outcome.text;
}
function defaultVoiceHint(): string {
  if (!microphoneAvailable) return '麦克风识别未配置或浏览器不支持。可以继续用文字。';
  return continuousAvailable
    ? '连续聆听是默认语音方式：点击开始后持续听，包括安静时段。临时转写不会自动发送；发送时会先结束监听。'
    : '按住说话是备用输入方式，松开后等待可靠转写。停止会立即释放麦克风。';
}
const sceneExecutor = new SceneEffectExecutor(stage, {
  characterRendererMode: document.body?.dataset['characterRenderer'] === 'code-native-review'
    ? 'code-native-review' : 'static-pixi',
});
const controller = new SessionController(
  api, sceneExecutor, {
    connected() {
      if (closed) return;
      showConnection('ready');
      reviewPanel?.start();
    },
    update(view) {
      status.textContent = view.phase;
      diagnostic.textContent = JSON.stringify({
        state: view.revision, activity: view.activity_seq, output: view.output_epoch,
        permit: view.permit_revision, grants: view.active_grants.length,
        presented: view.presented_effects.length, audioFacts: view.audio_progress.length, sealed: view.sealed,
      }, null, 2);
      if (view.last_error === 'review_uncertain') error.textContent = '';
      else if (view.last_error) error.textContent = safeSessionError(view.last_error, view.last_error_diagnostic_id);
    },
    error(message) { error.textContent = message; },
    systemNotice(notice) {
      if (!systemNoticeRegion || !systemNoticeBody) return;
      systemNoticeRegion.hidden = notice === null;
      systemNoticeBody.textContent = notice?.body ?? '';
    },
    localStop() { status.textContent = 'stopped · 本地已制止'; },
    capabilities(value) {
      if (closed) return;
      microphoneAvailable = value.microphone_enabled && typeof navigator.mediaDevices?.getUserMedia === 'function'
        && typeof globalThis.AudioContext === 'function' && typeof globalThis.AudioWorkletNode === 'function' && globalThis.isSecureContext;
      const continuousCapability = (value as typeof value & {readonly continuous_listening_enabled?: boolean}).continuous_listening_enabled === true;
      continuousAvailable = microphoneAvailable && continuousCapability && value.generation_mode !== 'rehearsal';
      continuousButton.hidden = !continuousAvailable;
      continuousPanel.hidden = !continuousAvailable;
      ptt.disabled = !microphoneAvailable || Boolean(continuous?.active);
      const modes = {mock: 'Mock · 固定场景', replay: 'Fixture · 生成夹具回放', rehearsal: 'OFFLINE · 离线排练', injected: '注入后端 · 尚未验收'};
      element('[data-mode-label]').textContent = modes[value.generation_mode];
      rehearsalAvailable = value.generation_mode === 'rehearsal' && value.qualification === 'offline_fixture';
      reviewCanEnable = value.generation_mode === 'injected' && (value.microphone_enabled || value.speech_enabled);
      reviewPanel?.setCanEnable(reviewCanEnable);
      element('[data-rehearsal-banner]').hidden = !rehearsalAvailable;
      element('[data-rehearsal-controls]').hidden = !rehearsalAvailable;
      rehearsalButton.disabled = !rehearsalAvailable;
      element('[data-mode-description]').textContent = rehearsalAvailable
        ? 'OFFLINE 离线排练：固定口令、预先制作的英文合成音频与双语字幕。没有调用真实模型或 Google 服务；不识别自由对话，不采集麦克风。插画为原创本地矢量素材。字幕按整句语音 cue 呈现，不是逐字对齐，也不能证明用户听见。'
        : `${modes[value.generation_mode]}。${value.qualification === 'unavailable'
        ? '真实语音尚未配置，当前使用文字。' : '语音后端已注入；账户、扬声器、麦克风与真实打断仍需单独验收。'}角色与旅行插画是本地原创素材，不代表实时生图。字幕显示不代表已经听见或逐字对齐。`;
      voiceHint.textContent = defaultVoiceHint();
    },
    rehearsalInput(state) {
      rehearsalButton.setAttribute('aria-pressed', String(state === 'listening'));
      if (state === 'stopped') rehearsalHeld = null;
      rehearsalHint.textContent = state === 'listening'
        ? '正在演练 listening 状态，没有录音或识别。松开只会发送固定口令「照片里有什么」。'
        : '合成输入演练：按住观察 listening；松开发送固定口令「照片里有什么」。不打开麦克风。';
    },
    microphone(state) {
      ptt.setAttribute('aria-pressed', String(state === 'recording' || state === 'starting'));
      voiceHint.textContent = state === 'starting' ? '正在打开麦克风；请在浏览器中自行决定是否授权。'
        : state === 'recording' ? '正在听。识别内容会显示为未发送的用户输入预览；松开后才等待最终转写。'
        : state === 'finishing' ? '录音已停止，正在等待可靠的最终转写…' : defaultVoiceHint();
    },
    microphonePreview(revision: MicrophoneTranscriptRevision | null) {
      if (revision === null) { microphonePreview.textContent = ''; microphonePreview.hidden = true; return; }
      const qualifier = revision.is_final ? '（片段已定稿，整轮仍未完成）' : '（仍在变化）';
      microphonePreview.textContent = `用户输入临时预览${qualifier}，未发送：${revision.text.slice(0, 2000)}`;
      microphonePreview.hidden = false;
    },
    microphoneTiming(value: MicrophoneTimingSnapshot | null) {
      if (value === null) { microphoneTiming.textContent = ''; microphoneTimingPanel.hidden = true; return; }
      // This surface contains only an ephemeral stream ID, numeric stage deltas and counts.
      microphoneTiming.textContent = JSON.stringify(value, null, 2);
      microphoneTimingPanel.hidden = false;
    },
    reviewAudition(state) { reviewPanel?.auditionState(state); },
  }, config, {
    onGlobalStop() { void continuous?.stop('user_stop'); },
    externalMicrophoneActive: () => continuous?.microphoneActive === true,
  },
);
reviewPanel = new ReviewedAudioPanel(api, controller, {
  notice: element('[data-review-audio-notice]'),
  status: element('[data-review-audio-status]'),
  scope: element('[data-review-audio-scope]'),
  eligibilityNotice: element('[data-review-audio-eligibility]'),
  consent: element<HTMLInputElement>('[data-review-audio-consent]'),
  enable: element<HTMLButtonElement>('[data-review-audio-enable]'),
  disable: element<HTMLButtonElement>('[data-review-audio-disable]'),
  review: element<HTMLButtonElement>('[data-review-audio-review]'),
  clip: element('[data-review-audio-clip]'),
  clipMetadata: element('[data-review-audio-clip-metadata]'),
  preview: element<HTMLButtonElement>('[data-review-audio-preview]'),
  audition: element<HTMLButtonElement>('[data-review-audio-audition]'),
  auditionStatus: element('[data-review-audio-audition-status]'),
  attestation: element<HTMLInputElement>('[data-review-audio-attestation]'),
  confirm: element<HTMLButtonElement>('[data-review-audio-confirm]'),
  cancel: element<HTMLButtonElement>('[data-review-audio-cancel]'),
  result: element('[data-review-audio-result]'),
});
reviewPanel.setCanEnable(false);
function renderContinuous(view: ContinuousListeningView): void {
  const active = view.state === 'starting' || view.state === 'listening' || view.state === 'stopping';
  continuousButton.setAttribute('aria-pressed', String(active));
  continuousButton.textContent = active ? '停止连续聆听' : '点击开始连续聆听';
  const startsExhausted = view.ready !== null
    && (view.ready.session_lease_starts_used >= view.ready.max_streams_per_session
      || view.ready.total_lease_starts_used >= view.ready.max_total_streams);
  const previousPreviews = view.previous_previews ?? [];
  const previousPreviewsFull = previousPreviews.length >= (view.previous_preview_limit ?? 4);
  continuousButton.disabled = !continuousAvailable || view.state === 'stopping'
    || (!active && (controller.microphoneBusy || reviewPanel?.recordingActive === true || startsExhausted || previousPreviewsFull));
  ptt.disabled = !microphoneAvailable || active || controller.microphoneBusy;
  continuousPanel.hidden = !continuousAvailable;
  continuousInterrupt.hidden = !active;
  continuousInterrupt.disabled = !active || view.state === 'stopping';
  continuousRecordingLimit.hidden = !active;
  continuousReviewBlock.hidden = !active;
  reviewPanel?.setContinuousListeningBlocked(active);
  const stateText: Record<ContinuousListeningView['state'], string> = {
    idle: '连续聆听尚未开始。',
    starting: '正在请求麦克风并建立连续聆听；点击停止会立即释放麦克风。',
    listening: '正在聆听。安静时段也会持续采集；临时转写不会自动发送。',
    stopping: '正在关闭本条聆听；麦克风已先行释放。',
    stopped: '连续聆听已停止。已收到的文字仍保留，可继续核对。',
    limit: '本条连续聆听已到达声明上限。不会自动续开；继续前请再次点击开始。',
    error: view.error ?? '连续聆听遇到问题；麦克风已释放。',
    closed: '会话已关闭；未发送文字仍保留在当前页面。',
  };
  const readyText = view.ready === null ? '' : `本条监听最多 ${view.ready.max_seconds} 秒、${view.ready.max_utterances} 次手动发送。连接开始快照：本会话已启动 ${view.ready.session_lease_starts_used}/${view.ready.max_streams_per_session} 次；服务范围已启动 ${view.ready.total_lease_starts_used}/${view.ready.max_total_streams} 次。${typeof view.ready.stt_requests_used === 'number' && typeof view.ready.stt_requests_remaining === 'number'
    ? `共享 STT 额度快照：已用 ${view.ready.stt_requests_used}，可用 ${view.ready.stt_requests_remaining}。`
    : '共享 STT 额度快照不可用，剩余额度未知。'}这些是数量上限和连接时快照，不是费用额度，也不代表连接后的累计用量。`;
  const endpointText = view.ready?.endpoint_mode === 'unavailable_manual'
    ? '自动语句端点不可用；仅显示转写，手动发送仍需服务端确认。' : '';
  continuousStatus.textContent = [stateText[view.state], readyText, endpointText, view.notice, view.error]
    .filter(Boolean).join(' ');
  const transcript = view.transcript?.lease_id === view.lease_id ? view.transcript : null;
  continuousPreview.hidden = transcript === null;
  continuousPreview.textContent = transcript === null ? '' :
    `${transcript.endpoint_pending ? '句末未对齐' : transcript.is_final ? '稳定片段' : '临时转写'} · 修订 ${transcript.revision} · 未发送：${transcript.text}${transcript.truncated ? '（仅显示前 2,000 字符，此内容不可直接发送）' : ''}${transcript.hint ? ` ${transcript.hint}` : ''}`;
  continuousSend.disabled = !continuousAvailable || view.state !== 'listening' || transcript?.can_send !== true;
  if (previousPreviewsFull && !active) {
    continuousStatus.textContent += ' 历史预览已满；先把一段放入空文字框并核对，释放空间后才能再次开始。';
  }
  continuousSentText.replaceChildren();
  continuousSentText.setAttribute('aria-label', '上次未发送预览与手动发送记录');
  for (const preview of previousPreviews) {
    const li = document.createElement('li');
    const label = document.createElement('span');
    const kind = preview.endpoint_pending ? '句末未对齐' : preview.is_final ? '稳定转写' : '临时转写';
    label.textContent = `上次聆听预览 · ${kind} · 修订 ${preview.revision} · 请核对（可能与下方已确认文字重叠，不会自动发送）：${preview.text}${preview.truncated ? '（仅显示前 2,000 字符）' : ''}`;
    const restore = document.createElement('button');
    restore.type = 'button'; restore.textContent = '放入空文字框（仍需核对和手动发送）';
    restore.addEventListener('click', () => {
      if (messageInput.value !== '') { error.textContent = '文字输入框已有内容，未覆盖；请先核对后再决定。'; messageInput.focus(); return; }
      const restored = continuous?.restorePreviousPreview(preview.lease_id);
      if (restored === null || restored === undefined) { error.textContent = '这段预览已不在保留列表中，请核对页面当前文字。'; return; }
      messageInput.value = restored; messageRevision++; messageInput.focus();
    });
    li.append(label, restore); continuousSentText.append(li);
  }
  for (const item of view.sent_text) {
    const li = document.createElement('li');
    const label = document.createElement('span');
    const states = {sending: '正在提交', sent: '已提交', not_sent: '未送出', unknown: '结果不确定'};
    label.textContent = `${states[item.state]} · 已确定文字：${item.text}${item.notice ? ` · ${item.notice}` : ''}`;
    li.append(label);
    if (item.state === 'not_sent') {
      const restore = document.createElement('button');
      restore.type = 'button'; restore.textContent = '放入文字框（仍需手动发送）';
      restore.addEventListener('click', () => {
        if (messageInput.value !== '') { error.textContent = '文字输入框已有内容，未覆盖；请先核对后再决定。'; messageInput.focus(); return; }
        messageInput.value = item.text; messageRevision++; messageInput.focus();
      });
      li.append(restore);
    }
    continuousSentText.append(li);
  }
}
continuous = new ContinuousListeningController({
  openStream: (leaseId, signal, observers) => api.continuousListening(leaseId, signal, observers),
  submitInput: (text, listeningUtteranceId) => controller.input(text, undefined, listeningUtteranceId),
  canStart: () => continuousAvailable && microphoneAvailable && !controller.microphoneBusy
    && reviewPanel?.recordingActive !== true && !closed,
  interruptReply: () => controller.interruptReply(),
  onPhase: listening => controller.setContinuousListeningPhase(listening),
  onUpdate: renderContinuous,
});
continuousButton.addEventListener('click', () => {
  if (!continuous) return;
  error.textContent = '';
  if (continuous.active) void continuous.stop('user_stop');
  else continuous.start();
});
continuousSend.addEventListener('click', () => { void continuous?.sendCurrent(); });
continuousInterrupt.addEventListener('click', () => { controller.interruptReply(); });
function releaseGesture(cancel: boolean): void {
  if (held === null) return;
  held = null;
  const settleFence = gestureReviewFence; gestureReviewFence = null;
  if (cancel) {
    void controller.stop().finally(() => settleFence?.());
  }
  else {
    const revision = gestureInputRevision;
    void controller.finishMicrophone().then(outcome => restoreNotSent(outcome, revision))
      .finally(() => settleFence?.());
  }
}
function startGesture(identity: string): void {
  if (closed || ptt.disabled || held !== null || rehearsalHeld !== null) return;
  gestureInputRevision = ++messageRevision;
  gestureReviewFence = reviewPanel?.invalidateForNewInput() ?? null;
  held = identity;
  error.textContent = '';
  void controller.startMicrophone();
}
ptt.addEventListener('pointerdown', event => {
  if (event.button !== 0) return;
  event.preventDefault();
  startGesture(`pointer:${event.pointerId}`);
  try { ptt.setPointerCapture(event.pointerId); } catch { /* Window pointerup still releases capture. */ }
});
const pointerUp = (event: PointerEvent) => {
  if (held === `pointer:${event.pointerId}`) releaseGesture(false);
};
ptt.addEventListener('pointerup', pointerUp);
window.addEventListener('pointerup', pointerUp);
ptt.addEventListener('pointercancel', () => releaseGesture(true));
ptt.addEventListener('lostpointercapture', () => releaseGesture(true));
ptt.addEventListener('keydown', event => {
  if (event.key !== ' ' && event.key !== 'Enter') return;
  event.preventDefault();
  if (!event.repeat) startGesture(`key:${event.key}`);
});
ptt.addEventListener('keyup', event => {
  if (event.key !== ' ' && event.key !== 'Enter') return;
  event.preventDefault();
  if (held === `key:${event.key}`) releaseGesture(false);
});
// Assistive-technology activation can use a start/finish toggle without pointer events.
ptt.addEventListener('click', event => {
  if (event.detail !== 0) return;
  if (held === 'accessible') releaseGesture(false);
  else if (held === null) startGesture('accessible');
});
function releaseRehearsal(cancel: boolean): void {
  if (rehearsalHeld === null) return;
  rehearsalHeld = null;
  const settleFence = rehearsalReviewFence; rehearsalReviewFence = null;
  if (cancel) {
    void controller.stop().finally(() => settleFence?.());
  }
  else {
    const revision = rehearsalInputRevision;
    void controller.finishRehearsalInput().then(outcome => restoreNotSent(outcome, revision))
      .finally(() => settleFence?.());
  }
}
function startRehearsal(identity: string): void {
  if (closed || !rehearsalAvailable || rehearsalButton.disabled || held !== null || rehearsalHeld !== null) return;
  rehearsalInputRevision = ++messageRevision;
  rehearsalReviewFence = reviewPanel?.invalidateForNewInput() ?? null;
  error.textContent = '';
  void controller.startRehearsalInput();
  rehearsalHeld = identity;
}
rehearsalButton.addEventListener('pointerdown', event => {
  if (event.button !== 0) return;
  event.preventDefault(); startRehearsal(`pointer:${event.pointerId}`);
  try { rehearsalButton.setPointerCapture(event.pointerId); } catch { /* Window release is also observed. */ }
});
const rehearsalPointerUp = (event: PointerEvent) => {
  if (rehearsalHeld === `pointer:${event.pointerId}`) releaseRehearsal(false);
};
rehearsalButton.addEventListener('pointerup', rehearsalPointerUp);
window.addEventListener('pointerup', rehearsalPointerUp);
rehearsalButton.addEventListener('pointercancel', () => releaseRehearsal(true));
rehearsalButton.addEventListener('lostpointercapture', () => releaseRehearsal(true));
rehearsalButton.addEventListener('keydown', event => {
  if (event.key !== ' ' && event.key !== 'Enter') return;
  event.preventDefault(); if (!event.repeat) startRehearsal(`key:${event.key}`);
});
rehearsalButton.addEventListener('keyup', event => {
  if (event.key !== ' ' && event.key !== 'Enter') return;
  event.preventDefault(); if (rehearsalHeld === `key:${event.key}`) releaseRehearsal(false);
});
rehearsalButton.addEventListener('click', event => {
  if (event.detail !== 0) return;
  if (rehearsalHeld === 'accessible') releaseRehearsal(false);
  else if (rehearsalHeld === null) startRehearsal('accessible');
});
window.addEventListener('blur', () => releaseRehearsal(true));
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') releaseRehearsal(true); });
window.addEventListener('blur', () => { releaseGesture(true); void continuous?.stop('user_stop'); });
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') { releaseGesture(true); void continuous?.stop('user_stop'); }
});

element<HTMLFormElement>('form.composer').addEventListener('submit', event => {
  event.preventDefault();
  if (!connected || closed) return;
  const text = messageInput.value;
  if (!text.trim()) return;
  const gestureFence = gestureReviewFence; gestureReviewFence = null; gestureFence?.();
  const rehearsalFence = rehearsalReviewFence; rehearsalReviewFence = null; rehearsalFence?.();
  const reviewFence = reviewPanel?.invalidateForNewInput();
  error.textContent = '';
  held = null; rehearsalHeld = null;
  const revision = ++messageRevision;
  messageInput.value = '';
  void (async () => {
    if (continuous?.active) await continuous.stop('user_stop');
    const outcome = await controller.input(text);
    restoreNotSent(outcome, revision, text);
  })().finally(() => reviewFence?.());
});
element('[data-stop]').addEventListener('click', () => {
  held = null; rehearsalHeld = null;
  const gestureFence = gestureReviewFence; gestureReviewFence = null; gestureFence?.();
  const rehearsalFence = rehearsalReviewFence; rehearsalReviewFence = null; rehearsalFence?.();
  const reviewFence = reviewPanel?.invalidateForStop();
  const stopping = controller.stop();
  memoryManagement?.stop();
  void stopping.finally(() => reviewFence?.());
});
for (const button of document.querySelectorAll<HTMLButtonElement>('[data-command]')) {
  button.addEventListener('click', () => {
    if (!connected || closed) return;
    error.textContent = ''; held = null; rehearsalHeld = null; messageRevision++;
    const gestureFence = gestureReviewFence; gestureReviewFence = null; gestureFence?.();
    const rehearsalFence = rehearsalReviewFence; rehearsalReviewFence = null; rehearsalFence?.();
    const reviewFence = reviewPanel?.invalidateForNewInput();
    void (async () => {
      if (continuous?.active) await continuous.stop('user_stop');
      return controller.input(button.dataset.command ?? '');
    })().finally(() => reviewFence?.());
  });
}
const stopAndClose = async (): Promise<void> => {
  if (closed) return;
  memoryManagement?.close();
  memoryManagement = null;
  const stopping = controller.stop();
  messageRevision++;
  closed = true; held = null; rehearsalHeld = null; ptt.disabled = true; rehearsalButton.disabled = true;
  gestureReviewFence?.(); gestureReviewFence = null; rehearsalReviewFence?.(); rehearsalReviewFence = null;
  reviewPanel?.close();
  diagnosticsWatcher.close();
  showConnection('closed');
  await stopping;
  await continuous?.close();
  await controller.close();
  status.textContent = 'closed · 刷新可新建';
};
element('[data-close]').addEventListener('click', () => {
  if (operatorGate) void operatorGate.cancelAndRevoke();
  else void stopAndClose();
});
window.addEventListener('pagehide', () => {
  if (operatorGate) return;
  closed = true; held = null; rehearsalHeld = null; messageRevision++;
  gestureReviewFence?.(); gestureReviewFence = null; rehearsalReviewFence?.(); rehearsalReviewFence = null;
  reviewPanel?.close(); diagnosticsWatcher.close(); void continuous?.close(); void controller.close();
});
function connectSession(): void {
  if (closed || connected || connecting) return;
  connecting = true;
  error.textContent = '';
  showConnection('connecting');
  void controller.connect().catch(problem => {
    if (closed) return;
    showConnection('failed');
    error.textContent = problem instanceof MiraHttpError
      ? problem.message : '连接失败。请确认开发服务已启动，再点重试连接；未启动任何语音。';
  }).finally(() => { connecting = false; });
}
connectRetry.addEventListener('click', connectSession);
connectSession();
return {stopAndClose};
}

if (document.body?.dataset['operatorPairing'] === 'required') {
  operatorGate = mountOperatorPairing(document, {onPaired: startSessionApp});
} else {
  startSessionApp();
}
