import type { SceneState } from './scene-state.js';

/** Read-only resource preparation plus a synchronous, gate-following visual commit. */
export interface CharacterRendererPort {
  prepareState(state: SceneState, signal: AbortSignal): Promise<boolean>;
  render(state: SceneState): void;
  /** Synchronously cancel motion and restore neutral face channels on Stop. */
  stop?(): void;
  /** Optional local pause hook for page hiding/backgrounding. */
  setPaused?(paused: boolean): void;
  /** Review-only status used to expose unaccepted assets without claiming success. */
  getStatus?(): {readonly mode: 'static-pixi' | 'code-native-review'; readonly visualAcceptance: 'pending' | 'accepted'; readonly warnings: readonly string[]};
  destroy(): void;
}
export type CharacterRendererFactory = (host: HTMLElement, signal: AbortSignal) => Promise<CharacterRendererPort | null>;
export type CharacterRendererMode = 'static-pixi' | 'code-native-review';
