import type {CharacterRendererPort} from './character-renderer-port.js';
import {initialSceneState} from './scene-state.js';
import type {ScenePhase, SceneState} from './scene-state.js';
import './code-native-vendor/character.js';
import './code-native-vendor/body.js';

export const CODE_NATIVE_SIZE = Object.freeze({width:192, height:320});
export const CODE_NATIVE_PHASES: Readonly<Record<ScenePhase, string>> = Object.freeze({
  idle:'idle', listening:'listen', thinking:'think', speaking:'speak',
});
type Node = {id:string; type:'group'|'path'; children?:Node[]; d?:string; fill?:string; transform?:string; opacity?:number; clip?:string};
type Pose = Record<string, number|string|boolean>;
interface FaceSource {
  palette:Record<string,string>;
  stateAt(mode:string, time:number, running:boolean):Pose;
  scene(pose:Pose):{layers:Node[]};
}
interface BodySource {
  bodyLayers(pose:Pose, palette:Record<string,string>):{back:Node[]; front:Node[]};
}
const sources = globalThis as unknown as {MiraCharacter:FaceSource; MiraBody:BodySource};
const FACE = sources.MiraCharacter;
const BODY = sources.MiraBody;
const abortError = (): Error => Object.assign(new Error('Code-native preparation cancelled'), {name:'AbortError'});

export function assertCodeNativeState(state:SceneState):void {
  if (!Object.hasOwn(CODE_NATIVE_PHASES, state.phase)) throw new Error('Unsupported character phase');
  if (!['outfit_black_jacket','outfit_cream_inner_only','outfit_amber_raincoat'].includes(state.outfit)) {
    throw new Error('Unsupported code-native wardrobe');
  }
  if (state.expression !== 'calm' || state.emotion !== 'emotion_normal') throw new Error('Code-native facial emotion unavailable');
  if (state.action !== 'camera_ready') throw new Error('Code-native camera/turn pose unavailable');
  if (state.accessory !== 'accessory_camera_clip') throw new Error('Code-native accessory unavailable');
}

/** Geometry-only composition: original face/hair geometry is never edited here. */
export function composeCodeNativeScene(state:SceneState, seconds:number, running:boolean):{layers:Node[]; pose:Pose} {
  assertCodeNativeState(state);
  const pose = FACE.stateAt(CODE_NATIVE_PHASES[state.phase], Number.isFinite(seconds) ? Math.max(0, seconds) : 0, running);
  const face = FACE.scene(pose);
  const rear = face.layers.find(node => node.id === 'rear-hair-rig');
  const head = face.layers.find(node => node.id === 'head-rig');
  if (!rear || !head) throw new Error('Code-native source layer contract changed');
  const body = BODY.bodyLayers({...pose, outfit:state.outfit.slice('outfit_'.length), reducedMotion:!running}, FACE.palette);
  return {layers:[...body.back, rear, ...body.front, head], pose};
}

function transform(context:CanvasRenderingContext2D, value = ''):void {
  const expression = /(translate|rotate|scale)\(([^)]+)\)/g;
  let match:RegExpExecArray|null;
  while ((match = expression.exec(value))) {
    const args = match[2]!.trim().split(/[ ,]+/).map(Number);
    if (!args.length || !args.every(Number.isFinite)) throw new Error('Invalid character transform');
    if (match[1] === 'translate') context.translate(args[0]!, args[1] ?? 0);
    else if (match[1] === 'scale') context.scale(args[0]!, args[1] ?? args[0]!);
    else {
      if (args.length === 3) context.translate(args[1]!, args[2]!);
      context.rotate(args[0]! * Math.PI / 180);
      if (args.length === 3) context.translate(-args[1]!, -args[2]!);
    }
  }
}

export interface CodeNativeRendererOptions {
  readonly signal?:AbortSignal;
  readonly document?:Document;
  readonly window?:Window;
  readonly createCanvas?:()=>HTMLCanvasElement;
  readonly createPath?:(path:string)=>Path2D;
  readonly requestAnimationFrame?:(callback:FrameRequestCallback)=>number;
  readonly cancelAnimationFrame?:(handle:number)=>void;
}

/** Single visual clock; never owns audio, authorization or presented-history receipts. */
class CodeNativeCharacterRenderer implements CharacterRendererPort {
  private current = initialSceneState();
  private seconds = 0;
  private lastTimestamp:number|null = null;
  private frame:number|null = null;
  private epoch = 0;
  private destroyed = false;
  private stopped = false;
  private paused = false;
  private reducedMotion = false;
  private hidden = false;
  private readonly canvas:HTMLCanvasElement;
  private readonly staging:HTMLCanvasElement;
  private readonly context:CanvasRenderingContext2D;
  private readonly stagingContext:CanvasRenderingContext2D;
  private readonly paths = new Map<string,Path2D>();
  private readonly document:Document;
  private readonly media:MediaQueryList|undefined;
  private readonly request:(callback:FrameRequestCallback)=>number;
  private readonly cancel:(handle:number)=>void;
  private readonly path:(data:string)=>Path2D;
  private lastPose:Pose = {};

  constructor(private readonly host:HTMLElement, private readonly options:CodeNativeRendererOptions) {
    this.document = options.document ?? host.ownerDocument ?? globalThis.document;
    const window = options.window ?? this.document.defaultView ?? globalThis.window;
    const create = options.createCanvas ?? (() => this.document.createElement('canvas'));
    this.canvas = create(); this.staging = create();
    for (const canvas of [this.canvas,this.staging]) { canvas.width = 192; canvas.height = 320; }
    this.canvas.className = 'mira-code-native-canvas';
    this.canvas.setAttribute('aria-label','MIRA 代码角色审阅草稿，外观未经认可');
    const context = this.canvas.getContext('2d'); const stagingContext = this.staging.getContext('2d');
    if (!context || !stagingContext) throw new Error('Canvas2D unavailable');
    this.context = context; this.stagingContext = stagingContext;
    this.context.imageSmoothingEnabled = false; this.stagingContext.imageSmoothingEnabled = false;
    this.path = options.createPath ?? (data => new Path2D(data));
    this.request = options.requestAnimationFrame ?? (callback => window.requestAnimationFrame(callback));
    this.cancel = options.cancelAnimationFrame ?? (handle => window.cancelAnimationFrame(handle));
    this.hidden = this.document.visibilityState === 'hidden';
    this.media = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    this.reducedMotion = this.media?.matches ?? false;
    this.document.addEventListener('visibilitychange', this.visibilityChanged);
    this.media?.addEventListener('change', this.motionChanged);
    options.signal?.addEventListener('abort', this.destroy, {once:true});
    try {
      this.commit(this.current);
      this.host.appendChild(this.canvas);
      this.host.dataset['renderer'] = 'code-native-review';
      this.host.dataset['visualAcceptance'] = 'pending';
      this.schedule();
    } catch (error) { this.destroy(); throw error; }
  }

  private running():boolean { return !this.destroyed && !this.stopped && !this.paused && !this.hidden && !this.reducedMotion; }
  private invalidate():void {
    this.epoch++;
    if (this.frame !== null) this.cancel(this.frame);
    this.frame = null; this.lastTimestamp = null;
  }
  private readonly visibilityChanged = ():void => {
    this.hidden = this.document.visibilityState === 'hidden';
    this.invalidate();
    if (this.hidden) this.paused = true;
    // Returning to a tab is not a request to resume an old speech animation.
    this.drawNeutral();
  };
  private readonly motionChanged = (event:MediaQueryListEvent):void => {
    this.reducedMotion = event.matches;
    this.invalidate(); this.drawNeutral();
    if (!event.matches) this.paused = true;
  };
  private drawNeutral():void {
    if (this.destroyed) return;
    try { this.commit(this.current, false); }
    catch { this.host.dataset['rendererError'] = 'drawing-failed'; this.destroy(); }
  }
  private drawNode(context:CanvasRenderingContext2D, node:Node):void {
    context.save();
    try {
      transform(context,node.transform);
      if (node.opacity !== undefined) {
        if (!Number.isFinite(node.opacity)) throw new Error('Invalid character opacity');
        context.globalAlpha *= node.opacity;
      }
      if (node.clip) context.clip(this.getPath(node.clip));
      if (node.type === 'group') for (const child of node.children ?? []) this.drawNode(context,child);
      else { context.fillStyle = node.fill!; context.fill(this.getPath(node.d!)); }
    } finally { context.restore(); }
  }
  private getPath(data:string):Path2D {
    if (typeof data !== 'string' || /NaN|Infinity/.test(data)) throw new Error('Invalid character path');
    let path = this.paths.get(data);
    if (!path) {
      path = this.path(data);
      // Mouth paths change per frame. Keep a bounded cache rather than growing forever.
      if (this.paths.size > 768) this.paths.clear();
      this.paths.set(data,path);
    }
    return path;
  }
  private stage(state:SceneState, running = this.running()):Pose {
    const scene = composeCodeNativeScene(state,this.seconds,running);
    this.stagingContext.clearRect(0,0,192,320);
    for (const node of scene.layers) this.drawNode(this.stagingContext,node);
    return scene.pose;
  }
  private commit(state:SceneState, running = this.running()):void {
    const pose = this.stage(state,running);
    this.context.save();
    try {
      // One full-frame copy replaces transparency atomically; no visible pre-clear.
      this.context.globalCompositeOperation = 'copy';
      this.context.drawImage(this.staging,0,0);
    } finally { this.context.restore(); }
    this.lastPose = pose;
  }
  private schedule():void {
    if (!this.running() || this.frame !== null) return;
    const epoch = this.epoch;
    this.frame = this.request(timestamp => {
      if (this.destroyed || epoch !== this.epoch || !this.running()) return;
      this.frame = null;
      const safeTimestamp = Number.isFinite(timestamp) ? timestamp : 0;
      if (this.lastTimestamp !== null) this.seconds += Math.min(.1,Math.max(0,(safeTimestamp-this.lastTimestamp)/1000));
      this.lastTimestamp = safeTimestamp;
      try { this.commit(this.current); }
      catch { this.host.dataset['rendererError'] = 'drawing-failed'; this.destroy(); return; }
      this.schedule();
    });
  }
  async prepareState(state:SceneState, signal:AbortSignal):Promise<boolean> {
    if (this.destroyed || signal.aborted || this.options.signal?.aborted) throw abortError();
    if (this.hidden) throw new Error('Character review is hidden');
    const epoch = this.epoch;
    this.stage(state);
    await Promise.resolve();
    if (this.destroyed || signal.aborted || this.options.signal?.aborted || epoch !== this.epoch) throw abortError();
    return true;
  }
  render(state:SceneState):void {
    if (this.destroyed) throw new Error('Code-native renderer unavailable');
    assertCodeNativeState(state);
    const changedPhase = state.phase !== this.current.phase;
    const restart = changedPhase && state.phase !== 'idle' && !this.hidden;
    // Commit can fail; do not advance logical state or the animation clock first.
    this.commit(state, restart ? !this.reducedMotion : this.running());
    this.current = {...state};
    if (restart) { this.stopped = false; this.paused = false; }
    if (changedPhase) this.lastTimestamp = null;
    this.schedule();
  }
  stop():void {
    if (this.destroyed) return;
    this.invalidate(); this.stopped = true; this.seconds = 0;
    this.current = {...this.current,phase:'idle'};
    this.commit(this.current,false);
  }
  setPaused(paused:boolean):void {
    if (this.destroyed) return;
    this.invalidate(); this.paused = paused;
    if (paused) this.commit(this.current,false); else this.schedule();
  }
  getStatus():{mode:'code-native-review'; visualAcceptance:'pending'; warnings:readonly string[]; phase:ScenePhase; running:boolean; seconds:number; mouth:number} {
    return {mode:'code-native-review',visualAcceptance:'pending',
      warnings:['角色外观尚未认可；四种情绪和星形发夹不可用；讲话口型仅为阶段示意。'],
      phase:this.current.phase,running:this.running(),seconds:this.seconds,mouth:Number(this.lastPose['mouth'] ?? 0)};
  }
  readonly destroy = ():void => {
    if (this.destroyed) return;
    this.destroyed = true; this.invalidate();
    this.document.removeEventListener('visibilitychange',this.visibilityChanged);
    this.media?.removeEventListener('change',this.motionChanged);
    this.options.signal?.removeEventListener('abort',this.destroy);
    this.canvas.remove(); this.paths.clear();
    delete this.host.dataset['renderer']; delete this.host.dataset['visualAcceptance'];
  };
}

export async function createCodeNativeCharacterRenderer(host:HTMLElement, options:CodeNativeRendererOptions = {}):Promise<CharacterRendererPort|null> {
  if (options.signal?.aborted) return null;
  return new CodeNativeCharacterRenderer(host,options);
}
