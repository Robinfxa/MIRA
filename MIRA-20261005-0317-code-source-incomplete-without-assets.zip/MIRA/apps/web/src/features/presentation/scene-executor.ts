import type { EffectView } from '../../shared/generated/contracts.js';
import type { EffectExecutor } from './ports.js';
import type { CharacterRendererFactory, CharacterRendererMode, CharacterRendererPort } from './character-renderer-port.js';
import { initialSceneState, reduceSceneEffect } from './scene-state.js';
import type { SceneExpression, ScenePhase, SceneState } from './scene-state.js';

const PHASE_LABELS: Record<ScenePhase, string> = {
  idle: '陪你听雨', listening: '正在认真听', thinking: '想一想…', speaking: '正在说话',
};
const EXPRESSION_LABELS: Record<SceneExpression, string> = {
  calm: '平静', warm: '温暖微笑', curious: '好奇', reflective: '若有所思',
};
const ACTION_LABELS: Record<SceneState['action'], string> = {
  camera_ready: '手中拿着相机', camera_lowered: '放低了相机', look_at_rain: '转头看向窗外的雨',
};
const SCENE_LABELS: Record<SceneState['environment'], string> = {
  cafe: '雨夜 · 窗边咖啡馆', rain_window: '雨窗 · 城市慢了下来', cafe_warm: '暖灯 · 留一会儿吧',
};
const DEFAULT_MEDIA_READINESS_TIMEOUT_MS = 5000;
const MAX_MEDIA_READINESS_TIMEOUT_MS = 30000;
const abortError = (): Error => Object.assign(new Error('Media preparation cancelled'), { name: 'AbortError' });

export interface SceneEffectExecutorOptions {
  /** Test seam for the bounded asset wait; production defaults to five seconds. */
  readonly mediaReadinessTimeoutMs?: number;
  /** Null disables Pixi; absent uses the local, lazy-loaded Pixi adapter. */
  readonly characterRendererFactory?: CharacterRendererFactory | null;
  /** Explicit opt-in for the unaccepted semantic code-native review renderer. */
  readonly characterRendererMode?: CharacterRendererMode;
}

/**
 * Synchronous visual consumer beneath the existing presentation gate.
 * The selected renderer owns visual motion; this class schedules nothing and never starts audio.
 * Real recording/playback owners call setPhase; subtitle delivery is not speech evidence.
 */
export class SceneEffectExecutor implements EffectExecutor {
  private state = initialSceneState();
  private readonly decodedImages = new WeakMap<HTMLImageElement, Promise<void>>();
  private readonly mediaReadinessTimeoutMs: number;
  private readonly rendererAbort = new AbortController();
  private characterRenderer: CharacterRendererPort | null = null;
  private characterRendererPromise: Promise<CharacterRendererPort | null> | null = null;
  private readonly characterRendererMode: CharacterRendererMode;
  private closed = false;

  constructor(private readonly root: HTMLElement, options: SceneEffectExecutorOptions = {}) {
    const timeout = options.mediaReadinessTimeoutMs ?? DEFAULT_MEDIA_READINESS_TIMEOUT_MS;
    if (!Number.isSafeInteger(timeout) || timeout < 1 || timeout > MAX_MEDIA_READINESS_TIMEOUT_MS) {
      throw new RangeError('Media readiness timeout must be between 1 and 30000 milliseconds');
    }
    this.mediaReadinessTimeoutMs = timeout;
    this.characterRendererMode = options.characterRendererMode ?? 'static-pixi';
    this.render();
    this.initializeCharacterRenderer(root.querySelector<HTMLElement>('.character-anchor'), options.characterRendererFactory);
  }

  private initializeCharacterRenderer(host: HTMLElement | null, factory: CharacterRendererFactory | null | undefined): void {
    if (!host || factory === null) return;
    const load: CharacterRendererFactory = factory ?? (async (target, signal) => {
      if (this.characterRendererMode === 'code-native-review') {
        const module = await import('./code-native-character-renderer.js');
        return module.createCodeNativeCharacterRenderer(target, {signal});
      }
      const module = await import('./pixi-character-renderer.js');
      return module.createPixiCharacterRenderer(target, {signal});
    });
    this.characterRendererPromise = Promise.resolve().then(() => load(host, this.rendererAbort.signal)).then(renderer => {
      if (this.closed || this.rendererAbort.signal.aborted) {
        try { renderer?.destroy(); } catch { /* the static SVG remains the fallback */ }
        return null;
      }
      this.characterRenderer = renderer;
      if (renderer) this.render();
      return renderer;
    }).catch(() => null);
  }

  private async prepareCharacterState(state: SceneState, signal: AbortSignal): Promise<void> {
    if (signal.aborted) throw abortError();
    if (!this.characterRendererPromise) {
      if (this.characterRendererMode === 'code-native-review') throw new Error('Code-native review renderer unavailable');
      return;
    }
    const renderer = await this.awaitWithAbort(this.characterRendererPromise, signal);
    if (signal.aborted) throw abortError();
    if (!renderer || this.characterRenderer !== renderer) {
      if (this.characterRendererMode === 'code-native-review') throw new Error('Code-native review renderer unavailable');
      return;
    }
    let prepared = false;
    try { prepared = await renderer.prepareState(state, signal); }
    catch {
      if (signal.aborted) throw abortError();
      if (this.characterRendererMode === 'code-native-review') {
        this.root.dataset['rendererError'] = 'preparation-failed';
        throw new Error('Code-native review preparation failed');
      }
      this.disableCharacterRenderer(renderer);
      return;
    }
    if (signal.aborted) throw abortError();
    if (!prepared) {
      if (this.characterRendererMode === 'code-native-review') throw new Error('Code-native review asset unavailable');
      this.disableCharacterRenderer(renderer);
    }
  }

  private awaitWithAbort<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
    if (signal.aborted) return Promise.reject(abortError());
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error?: Error, value?: T): void => {
        if (settled) return;
        settled = true;
        signal.removeEventListener('abort', onAbort);
        if (error) reject(error); else resolve(value as T);
      };
      const onAbort = (): void => finish(abortError());
      signal.addEventListener('abort', onAbort, {once: true});
      promise.then(value => finish(undefined, value), () => finish(new Error('Character renderer unavailable')));
      if (signal.aborted) onAbort();
    });
  }

  private disableCharacterRenderer(expected?: CharacterRendererPort): void {
    const renderer = this.characterRenderer;
    if (!renderer || (expected && renderer !== expected)) return;
    this.characterRenderer = null;
    try { renderer.destroy(); } catch { /* the inline SVG remains the fallback */ }
  }

  private element(name: string): HTMLElement {
    const target = this.root.querySelector<HTMLElement>(`[data-${name}]`);
    if (!target) throw new Error(`Missing scene slot: ${name}`);
    return target;
  }

  apply(effect: EffectView): void {
    const next = this.reduceForRenderer(effect);
    this.render(next, true);
    this.state = next;
  }

  private reduceForRenderer(effect: EffectView): SceneState {
    const value = String(effect.value);
    const appearance = /^(outfit_|emotion_|accessory_)/.test(value);
    if (this.characterRendererMode !== 'code-native-review' && effect.kind === 'pose' && appearance) {
      if (!['outfit_black_jacket', 'emotion_normal', 'accessory_camera_clip'].includes(value)) {
        throw new Error('Appearance state requires explicit code-native review rendering');
      }
    }
    const next = reduceSceneEffect(this.state, effect);
    if (this.characterRendererMode !== 'code-native-review') return next;
    // Environment/media change their own visible facts, never an unsupported implicit face/camera pose.
    if (effect.kind === 'scene' || effect.kind === 'media') {
      return {...next, action: this.state.action, expression: this.state.expression};
    }
    return next;
  }

  /**
   * Wait for the already-mounted local illustration without changing visible DOM state.
   * This establishes decoded-resource readiness only; it cannot establish browser paint or
   * that a person looked at the image. The controller revalidates its gate before apply().
   */
  async prepare(effect: EffectView, signal: AbortSignal): Promise<void> {
    if (signal.aborted) throw abortError();
    const nextState = this.reduceForRenderer(effect);
    await this.prepareCharacterState(nextState, signal);
    if (signal.aborted) throw abortError();
    if (effect.kind !== 'media' || (effect.value !== 'trip_photo' && effect.value !== 'trip_photo_placeholder')) return;
    const image = this.root.querySelector<HTMLImageElement>('[data-photo] img');
    if (!image) throw new Error('Image resource unavailable');

    const deadline = new AbortController();
    let timedOut = false;
    const abortDeadline = (): void => deadline.abort();
    const timer = globalThis.setTimeout(() => { timedOut = true; deadline.abort(); }, this.mediaReadinessTimeoutMs);
    signal.addEventListener('abort', abortDeadline, { once: true });
    try {
      await this.waitForImageLoad(image, deadline.signal);
      await this.decodeImage(image, deadline.signal);
      if (signal.aborted) throw abortError();
      if (!this.imageIsReady(image)) throw new Error('Image resource unavailable');
    } catch (error) {
      if (signal.aborted) throw abortError();
      if (timedOut) throw new Error('Image readiness timed out');
      throw error instanceof Error && error.name === 'AbortError' ? error : new Error('Image resource unavailable');
    } finally {
      globalThis.clearTimeout(timer);
      signal.removeEventListener('abort', abortDeadline);
    }
  }

  private imageIsReady(image: HTMLImageElement): boolean {
    return image.complete && image.naturalWidth > 0;
  }

  private waitForImageLoad(image: HTMLImageElement, signal: AbortSignal): Promise<void> {
    if (signal.aborted) return Promise.reject(abortError());
    if (image.complete) return this.imageIsReady(image) ? Promise.resolve() : Promise.reject(new Error('Image resource unavailable'));
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error?: Error): void => {
        if (settled) return;
        settled = true;
        image.removeEventListener('load', onLoad);
        image.removeEventListener('error', onError);
        signal.removeEventListener('abort', onAbort);
        if (error) reject(error); else resolve();
      };
      const onLoad = (): void => finish(this.imageIsReady(image) ? undefined : new Error('Image resource unavailable'));
      const onError = (): void => finish(new Error('Image resource unavailable'));
      const onAbort = (): void => finish(abortError());
      image.addEventListener('load', onLoad, { once: true });
      image.addEventListener('error', onError, { once: true });
      signal.addEventListener('abort', onAbort, { once: true });
      // Close the small race between the initial complete check and listener registration.
      if (image.complete) onLoad();
      if (signal.aborted) onAbort();
    });
  }

  private decodeImage(image: HTMLImageElement, signal: AbortSignal): Promise<void> {
    if (signal.aborted) return Promise.reject(abortError());
    if (!this.imageIsReady(image)) return Promise.reject(new Error('Image resource unavailable'));
    return new Promise((resolve, reject) => {
      let settled = false;
      const finish = (error?: Error): void => {
        if (settled) return;
        settled = true;
        signal.removeEventListener('abort', onAbort);
        if (error) reject(error); else resolve();
      };
      const onAbort = (): void => finish(abortError());
      signal.addEventListener('abort', onAbort, { once: true });
      this.decodeResource(image).then(() => {
          finish(this.imageIsReady(image) ? undefined : new Error('Image resource unavailable'));
        }, () => finish(new Error('Image resource unavailable')));
      if (signal.aborted) onAbort();
    });
  }

  private decodeResource(image: HTMLImageElement): Promise<void> {
    const existing = this.decodedImages.get(image);
    if (existing) return existing;
    let decoding: Promise<void>;
    try { decoding = image.decode(); }
    catch { decoding = Promise.reject(new Error('Image resource unavailable')); }
    this.decodedImages.set(image, decoding);
    // Keep an in-flight decode single-flight even if one waiter is canceled. A settled
    // rejection is retryable, but an older rejection must never evict a newer cached attempt.
    void decoding.catch(() => {
      if (this.decodedImages.get(image) === decoding) this.decodedImages.delete(image);
    });
    return decoding;
  }

  prepareInput(): void {
    this.state = { ...this.state, phase: 'thinking', subtitle: '' };
    this.render();
  }

  stop(): void {
    this.state = { ...this.state, phase: 'idle', subtitle: this.state.photoVisible ? '已停下。那张旅行插画还留在这里。' : '已停下。我们可以慢慢说。' };
    try { this.characterRenderer?.stop?.(); } catch { this.disableCharacterRenderer(); }
    try { this.render(); } catch { this.disableCharacterRenderer(); this.render(); }
  }

  /** Allow the owning page lifecycle to pause the local visual loop without closing it. */
  setPaused(paused: boolean): void {
    try { this.characterRenderer?.setPaused?.(paused); }
    catch { this.disableCharacterRenderer(); }
  }

  setPhase(phase: ScenePhase): void {
    const next = { ...this.state, phase };
    this.render(next);
    this.state = next;
  }

  setExpression(expression: SceneExpression): void {
    const next = { ...this.state, expression };
    this.render(next, true);
    this.state = next;
  }

  close(): void {
    if (this.closed) return;
    this.closed = true;
    this.rendererAbort.abort();
    this.disableCharacterRenderer();
  }

  private render(state: SceneState = this.state, requireReviewCommit = false): void {
    // Resolve every DOM destination before asking the renderer to commit. A failed
    // explicit review commit must leave both the scene and its text description unchanged.
    const subtitle = this.element('subtitle');
    const photo = this.element('photo');
    const pose = this.element('pose');
    const sceneLabel = this.element('scene-label');
    const phaseLabel = this.element('phase-label');
    const characterDescription = this.element('character-description');
    const rendererStatus = this.characterRenderer?.getStatus?.();
    const reviewWarning = this.characterRendererMode === 'code-native-review'
      ? ' · 代码角色审阅中 · 外观未经认可' : '';
    const warningText = rendererStatus?.mode === 'code-native-review' ? ` ${rendererStatus.warnings.join(' ')}` : '';
    if (requireReviewCommit && this.characterRendererMode === 'code-native-review' && !this.characterRenderer) {
      throw new Error('Code-native review renderer unavailable');
    }
    try { this.characterRenderer?.render(state); }
    catch {
      if (this.characterRendererMode === 'code-native-review') {
        this.root.dataset['rendererError'] = 'commit-failed';
        if (requireReviewCommit) throw new Error('Code-native review render did not commit');
      } else this.disableCharacterRenderer();
    }
    this.root.dataset.phase = state.phase;
    this.root.dataset.expression = state.expression;
    this.root.dataset.action = state.action;
    this.root.dataset.scene = state.environment;
    this.root.dataset['outfit'] = state.outfit;
    this.root.dataset['emotion'] = state.emotion;
    this.root.dataset['accessory'] = state.accessory;
    this.root.dataset['characterRendererMode'] = this.characterRendererMode;
    if (rendererStatus?.mode === 'code-native-review' && this.characterRenderer) this.root.dataset['visualAcceptance'] = 'pending';
    else delete this.root.dataset['visualAcceptance'];
    subtitle.textContent = state.subtitle;
    photo.hidden = !state.photoVisible;
    pose.textContent = ACTION_LABELS[state.action];
    sceneLabel.textContent = SCENE_LABELS[state.environment];
    phaseLabel.textContent = `${PHASE_LABELS[state.phase]}${reviewWarning}`;
    characterDescription.textContent =
      `MIRA，26 岁的旅行摄影师。神情${EXPRESSION_LABELS[state.expression]}，${ACTION_LABELS[state.action]}。${PHASE_LABELS[state.phase]}。${reviewWarning}${warningText}`;
  }
}
