/* MIRA half-body / wardrobe study. Hand-authored semantic vector geometry.
 * No pixels, textures, external assets, timers or network calls are used to draw.
 * Integration: bodyLayers returns {back,front,width,height}.
 * Draw body back, existing rear-hair-rig, body front, existing head-rig.
 */
(function(root){
'use strict';
const W=192,H=320;
const OUTFITS=Object.freeze(['black_jacket','cream_inner_only','amber_raincoat']);
const basePalette=Object.freeze({
 ink:'#211b22',skinShadow:'#b56146',skinDeep:'#d57f5b',skin:'#eead83',skinLight:'#ffd0a3',skinGlow:'#ffdfb6',
 ivory:'#eee3cb',ivoryShade:'#cabcaa',white:'#fff0d2',gold:'#d49c3d',goldLight:'#ffe1a0',
 jacket:'#262936',jacketLight:'#424454',jacketDeep:'#191c27',leatherEdge:'#6b6876',
 trouser:'#33323d',trouserLight:'#514a51',trouserDeep:'#252631',
 amber:'#c28734',amberLight:'#e9b653',amberDeep:'#895323',amberEdge:'#fbd882',
 cameraInk:'#171b23',cameraGrip:'#282c35',cameraTop:'#c2c4c7',cameraShade:'#818994',cameraLight:'#f1ede2',
 lens:'#11191c',lensMid:'#283d3d',lensGreen:'#35553c',lensGold:'#9d7332',lensShine:'#9ed4b6',
 watchFace:'#23373e'
});
const clamp=(value,min,max)=>Math.max(min,Math.min(max,Number.isFinite(value)?value:0));
function normalized(s={}){
 const running=s.running!==false&&!s.reducedMotion;
 const time=clamp(s.time,0,1e9);
 return {outfit:OUTFITS.includes(s.outfit)?s.outfit:'black_jacket',running,time,
  breath:running?clamp(s.breath,-.5,.5):0,
  settle:running?Math.sin(time*.85)*.18:0,
  finger:running?Math.sin(time*.85-.4)*1.2:0};
}
function bodyLayers(state={},customPalette={}){
 const s=normalized(state),p={...basePalette,...customPalette};
 const S=(id,d,color,extra={})=>({id,type:'path',d,fill:p[color]||color,...extra});
 const G=(id,children,extra={})=>({id,type:'group',children,...extra});
 const isInner=s.outfit==='cream_inner_only',isRain=s.outfit==='amber_raincoat';
 const cloth=isRain?'amber':'jacket',deep=isRain?'amberDeep':'jacketDeep',light=isRain?'amberLight':'jacketLight';
 const edge=isRain?'amberEdge':'leatherEdge';
 const breathScale=1+s.breath*.008;

 const lower=G('waist-and-trousers',[
  S('trousers-outline','M60 282 L146 282 160 320 42 320 48 301Z','ink'),
  S('trousers-body','M64 285 L141 285 153 320 49 320 55 300Z','trouser'),
  S('trousers-left-light','M59 300 L93 297 89 320 53 320Z','trouserLight'),
  S('trousers-center-shadow','M105 296 L114 297 119 320 103 320Z','trouserDeep'),
  S('trousers-right-pocket','M127 300 L145 297 151 318 145 319 140 304 132 306Z','trouserLight'),
  S('trousers-left-seam','M67 305 L87 302 87 304 66 308 56 319 54 319Z','leatherEdge'),
  S('belt-strap','M55 290 L145 291 148 301 53 301Z','jacketDeep'),
  S('belt-upper-edge','M56 290 L144 290 144 292 56 292Z','leatherEdge'),
  S('belt-buckle-shadow','M101 290 L121 290 123 305 103 305 101 303Z','ink'),
  S('belt-buckle','M102 290 L121 291 122 304 104 305 102 302Z M105 294 L106 301 118 301 118 294Z','gold'),
  S('belt-buckle-glint','M103 291 L120 292 120 294 105 293 106 302 104 302Z','goldLight'),
  S('belt-buckle-tongue','M109 296 L121 296 121 298 109 298Z','gold'),
  S('belt-left-loop','M70 290 L74 290 73 302 69 302Z','trouserLight'),
  S('belt-right-loop','M134 291 L138 291 139 303 135 303Z','trouserLight')
 ]);

 const core=G('body-core',[
  S('neck-and-shoulder-outline','M87 118 L121 116 Q118 143 131 151 L146 160 Q157 169 159 190 L161 226 154 269 144 294 63 294 47 264 40 226 48 195 Q54 167 68 155 L79 150 Q90 135 87 118Z','ink'),
  S('neck-and-upper-chest','M89 118 L120 118 Q118 143 129 154 L145 161 Q153 169 153 189 L145 210 130 226 76 224 56 207 50 185 Q53 169 69 159 L82 151 Q92 135 89 118Z','skin'),
  S('neck-left-shadow','M89 120 L111 128 97 148 97 163 83 154 77 158 71 163 62 164 81 150 Q90 135 89 120Z','skinDeep'),
  S('neck-right-light','M119 123 Q116 145 126 156 L142 164 143 176 130 190 117 193 101 181 98 161 110 149Z','skinLight'),
  S('left-collarbone','M75 166 L87 166 103 177 101 179 87 170 77 170 68 174Z','skinDeep'),
  S('right-collarbone','M125 173 L137 166 143 167 135 170 128 178 119 181Z','skinGlow'),
  S('chest-soft-light','M88 177 Q99 181 108 188 Q126 178 141 181 L149 202 134 221 106 233 72 217 61 195 68 181Z','skinLight'),
  S('chest-center-shade','M104 198 Q108 210 110 220 L107 222 104 211 100 205Z','skinDeep'),
  S('cream-top-outline','M58 172 L71 177 75 191 Q79 201 105 224 Q128 207 138 188 L138 174 149 168 Q155 188 159 204 L163 231 154 269 144 291 63 291 47 263 40 226 45 196Z','ivoryShade'),
  S('cream-top-left-strap','M58 173 L66 177 65 188 57 207 49 218 45 209 49 188Z','white'),
  S('cream-top-right-strap','M140 174 L146 171 151 192 151 208 144 216 139 209 143 192Z','white'),
  S('cream-top-bodice','M52 202 Q75 215 105 229 Q133 207 150 201 L158 224 Q159 245 150 268 L141 288 65 288 Q49 267 45 240 L43 224Z','ivory'),
  G('cloth-breath',[
   S('cream-left-drape','M47 218 Q76 231 98 234 L127 224 Q100 243 80 242 L51 233Z','white'),
   S('cream-crossfold-shadow','M48 239 Q73 244 110 232 L139 222 Q124 237 82 251 L57 253Z','ivoryShade'),
   S('cream-crossfold-light','M52 247 Q96 246 147 219 L149 225 Q114 246 57 260Z','white'),
   S('cream-right-underfold','M153 235 Q141 256 115 267 L83 279 67 278 Q115 260 150 239Z','ivoryShade'),
   S('cream-waist-drape','M68 282 L117 269 147 250 144 260 130 274 94 286Z','white'),
   S('cream-side-shadow','M46 223 L51 240 53 255 63 274 70 287 65 287 Q49 268 45 243Z','ivoryShade')
  ],{transform:`translate(103 225) scale(${breathScale} 1) translate(-103 -225)`,pivot:[103,225]}),
  S('cream-neckline-shadow','M60 192 Q73 205 106 226 Q132 206 145 190 L149 199 Q134 216 106 234 Q73 214 55 200Z','ivoryShade'),
  S('cream-neckline-lace','M59 190 L64 194 65 198 69 198 70 202 75 203 76 207 82 209 85 213 90 215 95 219 101 222 106 227 112 222 118 218 123 214 128 209 134 204 138 198 142 194 146 189 148 194 Q133 215 106 231 Q74 211 57 196Z','white'),
  S('cream-waist-edge','M65 286 Q101 291 143 285 L142 290 66 290Z','ivoryShade'),
  G('necklace',[
   S('necklace-chain-shadow','M80 160 L87 175 107 188 124 179 136 160 136 165 126 181 107 192 86 178 77 163Z','skinShadow'),
   S('necklace-chain','M79 160 L89 177 107 188 124 178 136 160 134 167 126 181 107 191 87 179 77 162Z','gold'),
   S('necklace-chain-glints','M80 163 L81 163 86 172 85 173Z M124 178 L127 174 128 175 125 179Z','goldLight'),
   S('compass-pendant-outline','M103 190 L110 189 115 194 113 201 106 204 100 200 99 194Z','ink'),
   S('compass-pendant','M104 190 L109 190 114 194 112 200 106 202 101 199 101 194Z','gold'),
   S('compass-pendant-inset','M104 192 L109 192 112 195 110 199 106 200 103 198 103 194Z','amberDeep'),
   S('compass-pendant-star','M106 191 L107 195 111 194 109 197 111 200 107 198 106 202 105 198 102 199 104 196 102 194 105 195Z','goldLight')
  ])
 ],{pivot:[103,215]});

 const leftUpper=G('arm-left-upper',isInner?[
  S('left-upper-arm-outline','M47 169 Q31 169 25 188 L17 226 15 250 20 267 41 275 54 255 49 235 54 210Z','ink'),
  S('left-upper-arm-skin','M43 173 Q32 175 28 191 L21 222 18 249 22 262 39 270 49 254 46 235 51 208Z','skin'),
  S('left-upper-arm-light','M35 182 Q30 205 26 224 L23 249 29 259 36 260 42 249 39 232 45 199 44 177Z','skinLight'),
  S('left-upper-arm-inner-shadow','M46 200 L49 205 45 235 49 253 39 271 35 265 43 252 41 237Z','skinDeep'),
  S('left-shoulder-top-edge','M47 171 L55 172 55 181 50 190 46 188 49 178Z','white')
 ]:[
  S('left-sleeve-outline','M52 163 Q34 161 26 181 L18 215 12 240 14 265 31 286 50 273 57 239 57 201Z','ink'),
  S('left-sleeve-base','M48 165 Q33 169 29 184 L24 211 17 239 18 263 32 279 47 271 53 239 53 199Z',deep),
  S('left-sleeve-outer-plane','M35 178 L44 170 46 195 39 215 33 224 27 244 21 250 22 232 28 208Z',cloth),
  S('left-sleeve-ridge','M35 184 L39 178 37 205 33 218 26 228 29 211Z',light),
  S('left-sleeve-elbow-fold','M18 236 L27 228 45 226 53 232 48 241 37 233 26 235 18 246Z',light),
  S('left-sleeve-lower-fold','M21 251 L30 245 47 247 48 253 31 251 25 257 29 268 24 268Z',cloth),
  S('left-sleeve-long-fold','M47 196 L53 199 48 219 44 226 40 224 45 213Z',light),
  S('left-sleeve-seam','M29 181 L31 180 25 213 19 238 18 259 17 258 17 236 23 211Z',edge)
 ],{pivot:[40,178],transform:`rotate(${s.settle} 40 178)`});

 const rightUpper=G('arm-right-upper',isInner?[
  S('right-upper-arm-outline','M150 168 Q166 173 173 193 L182 232 182 262 170 279 154 276 148 260 153 235 149 208Z','ink'),
  S('right-upper-arm-skin','M153 173 Q165 181 169 195 L178 233 178 258 168 274 157 272 152 259 157 235 153 208Z','skin'),
  S('right-upper-arm-light','M159 182 Q166 191 168 205 L174 233 173 255 166 267 160 265 157 258 162 238 158 211Z','skinLight'),
  S('right-upper-arm-inner-shadow','M153 197 L159 219 161 238 156 260 159 270 155 271 151 260 156 235Z','skinDeep'),
  S('right-shoulder-top-edge','M146 170 L150 168 155 186 153 195 149 188Z','white')
 ]:[
  S('right-sleeve-outline','M146 159 Q169 163 177 188 L185 221 187 253 181 279 164 291 149 276 151 243 143 200Z','ink'),
  S('right-sleeve-base','M151 164 Q169 170 173 190 L181 222 183 252 177 277 165 285 154 273 155 243 149 201Z',deep),
  S('right-sleeve-outer-plane','M161 174 Q173 184 173 206 L179 225 178 246 170 250 167 228 157 205Z',cloth),
  S('right-sleeve-light-ridge','M166 183 L170 190 172 217 178 233 176 239 169 222Z',light),
  S('right-sleeve-elbow-fold','M155 233 L167 225 180 230 182 240 171 234 158 242Z',light),
  S('right-sleeve-lower-fold','M159 249 L170 242 181 248 178 255 171 250 161 257Z',cloth),
  S('right-sleeve-seam','M175 192 L178 206 184 231 185 253 182 265 181 263 183 251 182 231 176 206Z',edge)
 ],{pivot:[157,179],transform:`rotate(${-s.settle} 157 179)`});

 const jacketPanels=isInner?G('inner-top-side-finishing',[
  S('cream-left-side-edge','M52 191 L47 211 45 228 49 247 52 246 48 225 50 211 55 196Z','ivoryShade'),
  S('cream-right-side-edge','M149 191 L154 214 155 236 153 247 156 244 159 228 154 204Z','ivoryShade')
 ]):G(isRain?'amber-raincoat-panels':'black-jacket-panels',isRain?[
  S('raincoat-left-front','M71 151 L52 157 39 170 46 196 45 225 49 249 46 281 38 312 60 320 69 288 71 248 74 210 65 179Z','amberDeep'),
  S('raincoat-left-front-light','M55 161 L66 157 61 180 70 211 66 248 65 278 57 312 44 307 52 276 55 249 50 222 52 191 45 174Z','amber'),
  S('raincoat-left-placket','M65 179 L69 202 72 210 66 263 67 280 58 312 55 311 63 279 62 262 68 212 63 197 61 182Z','amberLight'),
  S('raincoat-left-collar','M71 150 L58 155 49 174 57 184 61 201 76 207 70 188 64 179Z','amberLight'),
  S('raincoat-left-collar-fold','M64 160 L57 176 65 187 69 200 64 198 59 184 53 175Z','amberEdge'),
  S('raincoat-right-front','M128 149 L153 158 165 172 157 198 161 225 155 249 157 280 172 317 147 320 139 288 139 248 137 209 134 180Z','amberDeep'),
  S('raincoat-right-front-light','M147 160 L157 169 153 193 155 218 154 239 150 254 151 283 164 314 151 318 143 285 143 248 142 211 141 184Z','amber'),
  S('raincoat-right-collar','M129 149 L150 156 157 173 146 178 150 196 134 190 129 174Z','amberLight'),
  S('raincoat-right-collar-fold','M133 153 L147 159 152 171 141 176 145 190 141 188 137 174 147 170 144 161Z','amberEdge'),
  S('raincoat-shoulder-flap','M153 166 L166 177 167 183 154 177Z','amberLight'),
  S('raincoat-left-pocket','M52 245 L65 248 63 251 52 249Z','amberDeep'),
  S('raincoat-right-pocket','M143 247 L155 245 155 249 143 251Z','amberDeep'),
  S('raincoat-bottom-seams','M46 305 L57 309 57 311 45 308Z M151 311 L162 309 163 312 152 314Z','amberLight'),
  S('raincoat-snap-buttons','M65 217 L68 217 68 220 65 220Z M63 240 L66 240 66 243 63 243Z M61 263 L64 263 64 266 61 266Z M143 217 L146 217 146 220 143 220Z','goldLight')
 ]:[
  S('jacket-left-front','M71 151 L47 158 39 174 44 196 40 224 44 248 42 278 31 309 49 320 62 289 65 250 72 211 65 186Z','jacketDeep'),
  S('jacket-left-front-plane','M49 161 L61 156 58 178 67 204 60 243 59 275 49 307 38 305 47 276 50 251 46 225 50 192 43 175Z','jacket'),
  S('jacket-left-fold-plane','M48 213 L53 216 50 230 55 246 52 267 48 278 48 254 43 231Z','jacketLight'),
  S('jacket-left-lapel','M70 150 L57 155 46 175 58 188 55 198 75 216 66 194 65 182 60 174Z','jacketLight'),
  S('jacket-left-lapel-deep','M58 177 L64 183 65 194 71 208 59 197 61 188 53 178Z','jacket'),
  S('jacket-left-lapel-piping','M67 153 L58 157 48 175 61 188 58 197 70 209 72 211 67 203 61 196 64 187 51 174 60 158Z','gold'),
  S('jacket-right-front','M128 148 L153 157 163 172 153 193 157 221 153 249 154 278 167 315 148 320 137 287 138 248 137 212 132 178Z','jacketDeep'),
  S('jacket-right-front-plane','M149 159 L158 170 148 193 150 219 148 243 145 259 148 283 159 313 151 315 140 285 142 246 142 211 137 183Z','jacket'),
  S('jacket-right-lapel','M128 147 L153 156 158 176 145 178 159 200 141 207 136 182 131 174Z','jacketLight'),
  S('jacket-right-lapel-deep','M140 181 L145 181 153 196 143 201Z','jacket'),
  S('jacket-right-lapel-piping','M131 151 L150 159 154 173 141 175 155 196 144 202 144 205 159 198 146 178 157 176 153 157Z','gold'),
  S('jacket-left-zipper-shadow','M69 207 L71 210 64 250 62 276 53 301 50 300 59 275 61 249Z','ink'),
  S('jacket-left-zipper','M69 208 L70 211 63 250 61 276 52 301 51 299 59 275 61 249Z','gold'),
  S('jacket-right-zipper','M139 209 L141 209 145 241 143 271 151 301 149 300 141 271 143 241Z','gold'),
  S('jacket-left-pocket-welt','M46 245 L57 240 59 242 47 248Z','leatherEdge'),
  S('jacket-right-pocket-welt','M148 240 L155 244 154 247 148 244Z','leatherEdge'),
  S('jacket-lapel-studs','M58 190 L62 191 61 195 57 194Z M146 181 L150 180 151 184 147 185Z M61 232 L64 232 64 236 60 235Z','goldLight'),
  S('jacket-zipper-pull-left','M57 270 L61 270 60 278 56 278Z M57 272 L57 276 59 276 60 272Z','gold'),
  S('jacket-zipper-pull-right','M141 268 L145 268 146 275 142 276Z M143 270 L143 274 145 273 144 270Z','gold'),
  S('jacket-waist-folds','M43 286 L49 283 46 297 40 301Z M149 287 L153 293 158 305 153 305Z','jacketLight')
 ]);

 const straps=G('camera-neck-straps',[
  S('camera-strap-left-shadow','M60 191 L65 193 69 219 73 249 81 262 78 266 68 251 64 222Z','ink'),
  S('camera-strap-left-edge','M60 191 L62 192 66 219 70 250 78 261 77 263 68 252 63 221Z','jacketLight'),
  S('camera-strap-right-shadow','M137 190 L142 188 144 216 143 242 140 262 135 262 138 241 139 216Z','ink'),
  S('camera-strap-right-edge','M140 190 L142 189 144 216 142 243 139 259 137 259 140 241 142 216Z','jacketLight'),
  S('camera-strap-left-adjuster','M64 220 L70 219 71 227 65 228Z M66 221 L67 226 69 225 68 221Z','gold'),
  S('camera-strap-right-adjuster','M137 224 L144 224 144 232 137 232Z M139 226 L139 230 142 230 142 226Z','gold'),
  S('camera-strap-left-link','M70 246 L73 246 77 255 75 258 72 255Z M72 248 L73 253 75 256 76 254Z','gold'),
  S('camera-strap-right-link','M137 248 L141 248 140 258 136 260 135 256Z M138 250 L136 256 137 258 139 256 140 250Z','gold'),
  S('camera-strap-glints','M65 220 L69 220 69 221 65 222Z M138 225 L143 225 143 226 138 226Z','goldLight')
 ]);

 const forearms=G('elbows-and-forearms',[
  G('elbow-left',[
   ...(isInner?[]:[
    S('left-rolled-cuff-outline','M19 241 Q32 232 48 240 L52 252 46 267 29 277 17 266 15 253Z','ink'),
    S('left-rolled-cuff','M20 243 Q34 237 46 243 L48 251 42 264 29 271 21 264 18 253Z',light),
    S('left-rolled-cuff-band','M21 250 Q31 242 46 248 L43 256 29 265 22 259Z',deep),
    S('left-rolled-cuff-rim','M22 250 L31 244 44 245 45 248 33 247 23 254Z',edge)
   ]),
   G('forearm-left',[
    S('left-forearm-outline','M28 249 Q35 248 43 255 L57 262 71 261 83 270 77 282 59 285 43 280 28 275 22 263Z','ink'),
    S('left-forearm-skin','M29 252 Q36 253 43 258 L56 265 70 264 79 271 75 279 59 282 44 277 31 273 25 263Z','skin'),
    S('left-forearm-light','M30 253 Q38 258 45 260 L57 267 70 266 76 271 72 275 57 276 44 272 34 270 28 262Z','skinLight'),
    S('left-forearm-lower-shade','M28 268 L44 275 59 280 74 277 75 280 59 283 43 278 30 274Z','skinDeep')
   ],{pivot:[29,255]})
  ],{pivot:[28,250]}),
  G('elbow-right',[
   ...(isInner?[]:[
    S('right-rolled-cuff-outline','M158 250 Q172 243 182 253 L181 268 174 283 160 284 150 274Z','ink'),
    S('right-rolled-cuff','M160 253 Q171 248 178 255 L177 266 172 279 162 281 155 273Z',light),
    S('right-rolled-cuff-band','M161 259 Q170 252 179 260 L176 268 172 275 161 278 158 272Z',deep),
    S('right-rolled-cuff-rim','M162 259 L170 255 177 257 177 260 170 258 162 262Z',edge)
   ]),
   G('forearm-right',[
    S('right-forearm-outline','M164 261 Q175 262 175 273 L169 289 153 299 141 295 142 280 153 271Z','ink'),
    S('right-forearm-skin','M164 264 Q173 265 172 273 L166 287 153 296 144 292 145 282 155 274Z','skin'),
    S('right-forearm-light','M163 265 Q170 266 169 274 L164 283 154 290 148 288 150 281 158 274Z','skinLight'),
    S('right-forearm-bottom-shadow','M166 283 L165 289 153 298 144 294 143 290 153 293Z','skinDeep')
   ],{pivot:[169,264]})
  ],{pivot:[173,256]})
 ]);

 const camera=G('camera-rig',[
  S('camera-strap-left-lug','M77 259 L83 259 84 267 78 268 75 265Z','gold'),
  S('camera-strap-right-lug','M145 265 L150 265 150 273 146 274Z','gold'),
  S('camera-silhouette','M80 255 L93 253 101 257 112 256 116 250 128 251 132 258 147 260 148 284 142 291 83 286 77 280Z','cameraInk'),
  S('camera-top-plate','M81 256 L94 254 102 258 113 257 117 251 128 252 132 259 146 261 145 269 81 264Z','cameraTop'),
  S('camera-top-plate-light','M82 256 L93 255 103 259 114 258 117 253 127 254 130 260 145 262 145 264 130 262 126 256 118 255 115 261 102 261 91 258 82 259Z','cameraLight'),
  S('camera-front-body','M81 264 L106 266 113 261 127 262 132 269 145 270 144 282 140 288 83 284 79 279Z','cameraGrip'),
  S('camera-left-grip','M80 263 L91 264 95 271 93 283 83 283 78 279Z','cameraInk'),
  S('camera-bottom-trim','M82 281 L143 285 140 289 84 286 81 284Z','cameraTop'),
  S('camera-bottom-trim-light','M85 283 L104 284 106 286 86 285Z','cameraLight'),
  S('camera-viewfinder-frame','M134 263 L144 264 143 270 133 269Z','cameraShade'),
  S('camera-viewfinder','M135 264 L143 265 142 269 134 268Z','cameraInk'),
  S('camera-viewfinder-glint','M136 264 L141 265 141 266 136 266Z','lensShine'),
  S('camera-shutter-button','M90 252 L96 252 98 254 96 257 90 256 88 254Z','cameraInk'),
  S('camera-shutter-metal','M90 252 L95 252 96 254 91 254Z','cameraLight'),
  S('camera-top-dial','M103 254 L108 254 109 256 107 259 102 258 101 256Z','cameraInk'),
  S('camera-dial-highlight','M103 254 L107 254 107 255 103 255Z','cameraShade'),
  S('camera-mode-dial','M134 257 L140 257 142 260 140 262 134 261 132 259Z','cameraInk'),
  S('camera-mode-dial-glint','M134 257 L139 258 139 259 134 259Z','cameraShade'),
  S('camera-red-indicator','M105 262 L108 262 108 265 106 265Z','skinShadow'),
  S('camera-gold-front-screw','M139 273 L142 274 142 277 139 277Z','gold'),
  S('camera-lens-outer-shadow','M115 261 L125 261 135 267 140 277 136 287 126 293 114 292 104 286 101 276 105 267Z','cameraInk'),
  S('camera-lens-outer-metal','M116 262 L125 263 134 268 138 277 135 286 125 291 115 290 106 285 103 276 107 268Z','cameraTop'),
  S('camera-lens-fluted-ring','M115 265 L124 265 132 270 135 278 131 286 123 289 115 287 108 283 106 275 109 269Z','cameraInk'),
  S('camera-lens-ring-light','M115 264 L123 264 129 267 124 266 116 266 110 270 108 276 109 282 106 278 107 271Z','cameraLight'),
  S('camera-lens-ring-bottom','M113 286 L122 288 130 285 134 279 133 284 128 289 119 290Z','cameraShade'),
  S('camera-lens-optical-rim','M116 268 L123 268 129 272 132 279 128 285 121 287 115 284 111 279 112 272Z','lensMid'),
  S('camera-lens-glass','M117 270 L123 270 128 274 129 280 126 284 120 285 115 281 114 276Z','lens'),
  S('camera-lens-green-reflection','M116 272 L121 270 125 272 122 275 117 275 115 279 115 275Z','lensGreen'),
  S('camera-lens-amber-reflection','M120 279 L122 281 125 279 127 279 125 283 120 284 117 281Z','lensGold'),
  S('camera-lens-aperture','M119 274 L124 274 126 278 123 281 119 280 117 277Z','cameraInk'),
  S('camera-lens-catchlight','M117 272 L120 272 120 275 117 275Z','lensShine'),
  S('camera-lens-small-catchlight','M123 280 L125 280 125 282 123 282Z','goldLight')
 ],{pivot:[121,276]});

 const hands=G('hands-front-of-camera',[
  G('wrist-left',[
   S('left-hand-outline','M67 265 L73 256 Q80 249 86 250 L95 254 104 262 Q106 266 102 268 L95 264 87 261 84 264 Q96 266 101 273 Q102 277 98 278 L94 275 86 271 83 271 Q92 276 95 282 Q95 286 91 287 L86 283 82 278 79 276 84 284 Q85 290 80 290 L73 282 66 281 63 275Z','skinShadow'),
   S('left-hand-skin','M68 265 L75 256 Q80 252 85 252 L94 256 102 263 Q103 266 101 266 L94 262 87 259 82 263 83 266 Q92 267 99 274 Q99 276 97 276 L92 272 86 269 81 270 81 273 Q89 278 93 283 Q93 285 91 285 L86 280 81 276 77 276 77 279 82 285 Q83 288 80 288 L73 279 66 279 65 275Z','skin'),
   S('left-hand-back-light','M69 265 L76 258 82 254 87 256 88 259 80 263 77 269 75 278 69 277 67 273Z','skinLight'),
   S('left-index-knuckle-light','M89 257 L95 259 100 263 100 265 94 262 88 260Z','skinLight'),
   S('left-middle-knuckle-light','M86 267 L91 269 98 274 97 275 90 271 84 270Z','skinLight'),
   S('left-finger-creases','M81 270 L84 270 84 271 81 272Z M78 275 L81 276 80 277 78 277Z M74 261 L77 259 77 261 75 263Z','skinDeep'),
   G('left-index-tip',[
    S('left-index-nail','M99 263 L102 264 101 266 99 265Z','skinGlow')
   ],{pivot:[99,264],transform:`rotate(${s.finger} 99 264)`}),
   S('left-middle-nail','M96 274 L98 274 99 276 97 276Z','skinGlow'),
   S('left-ring-nail','M91 282 L93 283 93 285 91 284Z','skinGlow')
  ],{pivot:[70,271],transform:`rotate(${-s.settle} 70 271)`}),
  G('wrist-right',[
   S('right-hand-outline','M158 270 Q148 267 142 273 L130 280 121 284 Q116 286 119 290 L124 291 130 289 126 292 120 293 Q116 297 121 299 L126 299 Q122 302 126 304 L133 305 147 303 157 297 164 287 165 278Z','skinShadow'),
   S('right-hand-skin','M157 272 Q149 270 144 275 L131 282 122 286 Q119 287 121 289 L125 289 144 282 145 284 131 291 121 295 Q119 297 123 297 L129 296 145 290 146 292 133 298 127 300 Q125 302 130 303 L136 302 147 300 155 295 161 286 163 278Z','skin'),
   S('right-hand-back-light','M156 273 Q151 271 147 275 L151 280 150 287 145 293 148 295 154 291 160 284 160 278Z','skinLight'),
   S('right-index-light','M142 276 L146 275 147 278 134 285 125 288 122 288 122 287 133 282Z','skinLight'),
   S('right-middle-light','M143 285 L147 284 146 287 135 293 124 296 122 296 127 293Z','skinLight'),
   S('right-ring-light','M144 293 L147 292 146 295 138 299 132 301 128 301 134 298Z','skinLight'),
   S('right-thumb-fold','M147 274 L152 278 152 283 150 282 150 279 145 277Z','skinDeep'),
   S('right-index-nail','M121 286 L125 285 126 287 122 289 120 288Z','skinGlow'),
   S('right-middle-nail','M121 295 L125 294 126 296 122 297 120 297Z','skinGlow'),
   S('right-ring-nail','M128 300 L131 299 132 301 129 302 126 302Z','skinGlow'),
   G('wrist-watch',[
    S('watch-band-shadow','M162 269 L166 272 168 279 167 287 160 295 156 294 161 286 163 279 160 273Z','amberDeep'),
    S('watch-band','M162 270 L165 273 167 279 165 287 159 293 157 292 162 285 164 279 161 273Z','gold'),
    S('watch-band-links','M162 271 L164 273 163 274 161 272Z M164 275 L166 277 165 278 163 276Z M162 287 L164 288 162 290 160 289Z M159 290 L161 291 159 293 158 292Z','goldLight'),
    S('watch-case','M160 277 L168 279 166 287 158 285Z','ink'),
    S('watch-case-gold','M161 278 L167 280 165 286 159 284Z','goldLight'),
    S('watch-face','M162 279 L166 280 164 285 160 284Z','watchFace'),
    S('watch-hand','M163 280 L164 280 163 283 161 283 161 282 163 282Z','gold')
   ],{pivot:[163,282]})
  ],{pivot:[158,279],transform:`rotate(${s.settle*.65} 158 279)`})
 ]);
 return {width:W,height:H,
  back:[G('body-back-rig',[lower,leftUpper,rightUpper],{pivot:[103,216],wardrobe:s.outfit})],
  front:[G('body-rig',[core,jacketPanels,straps,forearms,camera,hands],{pivot:[103,216],wardrobe:s.outfit})]};
}
function scene(state={},palette={}){const b=bodyLayers(state,palette);return {width:W,height:H,palette:{...basePalette,...palette},layers:[...b.back,...b.front]};}
function esc(v){return String(v).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function nodeSVG(n){const a=` id="${esc(n.id)}"${n.transform?` transform="${esc(n.transform)}"`:''}${n.opacity!==undefined?` opacity="${n.opacity}"`:''}`;return n.type==='group'?`<g${a}>${n.children.map(nodeSVG).join('')}</g>`:`<path${a} fill="${esc(n.fill)}" d="${esc(n.d)}"/>`;}
function svg(state={},palette={}){return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="MIRA editable vector body and wardrobe">${scene(state,palette).layers.map(nodeSVG).join('')}</svg>`;}
function transform(ctx,t){const re=/(translate|rotate|scale)\(([^)]+)\)/g;let m;while((m=re.exec(t||''))){const a=m[2].trim().split(/[ ,]+/).map(Number);if(m[1]==='translate')ctx.translate(a[0],a[1]||0);else if(m[1]==='scale')ctx.scale(a[0],a[1]??a[0]);else{if(a.length===3)ctx.translate(a[1],a[2]);ctx.rotate(a[0]*Math.PI/180);if(a.length===3)ctx.translate(-a[1],-a[2]);}}}
function drawNode(ctx,n){ctx.save();transform(ctx,n.transform);if(n.opacity!==undefined)ctx.globalAlpha*=n.opacity;if(n.type==='group')n.children.forEach(v=>drawNode(ctx,v));else{ctx.fillStyle=n.fill;ctx.fill(new Path2D(n.d));}ctx.restore();}
function render(ctx,state={},palette={}){scene(state,palette).layers.forEach(n=>drawNode(ctx,n));}
const API={W,H,OUTFITS,basePalette,bodyLayers,scene,svg,render,normalized};
if(typeof module!=='undefined'&&module.exports)module.exports=API;root.MiraBody=API;
})(typeof window!=='undefined'?window:globalThis);
