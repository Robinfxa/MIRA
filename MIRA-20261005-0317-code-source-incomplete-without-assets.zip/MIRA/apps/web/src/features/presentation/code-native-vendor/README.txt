Editable semantic sources, review candidate only

character.js is copied byte-for-byte from MIRA face v3, SHA256 e5a5a4382f560dd595246b8206b09cc9bb56dd3aa29d7c747aee05c3e7989b2d.
body.js is copied byte-for-byte from semantic body v1, SHA256 8b59ac31abbe711a629fae2e96cdcd28b7917cb0f68d752612e34c7eac98b0c2.
No face geometry is changed by integration. The source maintains its standalone browser/CommonJS export shim; browser bundling safely uses the global browser branch. The build may report the unused CommonJS export shim as a warning.

The production code-native renderer draws these semantic paths at 192x320. It composes body back, rear hair, body front and head; the face-only shoulder study is omitted. The v3 stationary eye clip parent and movable gaze child are preserved. No PNG, generated image, traced raster, or per-pixel rectangle reconstruction is a drawing input.

This source is editable and included in the project. The readiness catalog is in apps/web/public/scene/code-native/readiness-catalog.json; tests require exact source hashes. The catalog declares review_only geometry and unavailable states. It does not certify resemblance, visual quality, real audio lip sync or browser/device performance.
