/* MIRA — hand-authored semantic geometry. No raster source, generated-image or tracing dependency.
   Coordinates: 192 × 224. Layer order and pivots are intentionally editable. */
(function(root){
'use strict';
const W=192,H=224;
const palette={ink:'#211b22',hairDark:'#38231f',hairDeep:'#4b2b24',hair:'#704032',hairMid:'#92533c',hairLight:'#bc7951',hairGold:'#e6ae72',hairCool:'#947784',skinShadow:'#b56146',skinDeep:'#d57f5b',skin:'#eead83',skinLight:'#ffd0a3',skinGlow:'#ffdfb6',blush:'#e38e75',lipDark:'#813c35',lip:'#c66856',lipLight:'#ef997c',mouth:'#4a2526',white:'#fff0d2',iris:'#bf8a2c',irisLight:'#f4c965',pupil:'#241a19',jacket:'#262936',jacketLight:'#424454',jacketDeep:'#191c27',ivory:'#eee3cb',ivoryShade:'#cabcaa',gold:'#d49c3d',goldLight:'#ffe1a0',silver:'#acb7bb'};
const shape=(id,d,color,extra={})=>({id,type:'path',d,fill:palette[color]||color,...extra});
const group=(id,children,extra={})=>({id,type:'group',children,...extra});
function stateAt(mode='idle',time=0,running=true){
 const safeTime=Number.isFinite(time)?Math.min(86400,Math.max(0,time)):0;
 mode=['idle','listen','think','speak'].includes(mode)?mode:'idle';
 const t=running?safeTime:0, active=!!running;
 const blinkPhase=((t+0.25)%4.6), blink=active&&blinkPhase>4.35? Math.max(.03,Math.abs(blinkPhase-4.475)/.125):1;
 const speak=mode==='speak'&&active;
 return {mode,time:t,running,head:active?(mode==='listen'?-1.0:mode==='think'?1.1:0)+Math.sin(t*.85)*.45:0,
  headX:active?Math.sin(t*.63)*.35:0,breath:active?Math.sin(t*1.5)*.45:0,
  eyeOpen:blink, gazeX:active?(mode==='think'?1.0:mode==='listen'?-.5:Math.sin(t*.31)*.2):0,
  brow:active&&mode==='think'?.65:active&&mode==='listen'?.25:0,
  mouth:speak?.8+(Math.sin(t*11.4)*.5+.5)*2.5:0,
  strand:active?Math.sin(t*.9-.4)*1.05:0, strand2:active?Math.sin(t*.9-.9)*1.5:0, strand3:active?Math.sin(t*.9-1.4)*1.85:0};
}
function eye(id,x,y,angle,s){
 return group(id,[
  group(id+'-aperture',[
   shape(id+'-white','M-11 0 Q-3 -6.5 7 -3.5 L11 -1.5 Q3 4 -5 3Z','white'),
   shape(id+'-iris','M-3 -4.5 Q3 -6 5 -2 L5 1 Q3 5 -1 3 Q-5 2 -3 -4.5Z','iris',{transform:`translate(${s.gazeX} 0)`}),
   shape(id+'-iris-light','M-2 0 L0 3 3 2 4 0 3 3 0 4 -2 2Z','irisLight',{transform:`translate(${s.gazeX} 0)`}),
   shape(id+'-pupil','M0 -4 L3 -3 3 1 1 2 -1 1 -1 -3Z','pupil',{transform:`translate(${s.gazeX} 0)`}),
   shape(id+'-catchlight','M-2 -2 L0 -2 0 0 -2 0Z','white',{transform:`translate(${s.gazeX} 0)`}),
   shape(id+'-upper-lid','M-12 -1 L-9 -4 -10 -7 -7 -5 -5 -7 -4 -5 Q2 -7 7 -5 L11 -8 10 -5 14 -7 11 -2 Q5 -6 -3 -4Z','ink'),
   shape(id+'-lower-lid','M-10 1 Q0 5.5 9 0 L6 3 Q-2 6 -8 3Z','skinShadow')
  ],{transform:`scale(1 ${s.eyeOpen})`}),
  shape(id+'-lid-crease','M-10 -7 Q0 -11 9 -8 L7 -7 Q0 -9 -8 -6Z','skinDeep'),
  shape(id+'-closed-lid','M-11 0 Q0 4 11 -2 L13 -4 10 -1 Q1 5 -9 2Z','ink',{opacity:s.eyeOpen<.25?1:0})
 ],{transform:`translate(${x} ${y}) rotate(${angle})`});
}
/* Manual landmark-guided source-coordinate contours from approved pixel-coarse-v2.
   No raster texture or automated pixel tessellation. Each path is one editable anatomical part. */
function referenceFace(s,shape,group){
 const skin='#fcc59d', light='#fccda8', glow='#ffdbb6', shadow='#dc805f', line='#963f32';
 const sx=.29,tx=-50.56,ty=-12.99;
 const scleraL='M428 339 Q440 325 451 325 Q470 320 488 329 Q476 339 454 346 Q439 347 428 339Z';
 const scleraR='M541 301 Q550 282 565 279 Q588 267 615 266 Q608 284 589 295 Q563 303 541 301Z';
 function eye(id,cx,cy,angle,sclera,iris,lash,lower,closed){
 return group(id,[
 group(id+'-open',[
 shape(id+'-sclera',sclera,'#fff5df'),
 group(id+'-iris-clip',[group(id+'-gaze',[
 shape(id+'-iris',iris,'#a97430'),
 shape(id+'-iris-shadow',id==='left-eye'?'M452 320 L479 320 479 331 451 331Z':'M562 275 L593 268 594 283 562 288Z','#71451f'),
 shape(id+'-iris-gold',id==='left-eye'?'M455 334 Q466 340 477 331 L475 339 466 343 459 340Z':'M565 290 Q578 294 590 284 L588 296 579 300 570 297Z','#e5ae43'),
 shape(id+'-iris-glow',id==='left-eye'?'M460 336 L466 337 472 334 470 340 464 341Z':'M572 291 L579 292 586 288 584 296 577 297Z','#ffe186'),
 shape(id+'-pupil',id==='left-eye'?'M461 322 Q467 320 470 325 L470 333 Q468 338 464 336 L460 333Z':'M573 276 Q579 273 583 278 L584 286 Q582 292 577 292 Q570 290 571 283Z','#161312'),
 shape(id+'-catchlight',id==='left-eye'?'M462 324 L467 324 467 328 463 329Z':'M573 279 L578 278 579 282 574 283Z','#fffaf0'),
 shape(id+'-catchlight-small',id==='left-eye'?'M472 331 L474 331 474 333 472 333Z':'M585 287 L588 286 588 289 585 290Z','#fff3bb')
 ],{transform:`translate(${s.gazeX*2} 0)`})],{clip:sclera}),
 shape(id+'-lower-lid',lower,'#d7735b'),
 shape(id+'-upper-lid',lash,'#211615'),
 shape(id+'-eyelashes',id==='left-eye'?'M420 337 L411 334 418 331Z M427 327 L420 318 431 324Z M439 321 L432 313 443 319Z M451 318 L447 312 457 318Z':'M548 287 L542 281 552 283Z M558 279 L553 271 563 276Z M570 273 L568 266 575 271Z M582 268 L583 260 587 266Z M594 263 L599 254 599 262Z M605 260 L612 250 610 259Z M615 255 L622 246 620 255Z M617 261 L627 252 622 263 609 272Z','#201313')
 ],{transform:`translate(${cx} ${cy}) rotate(${angle}) scale(1 ${s.eyeOpen}) rotate(${-angle}) translate(${-cx} ${-cy})`,opacity:s.eyeOpen<.18?0:1}),
 shape(id+'-closed-lid',closed,'#40211e',{opacity:s.eyeOpen<.18?1:0})
 ]);
 }
 const shapes=[
 shape('ear-base','M668 250 Q685 235 703 243 Q721 246 721 269 L720 283 706 285 706 295 712 294 701 311 682 322 669 320 661 308 661 283Z','#f2a17c'),
 shape('ear-light','M679 249 Q697 241 708 255 L713 279 704 279 701 264 691 259 683 270 677 268Z','#ffc8a1'),
 shape('ear-inner','M677 257 L690 253 700 260 701 272 695 264 687 266 682 278 672 275Z','#da7558'),
 shape('ear-lobe','M671 291 L688 298 701 294 694 305 680 315 667 318Z','#ffcea6'),
 shape('face-outline','M430 211 L452 198 476 188 498 183 518 181 531 193 541 215 555 236 574 247 598 250 618 263 636 283 647 307 655 337 660 361 Q659 388 638 411 L613 438 592 456 577 474 569 480 545 480 528 470 508 459 484 444 460 425 443 408 429 386 418 364 412 343 415 316 422 288 423 260 426 239Z','#643024'),
 shape('face-base','M433 213 L455 201 478 191 501 186 517 184 529 196 538 217 552 236 571 250 596 253 615 265 632 284 642 308 650 337 655 360 Q654 386 634 409 L610 434 589 453 574 470 566 474 546 474 531 465 511 455 487 441 464 422 447 405 434 383 423 362 417 342 420 317 427 289 428 260 431 239Z',skin),
 shape('forehead-light','M438 215 L475 194 511 188 526 197 543 231 552 239 535 252 510 279 490 300 466 279 442 263 433 242Z',light),
 shape('cheek-center-light','M489 318 Q515 325 529 318 Q570 318 610 294 L635 306 646 342 641 369 617 403 587 432 561 454 544 452 517 438 491 417 472 389 468 359Z',light,{opacity:.45}),
 shape('face-left-shadow','M420 320 L427 339 431 360 441 381 453 401 469 421 488 438 466 423 447 405 434 383 423 362 417 342Z',shadow,{opacity:.48}),
 shape('right-jaw-warmth','M650 342 L655 362 Q654 386 634 409 L610 434 589 453 574 470 566 474 549 474 565 470 582 451 605 429 627 405 643 380Z','#efaa82',{opacity:.42}),
 shape('left-cheek-blush','M431 344 Q450 335 472 346 Q484 352 485 365 Q464 379 439 367Z','#f08e74',{opacity:.23}),
 shape('right-cheek-blush','M555 304 Q592 285 626 303 L635 320 Q608 335 579 330Z','#ef9279',{opacity:.20}),
 shape('left-eye-socket','M424 312 Q447 298 470 308 Q491 312 497 334 L488 335 Q474 317 450 318 L426 326Z','#eaa285',{opacity:.62}),
 shape('right-eye-socket','M537 291 Q546 271 568 262 L603 249 619 257 616 265 Q586 269 565 284 L542 304Z','#e79579',{opacity:.70}),
 shape('left-brow','M421 299 L438 287 451 285 468 291 470 296 456 297 443 294 424 305Z','#633626'),
 shape('right-brow','M514 264 L534 253 552 241 563 239 566 244 553 250 537 260 520 270 514 271Z','#633626'),
 eye('left-eye',465.5,330,-9,scleraL,
 'M451 321 Q464 315 478 323 L478 333 Q474 343 465 344 Q453 342 451 332Z',
 'M418 338 Q433 316 451 316 Q473 316 489 329 L486 332 Q471 323 454 324 Q436 326 423 343 L417 343Z',
 'M427 342 Q443 350 455 345 L465 343 479 335 475 341 468 345 465 350 462 346 454 349 451 353 448 349 440 349 437 353 435 347 427 347Z',
 'M420 338 Q446 352 480 333 L488 329 484 333 Q450 359 421 343Z'),
 eye('right-eye',577,285,-25,scleraR,
 'M561 278 Q574 269 591 274 L593 286 Q590 299 579 302 Q565 303 561 290Z',
 'M539 297 Q550 277 575 270 Q593 264 614 257 L620 253 617 262 Q595 272 577 277 Q556 284 543 301 L539 306Z',
 'M542 303 L551 301 557 300 561 305 564 301 572 301 577 304 578 299 586 298 590 300 593 293 601 288 603 290 606 282 614 272 611 282 604 292 591 300 576 305 558 306 544 309Z',
 'M541 301 Q574 304 608 275 L619 262 616 268 Q585 311 543 305Z'),
 shape('nose-soft-shade','M506 341 Q511 348 510 360 L513 369 521 374 527 375 524 379 514 375 508 369 505 358Z','#dc8566',{opacity:.62}),
 shape('nose-tip','M510 361 L515 367 522 371 523 375 518 374 510 369 507 363Z','#e88d6a'),
 shape('nose-highlight','M516 357 L522 357 521 361 517 363 514 362Z','#ffe6c7'),
 shape('nose-nostril','M535 366 L539 364 544 364 544 366 538 368 534 368Z','#b65340'),
 shape('nose-right-soft','M540 369 L548 367 544 374 538 376Z','#f3b28a',{opacity:.7}),
 shape('philtrum','M549 381 L551 387 548 389 546 386Z','#efb088',{opacity:.5}),
 shape('upper-lip','M519 414 L527 407 534 401 538 398 546 396 552 391 559 391 563 393 572 391 581 387 579 394 569 398 559 402 550 405 541 406 531 412Z','#ef9277'),
 shape('mouth-cavity',`M520 414 Q530 413 540 406 L549 404 560 401 571 396 581 387 L581 391 Q567 ${403+s.mouth*2.4} 553 ${406+s.mouth*3} Q535 ${415+s.mouth*2.4} 522 417Z`,'#9b4131'),
 shape('lower-lip',`M523 ${417+s.mouth*2.4} Q531 ${420+s.mouth*2.4} 537 ${426+s.mouth*2.4} L547 ${430+s.mouth*2.4} 556 ${427+s.mouth*2.4} 564 ${421+s.mouth*2.4} 570 ${411+s.mouth*2.4} 574 ${400+s.mouth*2.4} 561 ${406+s.mouth*2.4} 549 ${409+s.mouth*2.4} 538 ${412+s.mouth*2.4}Z`,'#f69d7e'),
 shape('lower-lip-shadow',`M537 ${426+s.mouth*2.4} L547 ${428+s.mouth*2.4} 558 ${424+s.mouth*2.4} 564 ${419+s.mouth*2.4} 559 ${426+s.mouth*2.4} 548 ${431+s.mouth*2.4} 540 ${431+s.mouth*2.4}Z`,'#df8b70',{opacity:.6}),
 shape('lip-highlight',`M533 ${416+s.mouth*2.4} L538 ${415+s.mouth*2.4} 538 ${417+s.mouth*2.4} 534 ${418+s.mouth*2.4}Z M548 ${412+s.mouth*2.4} L553 ${410+s.mouth*2.4} 555 ${411+s.mouth*2.4} 550 ${414+s.mouth*2.4}Z`,'#ffd3b1',{opacity:.8}),
 shape('lip-right-highlight',`M561 ${407+s.mouth*2.4} L563 ${406+s.mouth*2.4} 562 ${408+s.mouth*2.4}Z`,'#ffe0bf'),
 shape('chin-highlight','M542 448 Q556 455 574 446 L565 459 555 464 545 460Z','#ffd5af',{opacity:.22}),
 shape('right-sideburn','M638 283 L644 300 646 321 642 342 634 357 626 367 632 368 640 358 647 343 652 321 649 302 646 290Z','#70402e')
 ];
 return group('face-reference-fit',shapes,{transform:`translate(${tx} ${ty}) scale(${sx})`});
}

function scene(s){
 const backHair=group('hair-back',[
 shape('hair-silhouette','M37 178 Q18 175 21 156 Q7 157 13 139 Q-1 133 14 111 Q6 100 20 81 Q14 60 30 46 Q25 31 44 24 Q52 9 75 12 Q88 0 106 12 Q120 3 135 20 Q153 15 166 35 Q178 47 167 65 Q188 79 177 98 Q191 113 180 128 Q198 144 181 162 Q188 181 165 187 L53 194Z','hairDark'),
 shape('left-volume','M83 14 Q53 14 41 33 Q36 47 26 60 Q20 79 27 88 Q39 79 44 66 Q40 93 21 108 Q12 119 22 130 Q30 114 44 109 Q40 132 22 147 Q28 165 44 158 Q33 173 44 187 L69 179 Q61 148 74 125 L83 52Z','hair'),
 shape('left-light-ribbon','M82 16 Q52 17 47 36 Q43 49 34 58 Q27 69 29 78 Q40 56 51 49 Q55 29 82 23Z','hairLight'),
 shape('left-ribbon-gold','M74 18 Q53 24 51 35 L45 49 39 54 Q48 42 48 33 Q56 20 74 18Z','hairGold'),
 shape('left-flow-shadow','M53 57 Q57 87 33 107 Q16 122 23 128 Q35 113 44 113 Q64 86 63 63Z','hairDeep'),
 shape('left-flow-light','M51 63 Q43 91 25 105 Q13 119 21 129 L27 126 Q22 120 31 111 Q57 94 58 70Z','hairLight'),
 shape('left-bottom-sweep','M48 107 Q52 125 30 144 Q33 155 45 149 Q61 139 67 124 Q65 148 48 157 Q37 173 47 180 Q68 176 74 153 L79 134Z','hairMid'),
 shape('left-bottom-light','M48 123 Q43 138 33 144 Q39 150 51 141 L62 129 Q56 145 46 149 L40 153 Q27 156 26 145Z','hairLight'),
 shape('right-volume','M107 15 Q127 8 143 27 Q162 24 167 48 Q161 60 170 72 Q187 83 169 100 Q179 118 183 120 Q188 134 176 143 Q191 160 172 175 L151 161 143 110 128 64Z','hair'),
 shape('right-shadow-ribbon','M125 19 Q143 20 149 37 Q162 48 154 59 Q158 76 170 82 L169 91 Q145 76 141 62 L139 37Z','hairDeep'),
 shape('right-cool-rim','M148 30 L158 38 161 49 159 58 Q161 72 174 81 L173 88 Q156 76 154 60 L156 48 148 37Z','hairCool'),
 shape('right-middle-wave','M151 82 Q163 101 177 109 Q181 120 175 126 Q157 119 148 102 L140 86Z','hairMid'),
 shape('right-rim','M167 100 L179 111 Q185 123 175 128 L170 126 Q179 120 175 115 L164 105Z','hairCool'),
 shape('right-bottom-wave','M146 116 Q157 138 176 142 Q183 154 172 165 Q168 150 157 147 L141 137Z','hairDeep'),
 shape('right-bottom-light','M153 119 Q162 135 176 139 L180 149 177 157 Q176 143 166 141 Q150 132 153 119Z','hairLight')
 ]);
 const torso=group('shoulder-study',[
 shape('neck-outline','M83 121 L122 115 132 153 157 166 151 220 52 220 44 175 74 153Z','ink'),
 shape('neck','M88 118 L120 115 Q119 143 130 154 L144 162 129 188 99 193 68 166 79 155 Q91 142 88 118Z','skin'),
 shape('neck-shadow','M88 119 L113 126 94 151 96 163 81 152 Q90 137 88 119Z','skinDeep'),
 shape('neck-light','M119 123 Q116 148 127 157 L133 161 118 180 99 174 99 161 110 148Z','skinLight'),
 shape('camisole','M65 164 L79 174 105 196 133 173 147 166 158 224 48 224Z','ivory'),
 shape('camisole-shade','M70 178 L105 203 133 180 116 210 106 215Z','ivoryShade'),
 shape('camisole-edge','M69 168 L77 172 105 195 135 171 141 169 136 178 106 201 74 179Z','white'),
 shape('jacket-left','M70 153 L45 160 Q24 172 20 201 L18 224 73 224 80 190 61 176Z','jacketDeep'),
 shape('jacket-left-plane','M43 165 L57 161 55 178 70 200 65 224 26 224 29 192Z','jacket'),
 shape('jacket-left-lapel','M69 150 L57 174 72 189 58 187 63 204 42 182 44 162Z','jacketLight'),
 shape('jacket-left-trim','M67 154 L57 173 70 188 56 184 61 199 43 180 44 164 46 162 46 180 58 195 53 180 64 184 53 174Z','gold'),
 shape('jacket-right','M127 149 L152 156 Q176 164 181 193 L187 224 144 224 132 194Z','jacketDeep'),
 shape('jacket-right-plane','M151 162 L170 174 177 191 181 224 153 224 139 190Z','jacket'),
 shape('jacket-right-lapel','M128 148 L152 157 158 177 146 177 158 194 141 191 132 174Z','jacketLight'),
 shape('jacket-right-trim','M130 151 L150 159 155 175 142 174 154 191 148 190 138 173 152 173 148 160Z','gold'),
 shape('necklace','M78 161 L89 179 107 188 125 176 135 160 133 167 125 179 107 191 88 182Z','gold'),
 shape('pendant','M104 189 L111 189 114 194 111 200 104 200 101 194Z','gold'),
 shape('pendant-light','M105 190 L109 190 112 194 108 194 108 198 106 198 106 194 103 194Z','goldLight'),
 shape('jacket-studs','M59 192 L62 193 61 196 58 195Z M150 181 L153 181 154 184 151 185Z','goldLight')
 ],{transform:`translate(0 ${s.breath})`});
 const face=referenceFace(s,shape,group);
 const fringe=group('hair-front',[
 shape('crown-left','M49 36 Q51 12 76 13 Q91 4 103 16 L106 33 L101 40 Q91 40 82 46 L76 49 75 55 72 63 72 66 73 70 71 73 70 80 70 89 Q61 88 51 93 Q38 100 26 99 Q52 93 55 68 Q45 83 27 86 Q49 60 49 36Z','hair'),
 shape('crown-left-shadow','M94 17 L103 19 102 34 Q91 43 79 47 L73 49 70 64 72 77 65 86 54 92 42 95 Q68 81 69 58 Q75 27 94 17Z','hairDeep'),
 shape('crown-left-light','M52 35 Q62 16 82 18 L94 14 Q77 23 70 37 Q66 51 56 61 Q45 75 31 82 Q48 65 52 47Z','hairLight'),
 shape('crown-left-glint','M57 34 Q65 21 79 22 L72 29 64 38 61 49 53 60 42 69 50 56Z','hairGold'),
 shape('face-frame-left','M84 40 Q73 50 65 66 Q52 86 25 91 L23 91 Q38 99 56 88 Q70 75 74 59 L79 48Z','hairMid'),
 shape('face-frame-left-highlight','M73 50 Q62 81 35 92 L25 92 Q49 97 63 80 L70 66Z','hairLight'),
 shape('crown-right','M101 17 Q115 7 130 21 Q145 26 153 42 Q148 52 140 53 Q147 61 155 66 L148 72 Q137 71 126 62 L114 52 Q105 41 103 32 L99 29Z','hair'),
 shape('crown-right-shadow','M105 26 Q119 21 130 31 L142 42 134 44 Q121 32 110 36 L107 40 103 35Z','hairDeep'),
 shape('crown-right-light','M105 19 Q118 14 130 24 Q143 27 149 39 L141 34 131 30 121 23 113 24 104 29Z','hairLight'),
 shape('right-face-fringe','M109 37 Q122 38 130 49 Q134 57 147 64 L151 69 Q138 68 126 58 L116 47 110 43 104 40Z','hairMid'),
 shape('right-face-fringe-shadow','M109 43 Q116 42 122 51 L129 59 143 67 139 69 Q127 64 119 55 L108 48Z','hairDeep'),
 shape('right-face-fringe-glint','M116 38 Q128 40 133 50 L140 59 133 56 127 47 119 43Z','hairLight'),

 group('camera-hair-clip',[
 shape('camera-outline','M-9 -7 L-6 -8 -5 -10 3 -10 5 -7 10 -7 10 6 -9 6Z','ink'),
 shape('camera-gold-body','M-8 -6 L-5 -7 -4 -9 2 -9 4 -6 9 -6 9 5 -8 5Z','gold'),
 shape('camera-light','M-7 -5 L7 -5 7 -3 -5 -3 -5 4 -7 4Z','goldLight'),
 shape('camera-inset','M-4 -4 L5 -4 7 -2 7 2 4 4 -3 4 -5 1 -5 -2Z','silver'),
 shape('camera-lens','M-1 -3 L3 -3 5 -1 5 2 2 3 -1 2 -3 0Z','ink'),
 shape('camera-reflection','M0 -2 L2 -2 2 -1 0 0Z','white')
 ],{transform:'translate(145 36) rotate(-12)'}),
 group('reference-positioned-earring',[
 shape('earring-outline','M136 96 L141 96 142 106 138 111 132 109 131 102 134 98Z','hairDark'),
 shape('earring','M136 96 L138 97 135 101 135 106 138 107 140 105 140 98 142 99 143 106 138 111 133 109 132 102Z','gold'),
 shape('earring-glint','M136 98 L137 99 134 103 135 108 133 107 133 102Z','goldLight')
 ],{transform:'translate(12 -8)'})
 ]);
 const strand=group('articulated-lock-root',[
 shape('lock-root','M-8 -8 Q-15 11 -10 25 L-1 32 10 20 11 7 4 -12Z','hairDeep'),
 shape('lock-root-body','M-6 -6 Q-12 10 -6 21 L-1 26 6 18 8 4 3 -9Z','hair'),
 shape('lock-root-highlight','M-5 -1 Q-8 11 -2 19 L1 19 -2 22 Q-12 15 -5 -1Z','hairLight'),
 group('articulated-lock-middle',[
 shape('lock-mid','M-5 -6 Q7 6 3 18 Q-4 34 -19 28 Q-30 22 -22 10 Q-27 26 -14 23 Q-2 21 -5 7Z','hairDark'),
 shape('lock-mid-body','M-4 -5 Q10 10 1 20 Q-7 33 -20 26 Q-29 22 -24 14 Q-25 23 -14 23 Q-2 18 -5 7Z','hair'),
 shape('lock-mid-highlight','M0 0 Q10 16 -5 24 Q-15 30 -23 23 L-24 19 Q-13 27 -4 20 Q3 13 0 0Z','hairLight'),
 group('articulated-lock-tip',[
 shape('lock-tip','M-9 -7 Q4 2 -2 12 Q-10 24 -27 14 Q-35 9 -30 0 Q-31 11 -19 11 Q-7 10 -9 -7Z','hairDeep'),
 shape('lock-tip-light','M-6 -4 Q4 11 -13 16 Q-22 17 -29 9 Q-18 15 -9 9 Q-4 5 -6 -4Z','hairMid'),
 shape('lock-tip-glint','M-4 3 Q-8 17 -23 12 L-17 13 Q-9 12 -4 3Z','hairLight')
 ],{transform:`translate(-5 22) rotate(${s.strand3})`,pivot:[-5,22]})
 ],{transform:`translate(-1 21) rotate(${s.strand2})`,pivot:[-1,21]})
 ],{transform:`translate(71 107) rotate(${s.strand})`,pivot:[71,107]});
 return {width:W,height:H,palette,layers:[torso,group('head-rig',[backHair,face,fringe,strand],{transform:`translate(${s.headX} 0) rotate(${s.head} 103 138)`})]};
}
// The rear hair is rendered behind the shoulders while sharing the head transform.
function orderedScene(s){const r=scene(s),head=r.layers[1],back=head.children.shift();r.layers.unshift(group('rear-hair-rig',[back],{transform:head.transform}));return r;}
function xml(v){return String(v).replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function nodeSVG(n){const attrs=` id="${xml(n.id)}"${n.transform?` transform="${xml(n.transform)}"`:''}${n.opacity!==undefined?` opacity="${n.opacity}"`:''}`;const clip=n.clip?`<defs><clipPath id="${n.id}-clip"><path d="${n.clip}"/></clipPath></defs>`:'';return n.type==='group'?`<g${attrs}>${clip}<g${n.clip?` clip-path="url(#${n.id}-clip)"`:''}>${n.children.map(nodeSVG).join('')}</g></g>`:`<path${attrs} fill="${n.fill}" d="${n.d}"/>`;}
function svg(s){const r=orderedScene(s);return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="MIRA code-native face and hair study">${r.layers.map(nodeSVG).join('')}</svg>`;}
function transform(ctx,t){const re=/(translate|rotate|scale)\(([^)]+)\)/g;let m;while((m=re.exec(t||''))){const a=m[2].trim().split(/[ ,]+/).map(Number);if(m[1]==='translate')ctx.translate(a[0],a[1]||0);else if(m[1]==='scale')ctx.scale(a[0],a[1]??a[0]);else {if(a.length===3)ctx.translate(a[1],a[2]);ctx.rotate(a[0]*Math.PI/180);if(a.length===3)ctx.translate(-a[1],-a[2]);}}}
function drawNode(ctx,n){ctx.save();transform(ctx,n.transform);if(n.clip)ctx.clip(new Path2D(n.clip));if(n.opacity!==undefined)ctx.globalAlpha*=n.opacity;if(n.type==='group')n.children.forEach(v=>drawNode(ctx,v));else {ctx.fillStyle=n.fill;ctx.fill(new Path2D(n.d));}ctx.restore();}
function render(ctx,s){ctx.clearRect(0,0,W,H);orderedScene(s).layers.forEach(n=>drawNode(ctx,n));}
const API={W,H,palette,stateAt,scene:orderedScene,svg,render};
if(typeof module!=='undefined'&&module.exports)module.exports=API;root.MiraCharacter=API;
})(typeof window!=='undefined'?window:globalThis);
