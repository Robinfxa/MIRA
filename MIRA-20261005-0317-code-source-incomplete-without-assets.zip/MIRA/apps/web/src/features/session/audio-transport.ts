import type { PublicConfig } from '../../shared/config.js';
import { safeHttpError, safeSessionError } from '../diagnostics/status.js';
import type { ContinuousListeningAudio, ContinuousListeningCommit, ContinuousListeningStart,
  ContinuousListeningStop, EffectView, MicrophoneAudio, MicrophoneControl, MicrophoneStart,
  SpeechStreamRequest } from '../../shared/generated/contracts.js';
import type { CapturedAudio } from '../audio/types.js';
import type { FinalTranscript, MicrophoneObservers, MicrophoneOrigin, MicrophoneStream,
  MicrophoneTimingSnapshot, ContinuousListeningReady, ContinuousListeningServerEvent,
  ContinuousListeningObservers, ContinuousListeningStream, ContinuousListeningCommitResult } from './ports.js';

export interface SessionCredentials { readonly sessionId: string; readonly token: string; }
export interface AudioTransportPrimitives {
  readonly fetch?: typeof fetch;
  readonly createSocket?: (url: string) => WebSocket;
  readonly baseUrl?: string;
  readonly now?: () => number;
  readonly setTimeout?: (callback: () => void, milliseconds: number) => number;
  readonly clearTimeout?: (id: number) => void;
}
function record(raw: unknown): Record<string, unknown> {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('Invalid voice packet');
  return raw as Record<string, unknown>;
}
function parsePacket(text: string): Record<string, unknown> {
  try { return record(JSON.parse(text)); }
  catch { throw new Error('Invalid voice packet. Text input is still available.'); }
}
function count(value: unknown): value is number { return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0; }
function isUuid(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}
function pcmBytes(encoded: unknown): Uint8Array {
  if (typeof encoded !== 'string' || encoded.length === 0 || encoded.length > 16000
    || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(encoded)) throw new Error('Invalid PCM packet');
  const decoded = atob(encoded);
  if (decoded.startsWith('RIFF') && decoded.slice(8, 12) === 'WAVE') throw new Error('WAV containers are not raw PCM');
  if (decoded.length === 0 || decoded.length > 12000 || decoded.length % 2 !== 0 || btoa(decoded) !== encoded) throw new Error('Invalid PCM packet');
  return Uint8Array.from(decoded, value => value.charCodeAt(0));
}
function encode(bytes: Uint8Array): string {
  let text = '';
  for (const value of bytes) text += String.fromCharCode(value);
  return btoa(text);
}
function cancelled(): Error { return new Error('Voice operation cancelled'); }

/** Bounded browser transports. The sink remains the only audio playback owner. */
export class BrowserAudioTransport {
  private closed = false;
  private readonly requests = new Set<AbortController>();
  private readonly microphones = new Set<MicrophoneStream>();
  private readonly continuousStreams = new Set<ContinuousListeningStream>();
  constructor(private readonly config: PublicConfig,
    private readonly credentials: () => SessionCredentials,
    private readonly primitives: AudioTransportPrimitives = {}) {}

  async speech(effect: EffectView, signal: AbortSignal, onPcm: (pcm: Int16Array) => void | Promise<void>): Promise<void> {
    if (this.closed || signal.aborted) throw cancelled();
    if (effect.kind !== 'speech') throw new Error('Speech requires an explicit speech grant');
    const credentials = this.credentials();
    const abort = new AbortController();
    this.requests.add(abort);
    const combined = AbortSignal.any([signal, abort.signal]);
    const timeout = setTimeout(() => abort.abort(), 330000);
    let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
    const cancelReader = () => { void reader?.cancel().catch(() => {}); };
    combined.addEventListener('abort', cancelReader, {once: true});
    try {
      const response = await (this.primitives.fetch ?? globalThis.fetch)(
        `${this.config.apiBase}/sessions/${encodeURIComponent(credentials.sessionId)}/speech/${encodeURIComponent(effect.id)}/stream`, {
          method: 'POST', headers: {'Content-Type': 'application/json', 'X-Mira-Session-Token': credentials.token},
          body: JSON.stringify({digest: effect.digest, output_epoch: effect.output_epoch, activity_seq: effect.activity_seq} satisfies SpeechStreamRequest),
          signal: combined, cache: 'no-store', redirect: 'error',
        });
      if (combined.aborted || this.closed) throw cancelled();
      if (response.body) reader = response.body.getReader();
      if (!response.ok) throw new Error(safeHttpError(response.status, response.headers.get('x-request-id')));
      if (!response.headers.get('content-type')?.startsWith('application/x-ndjson') || !response.body) {
        throw new Error('Speech transport unavailable. Text input is still available.');
      }
      if (!reader) throw new Error('Speech response has no body');
      const decoder = new TextDecoder('utf-8', {fatal: true});
      let pending = '', sequence = 1, samples = 0, complete = false;
      while (true) {
        const part = await reader.read();
        if (combined.aborted || this.closed) throw cancelled();
        if (part.done) break;
        if (part.value.byteLength > 262144) throw new Error('Speech transport chunk exceeded its bound');
        pending += decoder.decode(part.value, {stream: true});
        let newline: number;
        while ((newline = pending.indexOf('\n')) !== -1) {
          if (newline > 20000 || complete) throw new Error('Invalid speech stream terminal or line bound');
          const line = pending.slice(0, newline);
          pending = pending.slice(newline + 1);
          const packet = parsePacket(line);
          if (packet['effect_id'] !== effect.id || packet['stream_id'] !== effect.id || packet['digest'] !== effect.digest
            || packet['activity_seq'] !== effect.activity_seq || packet['output_epoch'] !== effect.output_epoch) throw new Error('Speech origin mismatch');
          if (packet['type'] === 'audio') {
            if (packet['sequence'] !== sequence || packet['first_sample'] !== samples || packet['sample_rate_hz'] !== 24000) throw new Error('Discontinuous or unsupported speech audio');
            const bytes = pcmBytes(packet['pcm_base64']);
            samples += bytes.length / 2;
            if (samples > 24000 * 300) throw new Error('Speech duration exceeded its bound');
            const pcm = new Int16Array(bytes.length / 2), data = new DataView(bytes.buffer);
            for (let i = 0; i < pcm.length; i++) pcm[i] = data.getInt16(i * 2, true);
            await onPcm(pcm); // Backpressure is owned by the single bounded sink coordinator.
            if (combined.aborted || this.closed) throw cancelled();
            sequence++;
          } else if (packet['type'] === 'complete') {
            if (samples === 0 || packet['total_samples'] !== samples) throw new Error('Speech completion did not match received audio');
            complete = true;
          } else if (packet['type'] === 'error') {
            throw new Error(safeSessionError(packet['code'], Object.hasOwn(packet, 'diagnostic_id') ? packet['diagnostic_id'] : null));
          } else throw new Error('Unknown speech packet');
        }
        if (pending.length > 20000) throw new Error('Speech line exceeded its bound');
      }
      pending += decoder.decode();
      if (pending.length !== 0 || !complete) throw new Error('Speech stream ended without verified completion');
    } finally {
      clearTimeout(timeout);
      combined.removeEventListener('abort', cancelReader);
      cancelReader(); abort.abort();
      this.requests.delete(abort);
    }
  }

  microphone(origin: MicrophoneOrigin, signal: AbortSignal,
      observers: MicrophoneObservers = {}): MicrophoneStream {
    if (this.closed || signal.aborted) throw cancelled();
    const credentials = this.credentials();
    const setTimer = this.primitives.setTimeout ?? globalThis.setTimeout;
    const clearTimer = this.primitives.clearTimeout ?? globalThis.clearTimeout;
    const now = this.primitives.now ?? (() => performance.now());
    const url = new URL(`${this.config.apiBase}/sessions/${encodeURIComponent(credentials.sessionId)}/microphone`,
      this.primitives.baseUrl ?? globalThis.location.href);
    if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('Invalid microphone endpoint');
    url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
    const socket = (this.primitives.createSocket ?? (address => new WebSocket(address)))(url.href);
    let alive = true, opened = false, authenticated = false, sealed = false, finishSent = false;
    let nextSequence = 0, samples = 0, queuedBytes = 0, revision = 0;
    const nowAtStart = now();
    const timingOriginMs = typeof observers.timingOriginMs === 'number'
      && Number.isFinite(observers.timingOriginMs) && observers.timingOriginMs >= 0
      ? observers.timingOriginMs : nowAtStart;
    let firstRevisionMs: number | undefined, firstFinalRevisionMs: number | undefined;
    let clientFinishMs: number | undefined, streamCloseMs: number | undefined;
    let revisionCount = 0, finalRevisionCount = 0;
    const elapsedMs = (at = now()) => Number.isFinite(at) ? Math.max(0, at - timingOriginMs) : 0;
    const timing = (): MicrophoneTimingSnapshot => Object.freeze({
      stream_id: origin.stream_id, dispatch_ms: elapsedMs(nowAtStart),
      ...(firstRevisionMs === undefined ? {} : {first_revision_ms: firstRevisionMs}),
      ...(firstFinalRevisionMs === undefined ? {} : {first_final_revision_ms: firstFinalRevisionMs}),
      ...(clientFinishMs === undefined ? {} : {client_finish_ms: clientFinishMs}),
      ...(streamCloseMs === undefined ? {} : {stream_close_ms: streamCloseMs}),
      revision_count: revisionCount, final_revision_count: finalRevisionCount,
    });
    const notifyTiming = () => { try { observers.onTiming?.(timing()); } catch { /* Observation cannot affect transport. */ } };
    const clearPreview = () => { try { observers.onRevision?.(null); } catch { /* UI observation cannot affect transport. */ } };
    notifyTiming();
    const queue: {text: string; frames: number}[] = [];
    let readyAt = 0, nextSendAt = 0, sentSamples = 0;
    let drainTimer: ReturnType<typeof setTimeout> | null = null;
    let finishTimer: ReturnType<typeof setTimeout> | null = null;
    let resolveReady!: () => void, rejectReady!: (error: Error) => void;
    let resolveFinal!: (result: FinalTranscript) => void, rejectFinal!: (error: Error) => void;
    const ready = new Promise<void>((resolve, reject) => { resolveReady = resolve; rejectReady = reject; });
    const final = new Promise<FinalTranscript>((resolve, reject) => { resolveFinal = resolve; rejectFinal = reject; });
    // Consumers may cancel before they reach their await; still expose the same rejecting promises.
    void ready.catch(() => {}); void final.catch(() => {});
    const authTimer = setTimer(() => fail(new Error('Microphone connection timed out. Use text input.')), 10000);
    const lifetimeTimer = setTimer(() => fail(new Error('Microphone session exceeded its time limit. Use text input.')), 90000);
    const cleanup = () => {
      if (!alive) return;
      alive = false;
      clearPreview();
      streamCloseMs = elapsedMs(); notifyTiming();
      clearTimer(authTimer); clearTimer(lifetimeTimer);
      if (drainTimer !== null) clearTimer(drainTimer);
      if (finishTimer !== null) clearTimer(finishTimer);
      queue.length = 0; queuedBytes = 0;
      signal.removeEventListener('abort', onAbort);
      socket.onopen = null; socket.onmessage = null; socket.onerror = null; socket.onclose = null;
      try { socket.close(); } catch { /* All local state is already invalidated. */ }
      this.microphones.delete(stream);
    };
    const fail = (error: Error) => {
      if (!alive) return;
      cleanup(); rejectReady(error); rejectFinal(error);
    };
    const drain = () => {
      if (!alive || !authenticated) return;
      if (signal.aborted || this.closed) { stream.cancel(); return; }
      if (drainTimer !== null) { clearTimer(drainTimer); drainTimer = null; }
      try {
        const clock = now();
        const head = queue[0];
        const leadReadyAt = head ? readyAt + Math.max(0, (sentSamples + head.frames - 1920) / 16) : clock;
        // Pace against send-start monotonic time, never against old capture timestamps.
        // One chunk per duration avoids turning a delayed stop/handshake into a burst.
        if (head && socket.bufferedAmount === 0 && clock >= Math.max(nextSendAt, leadReadyAt)) {
          queue.shift(); queuedBytes -= head.text.length;
          socket.send(head.text); sentSamples += head.frames;
          nextSendAt = clock + head.frames / 16;
        }
        if (sealed && queue.length === 0 && socket.bufferedAmount === 0 && !finishSent) {
          finishSent = true;
          socket.send(JSON.stringify({type: 'finish'} satisfies MicrophoneControl));
          finishTimer = setTimer(() => fail(new Error('Final transcript timed out. Use text input.')), 15000);
        }
        if (queue.length || (sealed && !finishSent)) {
          const next = queue[0];
          const leadAt = next ? readyAt + Math.max(0, (sentSamples + next.frames - 1920) / 16) : clock;
          const delay = socket.bufferedAmount > 0 ? 10 : Math.max(1, Math.ceil(Math.max(nextSendAt, leadAt) - now()));
          drainTimer = setTimer(drain, delay);
        }
      } catch { fail(new Error('Microphone transport failed. Use text input.')); }
    };
    const onAbort = () => stream.cancel();
    const stream: MicrophoneStream = {
      ready, completion: final,
      send: (chunk: CapturedAudio) => {
        if (!alive || sealed) throw cancelled();
        if (!(chunk.pcm16le instanceof Uint8Array) || chunk.pcm16le.length === 0 || chunk.pcm16le.length > 12000
          || chunk.pcm16le.length % 2 !== 0 || chunk.sampleRate !== 16000 || chunk.channels !== 1
          || chunk.sequence !== nextSequence || chunk.startSample !== samples
          || chunk.endSample !== samples + chunk.pcm16le.length / 2 || chunk.endSample > 16000 * 60) {
          const error = new Error('Invalid or overlong microphone audio'); fail(error); throw error;
        }
        const packet = JSON.stringify({type: 'audio', sequence: nextSequence + 1, first_sample: samples, pcm_base64: encode(chunk.pcm16le)} satisfies MicrophoneAudio);
        if (queuedBytes + packet.length > 65536 || queue.length >= 100) {
          const error = new Error('Microphone queue overflow. Use text input.'); fail(error); throw error;
        }
        queue.push({text: packet, frames: chunk.pcm16le.length / 2}); queuedBytes += packet.length; nextSequence++; samples = chunk.endSample;
        drain();
      },
      finish: (clientFinishAtMs?: number) => {
        if (alive) {
          sealed = true;
          clientFinishMs = elapsedMs(typeof clientFinishAtMs === 'number' && Number.isFinite(clientFinishAtMs)
            && clientFinishAtMs >= 0 ? clientFinishAtMs : now());
          clearPreview(); notifyTiming(); drain();
        }
        return final;
      },
      cancel: () => {
        if (!alive) return;
        if (opened && socket.readyState === 1) { try { socket.send(JSON.stringify({type: 'cancel'} satisfies MicrophoneControl)); } catch { /* Closing next. */ } }
        fail(cancelled());
      },
    };
    this.microphones.add(stream);
    signal.addEventListener('abort', onAbort, {once: true});
    socket.onopen = () => {
      if (!alive || signal.aborted) return;
      opened = true;
      try { socket.send(JSON.stringify({type: 'start', session_token: credentials.token, ...origin, sample_rate_hz: 16000} satisfies MicrophoneStart)); }
      catch { fail(new Error('Microphone authentication transport failed')); }
    };
    socket.onmessage = event => {
      if (!alive || signal.aborted) return;
      try {
        if (typeof event.data !== 'string' || event.data.length > 20000) throw new Error('Invalid microphone response');
        const packet = record(JSON.parse(event.data));
        if (packet['type'] === 'error') {
          fail(new Error(safeSessionError(packet['code'], Object.hasOwn(packet, 'diagnostic_id') ? packet['diagnostic_id'] : null)));
          return;
        }
        if (packet['stream_id'] !== origin.stream_id) throw new Error('Microphone response origin mismatch');
        if (packet['type'] === 'ready') {
          if (!opened || authenticated || packet['activity_seq'] !== origin.activity_seq || packet['input_epoch'] !== origin.input_epoch) throw new Error('Invalid microphone readiness');
          authenticated = true; readyAt = now(); nextSendAt = readyAt;
          clearTimer(authTimer); resolveReady(); drain();
        } else if (packet['type'] === 'transcript' || packet['type'] === 'complete') {
          if (!authenticated || !count(packet['revision']) || packet['revision'] < revision
            || typeof packet['text'] !== 'string' || packet['text'].length > 16000) throw new Error('Invalid transcript');
          if (packet['type'] === 'transcript') {
            if (packet['revision'] <= revision || typeof packet['is_final'] !== 'boolean') throw new Error('Invalid transcript finality');
            revision = packet['revision'];
            const observedAt = elapsedMs();
            firstRevisionMs ??= observedAt;
            if (packet['is_final']) { finalRevisionCount++; firstFinalRevisionMs ??= observedAt; }
            revisionCount++;
            notifyTiming();
            // This callback is a bounded UI-only preview. It cannot enter the input path.
            if (!sealed) {
              try { observers.onRevision?.({stream_id: origin.stream_id, revision, text: packet['text'].slice(0, 2000), is_final: packet['is_final']}); }
              catch { /* Observation cannot affect transport. */ }
            }
          } else {
            if (!finishSent || typeof packet['had_final'] !== 'boolean' || (!packet['had_final'] && packet['text'] !== '')) throw new Error('Unreliable transcript completion');
            revision = packet['revision'];
            const result = {text: packet['text'], had_final: packet['had_final']};
            cleanup(); resolveFinal(result);
          }
        } else throw new Error('Unknown microphone packet');
      } catch { fail(new Error('Microphone response failed validation. Use text input.')); }
    };
    socket.onerror = () => fail(new Error('Microphone connection failed. Use text input.'));
    socket.onclose = () => fail(new Error('Microphone disconnected before final transcript. Use text input.'));
    if (signal.aborted) stream.cancel();
    return stream;
  }

  /** A continuous lease is independent of reply generations and ends only on an explicit or finite stop. */
  continuousListening(leaseId: string, signal: AbortSignal,
      observers: ContinuousListeningObservers): ContinuousListeningStream {
    if (this.closed || signal.aborted) throw cancelled();
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(leaseId)) {
      throw new Error('Invalid continuous-listening lease');
    }
    const credentials = this.credentials();
    const setTimer = this.primitives.setTimeout ?? globalThis.setTimeout;
    const clearTimer = this.primitives.clearTimeout ?? globalThis.clearTimeout;
    const now = this.primitives.now ?? (() => performance.now());
    const url = new URL(`${this.config.apiBase}/sessions/${encodeURIComponent(credentials.sessionId)}/continuous-listening`,
      this.primitives.baseUrl ?? globalThis.location.href);
    if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('Invalid continuous-listening endpoint');
    // Credentials are exclusively in the first WebSocket frame, never in URL parameters.
    url.search = ''; url.hash = '';
    url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
    const socket = (this.primitives.createSocket ?? (address => new WebSocket(address)))(url.href);
    let alive = true, opened = false, authenticated = false, stopping = false, readyReceived = false, finiteSignalled = false;
    let nextSequence = 1, samples = 0, expectedChunkSequence = 0;
    let readiness: ContinuousListeningReady | null = null;
    const pendingCommits = new Map<string, {resolve: (result: ContinuousListeningCommitResult) => void;
      reject: (error: Error) => void}>();
    const completedCommits = new Set<string>();
    let readyTimer: ReturnType<typeof setTimeout> | null = null;
    let finiteTimer: ReturnType<typeof setTimeout> | null = null;
    let stopTimer: ReturnType<typeof setTimeout> | null = null;
    let resolveReady!: (value: ContinuousListeningReady) => void;
    let rejectReady!: (error: Error) => void;
    let resolveClosed!: () => void;
    const ready = new Promise<ContinuousListeningReady>((resolve, reject) => { resolveReady = resolve; rejectReady = reject; });
    const closed = new Promise<void>(resolve => { resolveClosed = resolve; });
    void ready.catch(() => {});
    const clearTimers = (): void => {
      if (readyTimer !== null) clearTimer(readyTimer);
      if (finiteTimer !== null) clearTimer(finiteTimer);
      if (stopTimer !== null) clearTimer(stopTimer);
      readyTimer = finiteTimer = stopTimer = null;
    };
    const cleanup = (): void => {
      if (!alive) return;
      alive = false; clearTimers(); signal.removeEventListener('abort', onAbort);
      for (const pending of pendingCommits.values()) pending.reject(cancelled());
      pendingCommits.clear();
      socket.onopen = null; socket.onmessage = null; socket.onerror = null; socket.onclose = null;
      try { socket.close(); } catch { /* Local lease fencing is already complete. */ }
      this.continuousStreams.delete(stream); resolveClosed();
    };
    const rejectPendingCommits = (): void => {
      for (const pending of pendingCommits.values()) pending.reject(cancelled());
      pendingCommits.clear();
    };
    const rememberCommit = (commitId: string): void => {
      completedCommits.add(commitId);
      if (completedCommits.size > 32) completedCommits.delete(completedCommits.values().next().value as string);
    };
    const fail = (error: Error): void => {
      if (!alive) return;
      cleanup();
      if (!readyReceived) rejectReady(error);
      try { observers.onError(error); } catch { /* UI observers cannot retain the lease. */ }
    };
    const localFiniteStop = (reason: 'max_duration' | 'max_samples' = 'max_duration'): void => {
      if (!alive || stopping || finiteSignalled) return;
      finiteSignalled = true;
      const event: ContinuousListeningServerEvent = {type: 'stopped', lease_id: leaseId, reason};
      try { observers.onEvent(event); } catch { /* UI observers cannot retain the lease. */ }
      void stream.stop('user_stop');
    };
    readyTimer = setTimer(() => fail(new Error('Continuous listening did not become ready in time.')), 5000);
    const stream: ContinuousListeningStream = {
      ready, closed,
      send: (chunk: CapturedAudio): void => {
        if (!alive || stopping || !authenticated || !readiness) throw cancelled();
        if (!(chunk.pcm16le instanceof Uint8Array) || chunk.pcm16le.length === 0 || chunk.pcm16le.length > 12000
          || chunk.pcm16le.length % 2 !== 0 || chunk.sampleRate !== 16000 || chunk.channels !== 1
          || chunk.sequence !== expectedChunkSequence || chunk.startSample !== samples
          || chunk.endSample !== samples + chunk.pcm16le.length / 2) {
          fail(new Error('Invalid or overlong continuous-listening audio.'));
          throw new Error('Invalid or overlong continuous-listening audio.');
        }
        if (now() >= (startedAt + readiness.max_seconds * 1000)) {
          localFiniteStop('max_duration');
          return;
        }
        if (samples + chunk.pcm16le.length / 2 > readiness.max_samples) {
          localFiniteStop('max_samples');
          return;
        }
        const audio: ContinuousListeningAudio = {type: 'audio', lease_id: leaseId, sequence: nextSequence,
          first_sample: samples, pcm_base64: encode(chunk.pcm16le)};
        const packet = JSON.stringify(audio);
        if (socket.bufferedAmount + packet.length > 65536) {
          fail(new Error('Continuous-listening delivery fell behind and was stopped.'));
          throw new Error('Continuous-listening delivery fell behind and was stopped.');
        }
        try { socket.send(packet); }
        catch { fail(new Error('Continuous-listening transport failed.')); throw new Error('Continuous-listening transport failed.'); }
        expectedChunkSequence++; nextSequence++; samples = chunk.endSample;
        if (samples >= readiness.max_samples) localFiniteStop('max_samples');
      },
      commit: (commitId: string, revision: number): Promise<ContinuousListeningCommitResult> => {
        if (!alive || stopping || !authenticated || !readiness) return Promise.reject(cancelled());
        if (!isUuid(commitId) || !count(revision) || revision < 1 || pendingCommits.has(commitId)
          || completedCommits.has(commitId) || pendingCommits.size >= 1) {
          return Promise.reject(new Error('Invalid or duplicate continuous-listening commit.'));
        }
        return new Promise<ContinuousListeningCommitResult>((resolve, reject) => {
          pendingCommits.set(commitId, {resolve, reject});
          const commit: ContinuousListeningCommit = {type: 'commit', lease_id: leaseId, commit_id: commitId, revision};
          try { socket.send(JSON.stringify(commit)); }
          catch {
            pendingCommits.delete(commitId);
            reject(new Error('Continuous-listening commit could not be sent.'));
            fail(new Error('Continuous-listening transport failed.'));
          }
        });
      },
      stop: (reason: 'user_stop' | 'permission_lost' = 'user_stop'): Promise<void> => {
        if (!alive) return closed;
        if (!opened || !authenticated || socket.readyState !== 1) {
          cleanup();
          if (!readyReceived) rejectReady(cancelled());
          return closed;
        }
        if (stopping) return closed;
        stopping = true;
        rejectPendingCommits();
        const stop: ContinuousListeningStop = {type: 'stop', lease_id: leaseId, reason};
        try { socket.send(JSON.stringify(stop)); }
        catch { cleanup(); return closed; }
        // The local capture is already stopped by its owner. Bound waiting for the server ack.
        stopTimer = setTimer(() => cleanup(), 1500);
        return closed;
      },
      cancel: (): void => {
        if (!alive) return;
        if (opened && authenticated && socket.readyState === 1 && !stopping) {
          stopping = true;
          const stop: ContinuousListeningStop = {type: 'stop', lease_id: leaseId, reason: 'user_stop'};
          try { socket.send(JSON.stringify(stop)); }
          catch { /* Socket close still releases the server-side lease. */ }
        }
        cleanup();
        if (!readyReceived) rejectReady(cancelled());
      },
    };
    const startedAt = now();
    const onAbort = (): void => { stream.cancel(); };
    this.continuousStreams.add(stream);
    signal.addEventListener('abort', onAbort, {once: true});
    socket.onopen = (): void => {
      if (!alive || signal.aborted) return;
      opened = true;
      const start: ContinuousListeningStart = {type: 'start', session_token: credentials.token, lease_id: leaseId};
      try { socket.send(JSON.stringify(start)); }
      catch { fail(new Error('Continuous-listening authentication transport failed.')); }
    };
    socket.onmessage = (event): void => {
      if (!alive || signal.aborted) return;
      try {
        if (typeof event.data !== 'string' || event.data.length > 20000) throw new Error('Invalid continuous-listening packet');
        const raw = record(JSON.parse(event.data));
        if (raw['type'] === 'error') {
          fail(new Error(safeSessionError(raw['code'], Object.hasOwn(raw, 'diagnostic_id') ? raw['diagnostic_id'] : null)));
          return;
        }
        if (raw['type'] === 'ready') {
          if (!opened || readyReceived || raw['lease_id'] !== leaseId
            || (raw['sample_rate_hz'] !== undefined && raw['sample_rate_hz'] !== 16000)
            || !count(raw['max_seconds']) || raw['max_seconds'] < 1 || raw['max_seconds'] > 120
            || !count(raw['max_samples']) || raw['max_samples'] < 1 || raw['max_samples'] > 16000 * 120
            || raw['max_samples'] > raw['max_seconds'] * 16000
            || !count(raw['max_utterances']) || raw['max_utterances'] < 1 || raw['max_utterances'] > 12
            || !count(raw['max_streams_per_session']) || raw['max_streams_per_session'] < 1 || raw['max_streams_per_session'] > 4
            || !count(raw['max_total_streams']) || raw['max_total_streams'] < 1 || raw['max_total_streams'] > 8
            || !count(raw['session_lease_starts_used']) || raw['session_lease_starts_used'] > 1000000
            || !count(raw['total_lease_starts_used']) || raw['total_lease_starts_used'] > 1000000
            || (raw['stt_requests_used'] !== undefined && raw['stt_requests_used'] !== null
              && (!count(raw['stt_requests_used']) || raw['stt_requests_used'] > 1000000))
            || (raw['stt_requests_remaining'] !== undefined && raw['stt_requests_remaining'] !== null
              && (!count(raw['stt_requests_remaining']) || raw['stt_requests_remaining'] > 1000000))
            || !['google_vad_offsets_manual_commit', 'unavailable_manual'].includes(String(raw['endpoint_mode']))
            || raw['manual_commit_required'] !== true) throw new Error('Invalid continuous-listening readiness');
          readiness = Object.freeze({lease_id: leaseId, sample_rate_hz: 16000, max_seconds: raw['max_seconds'],
            max_samples: raw['max_samples'], max_utterances: raw['max_utterances'],
            max_streams_per_session: raw['max_streams_per_session'], max_total_streams: raw['max_total_streams'],
            session_lease_starts_used: raw['session_lease_starts_used'], total_lease_starts_used: raw['total_lease_starts_used'],
            ...(raw['stt_requests_used'] === undefined ? {} : {stt_requests_used: raw['stt_requests_used'] as number | null}),
            ...(raw['stt_requests_remaining'] === undefined ? {} : {stt_requests_remaining: raw['stt_requests_remaining'] as number | null}),
            endpoint_mode: raw['endpoint_mode'] as 'google_vad_offsets_manual_commit' | 'unavailable_manual',
            manual_commit_required: true});
          authenticated = true; readyReceived = true;
          if (readyTimer !== null) clearTimer(readyTimer);
          readyTimer = null;
          finiteTimer = setTimer(localFiniteStop, readiness.max_seconds * 1000);
          resolveReady(readiness);
          try { observers.onEvent({type: 'ready', ready: readiness}); } catch { /* UI observers cannot retain the lease. */ }
          return;
        }
        if (raw['lease_id'] !== leaseId || !authenticated) throw new Error('Continuous-listening lease mismatch');
        if (stopping && raw['type'] !== 'stopped') return;
        if (raw['type'] === 'transcript') {
          if (!count(raw['revision']) || raw['revision'] < 1 || typeof raw['text'] !== 'string'
            || raw['text'].length > 16000 || typeof raw['is_final'] !== 'boolean') throw new Error('Invalid transcript frame');
          try { observers.onEvent({type: 'transcript', lease_id: leaseId, revision: raw['revision'],
            text: raw['text'].slice(0, 2000), is_final: raw['is_final']}); } catch { /* Preview is not part of transport. */ }
        } else if (raw['type'] === 'endpoint_pending') {
          if (!count(raw['revision']) || raw['revision'] < 1 || typeof raw['text'] !== 'string'
            || raw['text'].length > 16000 || !['missing_result_offset', 'unmatched_activity_end'].includes(String(raw['reason']))
            || (raw['can_submit_manually'] !== undefined && typeof raw['can_submit_manually'] !== 'boolean')) {
            throw new Error('Invalid endpoint-pending frame');
          }
          try { observers.onEvent({type: 'endpoint_pending', lease_id: leaseId, revision: raw['revision'],
            text: raw['text'].slice(0, 2000), reason: raw['reason'] as 'missing_result_offset' | 'unmatched_activity_end',
            ...(raw['can_submit_manually'] === undefined ? {} : {can_submit_manually: raw['can_submit_manually'] as boolean})}); }
          catch { /* Manual review remains separate from transport. */ }
        } else if (raw['type'] === 'commit_ready') {
          if (!isUuid(raw['commit_id']) || !count(raw['segment_seq']) || raw['segment_seq'] < 1
            || !count(raw['revision']) || raw['revision'] < 1 || typeof raw['text'] !== 'string'
            || raw['text'].length > 2000) throw new Error('Invalid commit-ready frame');
          const pending = pendingCommits.get(raw['commit_id']);
          if (!pending) {
            if (completedCommits.has(raw['commit_id'])) return;
            throw new Error('Unexpected commit-ready frame');
          }
          const result: ContinuousListeningCommitResult = {type: 'commit_ready', lease_id: leaseId,
            commit_id: raw['commit_id'], segment_seq: raw['segment_seq'], revision: raw['revision'], text: raw['text']};
          pendingCommits.delete(raw['commit_id']); rememberCommit(raw['commit_id']); pending.resolve(result);
          try { observers.onEvent(result); } catch { /* Commit still belongs to the controller. */ }
        } else if (raw['type'] === 'commit_rejected') {
          if (!isUuid(raw['commit_id']) || !count(raw['current_revision'])
            || !['stale_revision', 'no_final_text', 'request_limit', 'lease_revoked', 'identity_conflict'].includes(String(raw['reason']))) {
            throw new Error('Invalid commit-rejected frame');
          }
          const pending = pendingCommits.get(raw['commit_id']);
          if (!pending) {
            if (completedCommits.has(raw['commit_id'])) return;
            throw new Error('Unexpected commit-rejected frame');
          }
          const result: ContinuousListeningCommitResult = {type: 'commit_rejected', lease_id: leaseId,
            commit_id: raw['commit_id'], reason: raw['reason'] as 'stale_revision' | 'no_final_text' | 'request_limit' | 'lease_revoked' | 'identity_conflict',
            current_revision: raw['current_revision']};
          pendingCommits.delete(raw['commit_id']); rememberCommit(raw['commit_id']); pending.resolve(result);
          try { observers.onEvent(result); } catch { /* A stale click never triggers a hidden retry. */ }
        } else if (raw['type'] === 'stopped') {
          if (typeof raw['reason'] !== 'string' || !/^[a-z][a-z0-9_]{0,79}$/.test(raw['reason'])) {
            throw new Error('Invalid stopped frame');
          }
          const reason = raw['reason'] as Extract<ContinuousListeningServerEvent, {readonly type: 'stopped'}>['reason'];
          try { observers.onEvent({type: 'stopped', lease_id: leaseId, reason}); } catch { /* Cleanup must continue. */ }
          cleanup();
        } else throw new Error('Unknown continuous-listening frame');
      } catch {
        fail(new Error('Continuous-listening response failed validation.'));
      }
    };
    socket.onerror = (): void => fail(new Error('Continuous-listening connection failed.'));
    socket.onclose = (): void => {
      if (stopping) cleanup();
      else fail(new Error('Continuous-listening connection ended unexpectedly.'));
    };
    if (signal.aborted) stream.cancel();
    return stream;
  }
  close(): void {
    if (this.closed) return;
    this.closed = true;
    for (const request of this.requests) request.abort();
    this.requests.clear();
    for (const microphone of this.microphones) microphone.cancel();
    this.microphones.clear();
    for (const stream of this.continuousStreams) stream.cancel();
    this.continuousStreams.clear();
  }
}
