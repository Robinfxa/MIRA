import { MicrophoneCapture } from '../audio/index.js';
import type { CaptureOptions, AudioRuntimeError, CapturedAudio } from '../audio/index.js';
import type { ContinuousListeningReady, ContinuousListeningServerEvent, ContinuousListeningStream } from './ports.js';
import type { SessionInputOutcome } from './controller.js';

export type ContinuousListeningState = 'idle' | 'starting' | 'listening' | 'stopping' | 'stopped' | 'limit' | 'error' | 'closed';
export interface ContinuousTranscriptView {
  readonly lease_id: string;
  readonly revision: number;
  readonly text: string;
  readonly is_final: boolean;
  readonly endpoint_pending: boolean;
  readonly can_send: boolean;
  readonly truncated: boolean;
  readonly hint: string | null;
}
export interface ContinuousSentTextView {
  readonly commit_id: string;
  readonly segment_seq: number;
  readonly revision: number;
  readonly text: string;
  readonly state: 'sending' | 'sent' | 'not_sent' | 'unknown';
  readonly notice: string | null;
}
export interface ContinuousListeningView {
  readonly state: ContinuousListeningState;
  readonly lease_id: string | null;
  readonly ready: ContinuousListeningReady | null;
  readonly transcript: ContinuousTranscriptView | null;
  readonly previous_previews: readonly ContinuousTranscriptView[];
  readonly previous_preview_limit: number;
  readonly sent_text: readonly ContinuousSentTextView[];
  readonly notice: string | null;
  readonly error: string | null;
}
export interface ContinuousListeningControllerOptions {
  readonly createCapture?: (options: CaptureOptions) => Pick<MicrophoneCapture, 'start' | 'stop' | 'close'>;
  readonly openStream: (leaseId: string, signal: AbortSignal,
    observers: {readonly onEvent: (event: ContinuousListeningServerEvent) => void;
      readonly onError: (error: Error) => void}) => ContinuousListeningStream;
  readonly submitInput: (text: string, listeningUtteranceId?: string) => Promise<SessionInputOutcome>;
  readonly canStart?: () => boolean;
  /** Local-only reply fence; must return before capture or commit starts. */
  readonly interruptReply?: () => boolean;
  readonly onUpdate: (view: ContinuousListeningView) => void;
  readonly onPhase?: (listening: boolean) => void;
  readonly createId?: () => string;
}
interface TranscriptState extends ContinuousTranscriptView {
  readonly textLength: number;
  readonly stable: boolean;
}
interface SentText extends ContinuousSentTextView {}
interface ListeningRun {
  readonly leaseId: string;
  readonly abort: AbortController;
  readonly queue: CapturedAudio[];
  queueBytes: number;
  stream: ContinuousListeningStream | null;
  ready: ContinuousListeningReady | null;
  captured: boolean;
  stopping: boolean;
  latestRevision: number;
  staleRevisionFence: number;
  commitCount: number;
  commitInFlight: boolean;
  onsetActiveSamples: number;
  onsetQuietSamples: number;
  onsetLatched: boolean;
  preserveAcceptedCommit: boolean;
  stopPromise: Promise<void> | null;
}
type CapturePort = Pick<MicrophoneCapture, 'start' | 'stop' | 'close'>;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const hasWords = (text: string): boolean => /[\p{L}\p{N}]/u.test(text);
const MAX_PREVIOUS_PREVIEWS = 4;
// A bounded PCM energy heuristic, not speech recognition. We count about 40 ms of
// consecutive 16 kHz samples over this RMS floor and rearm after 200 ms of quiet.
const ONSET_RMS_FLOOR = 900;
const ONSET_MIN_ACTIVE_SAMPLES = 640;
const ONSET_QUIET_RESET_SAMPLES = 3200;
const MAX_ONSET_SAMPLES_PER_CHUNK = 1600;

/** The capture lease owns its lifetime separately from SessionController reply generations. */
export class ContinuousListeningController {
  private readonly capture: CapturePort;
  private readonly makeId: () => string;
  private run: ListeningRun | null = null;
  private state: ContinuousListeningState = 'idle';
  private ready: ContinuousListeningReady | null = null;
  private transcript: TranscriptState | null = null;
  private readonly previousPreviews: ContinuousTranscriptView[] = [];
  private readonly sentText: SentText[] = [];
  private notice: string | null = null;
  private error: string | null = null;
  private closed = false;
  private releasing = false;
  private inputFence = 0;

  constructor(private readonly options: ContinuousListeningControllerOptions) {
    this.makeId = options.createId ?? (() => crypto.randomUUID());
    this.capture = (options.createCapture ?? (settings => new MicrophoneCapture(settings)))({
      onChunk: chunk => this.captureChunk(chunk),
      onState: state => {
        const run = this.run;
        if (!run || run.stopping) return;
        if (state === 'recording') {
          run.captured = true;
          if (run.ready) this.setState('listening');
        }
      },
      onError: problem => this.captureError(problem),
      chunkMilliseconds: 40,
      maxPendingChunks: 8,
    });
    this.publish();
  }

  get active(): boolean { return this.run !== null && !this.run.stopping; }
  get microphoneActive(): boolean { return this.active; }

  /** Returns a retained preview for an empty-composer UI action; never submits it. */
  restorePreviousPreview(leaseId: string): string | null {
    const index = this.previousPreviews.findIndex(preview => preview.lease_id === leaseId);
    if (index < 0) return null;
    const [preview] = this.previousPreviews.splice(index, 1);
    this.publish();
    return preview?.text ?? null;
  }

  /** Starts capture synchronously in the click gesture; silence is sent as ordinary PCM frames. */
  start(): boolean {
    if (this.closed || this.releasing || this.run) return false;
    if (!this.archiveCurrentTranscript() || this.previousPreviews.length >= MAX_PREVIOUS_PREVIEWS) {
      this.notice = '上次聆听的预览已满 4 段。请先把其中一段放入空文字框并核对（不会自动发送），再开始新的监听。';
      this.publish(); return false;
    }
    if (this.options.canStart && !this.options.canStart()) {
      this.notice = '请先结束当前的按住说话输入或关闭原始开发录制，再开始连续聆听。';
      this.publish(); return false;
    }
    const leaseId = this.makeId();
    if (!UUID.test(leaseId)) { this.setError('无法开始连续聆听：会话标识无效。'); return false; }
    if (this.options.interruptReply) {
      try {
        if (!this.options.interruptReply()) {
          this.setError('当前回复未能安全停止，连续聆听没有启动。请使用“停止回应”后重试。');
          return false;
        }
      } catch {
        this.setError('当前回复未能安全停止，连续聆听没有启动。请使用“停止回应”后重试。');
        return false;
      }
    }
    const run: ListeningRun = {leaseId, abort: new AbortController(), queue: [], queueBytes: 0,
      stream: null, ready: null, captured: false, stopping: false, latestRevision: 0,
      staleRevisionFence: 0, commitCount: 0, commitInFlight: false,
      onsetActiveSamples: 0, onsetQuietSamples: 0, onsetLatched: false,
      preserveAcceptedCommit: false, stopPromise: null};
    this.run = run; this.ready = null; this.notice = null; this.error = null;
    this.state = 'starting'; this.publish();
    let capturePromise: Promise<boolean>;
    try {
      // Calling start before any await preserves the browser's user-gesture permission boundary.
      capturePromise = this.capture.start();
      run.stream = this.options.openStream(leaseId, run.abort.signal, {
        onEvent: event => this.transportEvent(run, event),
        onError: problem => this.transportError(run, problem),
      });
    } catch (problem) {
      this.failRun(run, problem instanceof Error ? problem : new Error('Continuous listening could not start.'));
      return false;
    }
    void Promise.resolve(capturePromise).then(started => {
      if (!this.current(run)) return;
      if (!started) this.failRun(run, new Error('麦克风没有启动，请检查权限后重试。'), true);
    }).catch(problem => this.failRun(run, problem instanceof Error ? problem : new Error('麦克风启动失败。'), true));
    void run.stream.ready.then(ready => {
      if (!this.current(run)) return;
      run.ready = ready; this.ready = ready;
      this.drainQueue(run);
      if (run.captured) this.setState('listening');
      else this.publish();
    }).catch(problem => {
      if (this.current(run)) this.failRun(run, problem instanceof Error ? problem : new Error('连续聆听连接失败。'));
    });
    void run.stream.closed.then(() => {
      if (this.current(run) && !run.stopping) this.failRun(run, new Error('连续聆听连接意外结束。'));
    });
    return true;
  }

  private current(run: ListeningRun): boolean { return !this.closed && this.run === run && !run.stopping; }

  private archiveCurrentTranscript(): boolean {
    const current = this.transcript;
    if (!current) return true;
    if (!hasWords(current.text)) { this.transcript = null; return true; }
    if (this.previousPreviews.some(preview => preview.lease_id === current.lease_id)) {
      this.transcript = null; return true;
    }
    if (this.previousPreviews.length >= MAX_PREVIOUS_PREVIEWS) return false;
    this.previousPreviews.push(Object.freeze({...current, can_send: false,
      hint: '上次聆听的未发送/临时预览；其中可能包含下方另列的已确认文字。请核对后再放入空文字框；不会自动发送。'}));
    this.transcript = null;
    return true;
  }

  private captureChunk(chunk: CapturedAudio): void {
    const run = this.run;
    if (!run || !this.current(run)) throw new Error('连续聆听已停止。');
    this.detectCapturedOnset(run, chunk);
    if (!this.current(run)) throw new Error('连续聆听已停止。');
    if (run.stream && run.ready) { run.stream.send(chunk); return; }
    if (run.queue.length >= 100 || run.queueBytes + chunk.pcm16le.byteLength > 65536) {
      this.failRun(run, new Error('连接尚未就绪，音频队列已达上限。'));
      throw new Error('连续聆听音频队列已达上限。');
    }
    run.queue.push({...chunk, pcm16le: chunk.pcm16le.slice()});
    run.queueBytes += chunk.pcm16le.byteLength;
  }

  /** Uses only fresh, bounded captured PCM; transcript revisions never participate. */
  private detectCapturedOnset(run: ListeningRun, chunk: CapturedAudio): void {
    const bytes = chunk.pcm16le;
    if (!(bytes instanceof Uint8Array) || bytes.byteLength < 2 || bytes.byteLength % 2 !== 0
      || bytes.byteLength > MAX_ONSET_SAMPLES_PER_CHUNK * 2 || chunk.sampleRate !== 16000 || chunk.channels !== 1) return;
    const count = bytes.byteLength / 2, view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let sumSquares = 0;
    for (let index = 0; index < count; index++) {
      const sample = view.getInt16(index * 2, true);
      sumSquares += sample * sample;
    }
    const aboveFloor = Math.sqrt(sumSquares / count) >= ONSET_RMS_FLOOR;
    if (aboveFloor) {
      run.onsetActiveSamples = Math.min(ONSET_MIN_ACTIVE_SAMPLES, run.onsetActiveSamples + count);
      run.onsetQuietSamples = 0;
    } else {
      run.onsetActiveSamples = 0;
      run.onsetQuietSamples = Math.min(ONSET_QUIET_RESET_SAMPLES, run.onsetQuietSamples + count);
      if (run.onsetQuietSamples >= ONSET_QUIET_RESET_SAMPLES) run.onsetLatched = false;
    }
    if (run.onsetLatched || run.onsetActiveSamples < ONSET_MIN_ACTIVE_SAMPLES) return;
    run.onsetLatched = true;
    try {
      if (this.options.interruptReply && !this.options.interruptReply()) {
        // A non-reply can be present while a lease is active; in that case the
        // one-shot detector stays latched, avoiding repeated work on the same sound.
        return;
      }
    } catch {
      this.failRun(run, new Error('本地回复中断未能确认，连续聆听已停止以免漏掉新输入。'));
      return;
    }
    this.notice = '检测到新的本地声音活动，已尝试中断当前回复；能量阈值可能受噪声或扬声器回声影响。';
    this.publish();
  }

  private drainQueue(run: ListeningRun): void {
    if (!this.current(run) || !run.stream || !run.ready) return;
    try {
      for (const chunk of run.queue) {
        if (!this.current(run)) return;
        run.stream.send(chunk);
      }
      run.queue.length = 0; run.queueBytes = 0;
    } catch (problem) {
      this.failRun(run, problem instanceof Error ? problem : new Error('音频发送失败。'));
    }
  }

  private transportEvent(run: ListeningRun, event: ContinuousListeningServerEvent): void {
    if (!this.current(run)) return;
    if (event.type === 'ready') {
      // The ready promise is authoritative; this frame remains observable but does not reset state.
      return;
    }
    if (event.lease_id !== run.leaseId) return;
    if (event.type === 'transcript') {
      if (event.revision <= run.latestRevision) return;
      run.latestRevision = event.revision;
      const text = event.text.slice(0, 2000);
      const truncated = event.text.length > 2000;
      const isFinal = event.is_final;
      this.transcript = Object.freeze({lease_id: run.leaseId, revision: event.revision, text,
        textLength: text.length, is_final: isFinal, endpoint_pending: false,
        stable: isFinal, can_send: (isFinal || this.transcript?.endpoint_pending === true)
          && hasWords(text) && !truncated && event.revision > run.staleRevisionFence && !run.commitInFlight,
        truncated, hint: isFinal ? '识别器标记了一个稳定片段；它不保证完整句尾。点击发送后只提交服务端确认的文字。'
          : '临时转写仍可能变化，不会自动发送。'});
      this.notice = null; this.publish();
    } else if (event.type === 'endpoint_pending') {
      if (event.revision < run.latestRevision) return;
      if (event.revision > run.latestRevision) run.latestRevision = event.revision;
      const text = event.text.slice(0, 2000), truncated = event.text.length > 2000;
      this.transcript = Object.freeze({lease_id: run.leaseId, revision: event.revision, text,
        textLength: text.length, is_final: false, endpoint_pending: true, stable: false,
        can_send: event.can_submit_manually === true && hasWords(text) && !truncated
          && event.revision > run.staleRevisionFence && !run.commitInFlight,
        truncated, hint: event.can_submit_manually === true
          ? '句末对齐尚未确认。发送前请核对；麦克风会继续聆听。'
          : '句末对齐尚未确认，当前服务器不允许手动提交；麦克风仍在聆听。'});
      this.notice = null; this.publish();
    } else if (event.type === 'commit_ready' || event.type === 'commit_rejected') {
      // commit() resolves this exact frame to the user action that initiated it.
    } else if (event.type === 'stopped') {
      const limit = ['max_duration', 'max_samples', 'utterance_limit', 'revision_limit', 'input_limit'].includes(event.reason);
      this.endRun(run, limit ? 'limit' : 'stopped', limit
          ? '本条连续聆听已到达声明的时长或发送上限。不会自动续开；如需继续，请再次点击开始。'
        : event.reason === 'user_stop' || event.reason === 'permission_lost'
          ? '连续聆听已停止。已收到的文字仍保留在这里，可继续核对。'
          : '连续聆听已结束。麦克风已释放，已收到的文字仍保留在这里。', false, 'user_stop', limit);
    }
  }

  /** User action only: asks the server to snapshot the exact visible revision before sending it. */
  async sendCurrent(): Promise<void> {
    const run = this.run, transcript = this.transcript, stream = run?.stream;
    if (!run || !this.current(run) || !stream || !transcript || transcript.lease_id !== run.leaseId
      || !transcript.can_send || run.commitInFlight) return;
    const inputFence = this.inputFence;
    const commitId = this.makeId();
    if (!UUID.test(commitId)) { this.setError('无法发送：本次请求标识无效。'); return; }
    const revision = transcript.revision;
    if (this.options.interruptReply) {
      try {
        if (!this.options.interruptReply()) {
          this.notice = '当前回复未能安全停止，已确定文字没有发送；请点“停止回应”后重试。';
          this.refreshCanSend(run); this.publish(); return;
        }
      } catch {
        this.notice = '当前回复未能安全停止，已确定文字没有发送；请点“停止回应”后重试。';
        this.refreshCanSend(run); this.publish(); return;
      }
    }
    run.commitInFlight = true;
    this.transcript = Object.freeze({...transcript, can_send: false});
    this.notice = null; this.publish();
    let result;
    try { result = await stream.commit(commitId, revision); }
    catch (problem) {
      if (this.current(run)) {
        run.commitInFlight = false;
        this.notice = '发送确认没有完成。文字仍保留；请核对当前转写后再操作。';
        this.refreshCanSend(run); this.publish();
      }
      return;
    }
    if (this.closed || inputFence !== this.inputFence
      || (!this.current(run) && !run.preserveAcceptedCommit)) return;
    run.commitInFlight = false;
    if (result.type === 'commit_rejected') {
      // A stale response names the server's current revision. Keep the requested
      // stale snapshot fenced while permitting a later explicit click on that exact one.
      run.staleRevisionFence = Math.max(run.staleRevisionFence, result.current_revision - 1);
      if (result.reason === 'request_limit') {
        this.endRun(run, 'limit', '本条连续聆听的手动发送次数已到上限。不会自动续开；如需继续，请再次点击开始。', true);
        return;
      }
      if (result.reason === 'lease_revoked') {
        this.endRun(run, 'error', '连续聆听许可已撤销，麦克风已释放。', true);
        return;
      }
      if (result.reason === 'identity_conflict') {
        this.endRun(run, 'error', '本次提交标识与服务端记录冲突；为避免重复，已停止聆听。', true);
        return;
      }
      this.notice = result.reason === 'stale_revision'
        ? '转写刚更新，请核对后再发送。'
        : '还没有服务端确认可发送的稳定文字；可以继续说或停止聆听。';
      this.refreshCanSend(run); this.publish(); return;
    }
    const item: SentText = {commit_id: result.commit_id, segment_seq: result.segment_seq,
      revision: result.revision, text: result.text, state: 'sending', notice: null};
    this.sentText.push(item); run.commitCount++;
    run.staleRevisionFence = Math.max(run.staleRevisionFence, result.revision);
    this.refreshCanSend(run);
    this.notice = '只发送了上方标记的已确定文字；后续转写仍会留在预览中。';
    this.publish();
    const reachedLimit = run.ready !== null && run.commitCount >= run.ready.max_utterances;
    const submission = this.options.submitInput(result.text, result.commit_id);
    if (reachedLimit && this.current(run)) {
      this.endRun(run, 'limit', '本条连续聆听已达到声明的手动发送上限。不会自动续开；如需继续，请再次点击开始。', false,
        'user_stop', true);
    }
    let outcome: SessionInputOutcome;
    try { outcome = await submission; }
    catch { outcome = {status: 'unknown'}; }
    this.updateSentText(item.commit_id, outcome);
  }

  private refreshCanSend(run: ListeningRun): void {
    const current = this.transcript;
    if (!current || current.lease_id !== run.leaseId) return;
    const eligible = current.stable || current.endpoint_pending;
    this.transcript = Object.freeze({...current, can_send: eligible && hasWords(current.text)
      && !current.truncated && current.revision > run.staleRevisionFence && !run.commitInFlight});
  }

  private updateSentText(commitId: string, outcome: SessionInputOutcome): void {
    const index = this.sentText.findIndex(item => item.commit_id === commitId);
    if (index < 0) return;
    const item = this.sentText[index]!;
    const state: ContinuousSentTextView['state'] = outcome.status === 'submitted' ? 'sent'
      : outcome.status === 'not-sent' ? 'not_sent' : 'unknown';
    const notice = state === 'sent' ? '已提交到 MIRA；监听是否仍开启由上方状态显示。'
      : state === 'not_sent' ? '这段文字未送出，已保留在下方。可放入文字框核对后，再由你手动发送。'
      : state === 'unknown' ? '发送结果不确定。文字已保留；为避免重复，请先检查会话状态，本页不会自动重发。'
      : outcome.status === 'superseded' ? '该发送被较新的会话操作取代。文字仍保留。'
        : outcome.status === 'closed' ? '会话已关闭，文字仍保留。' : '输入未被接受，文字仍保留。';
    this.sentText[index] = {...item, state, notice}; this.publish();
  }

  private captureError(problem: AudioRuntimeError): void {
    const run = this.run;
    if (!run) return;
    this.failRun(run, new Error(problem.message), problem.code === 'permission-denied');
  }

  private transportError(run: ListeningRun, problem: Error): void {
    if (!this.current(run)) return;
    this.failRun(run, problem);
  }

  private failRun(run: ListeningRun, problem: Error, permissionLost = false): void {
    if (!this.current(run)) return;
    this.inputFence++;
    this.error = problem.message; this.notice = null;
    this.endRun(run, 'error', problem.message, true, permissionLost ? 'permission_lost' : 'user_stop');
  }

  private endRun(run: ListeningRun, state: ContinuousListeningState, notice: string,
      sendStop: boolean, stopReason: 'user_stop' | 'permission_lost' = 'user_stop',
      preserveAcceptedCommit = false): void {
    if (this.run !== run || run.stopping) return;
    run.preserveAcceptedCommit = preserveAcceptedCommit;
    const archived = this.archiveCurrentTranscript();
    run.stopping = true; this.run = null; this.releasing = true;
    run.queue.length = 0; run.queueBytes = 0;
    try { this.capture.stop(); } catch { /* Track release is still attempted by close. */ }
    this.state = state; this.notice = archived ? notice
      : '这段预览仍保留在上方；历史已满。请先恢复一段到空文字框，再继续开始新监听。';
    this.options.onPhase?.(false); this.publish();
    const stop = sendStop && run.stream ? run.stream.stop(stopReason) : Promise.resolve();
    run.stopPromise = Promise.resolve(stop).catch(() => {}).then(() => {
      run.abort.abort(); this.releasing = false;
      if (this.closed) this.state = 'closed';
      this.publish();
    });
  }

  async stop(reason: 'user_stop' | 'permission_lost' = 'user_stop'): Promise<void> {
    this.inputFence++;
    const run = this.run;
    if (!run) return;
    this.endRun(run, 'stopping', reason === 'permission_lost'
      ? '麦克风权限已失效，已停止并释放设备。' : '已停止连续聆听；已收到的文字仍保留在这里。', true, reason);
    await run.stopPromise;
    if (!this.closed && this.state === 'stopping') this.state = 'stopped';
    this.publish();
  }

  private setState(state: ContinuousListeningState): void {
    this.state = state;
    this.options.onPhase?.(state === 'listening');
    this.publish();
  }

  private setError(message: string): void { this.error = message; this.state = 'error'; this.publish(); }

  private publish(): void {
    const view: ContinuousListeningView = Object.freeze({state: this.state, lease_id: this.run?.leaseId ?? null,
      ready: this.ready, transcript: this.transcript,
      previous_previews: Object.freeze([...this.previousPreviews]), previous_preview_limit: MAX_PREVIOUS_PREVIEWS,
      sent_text: Object.freeze([...this.sentText]),
      notice: this.notice, error: this.error});
    try { this.options.onUpdate(view); } catch { /* Render failures cannot affect capture ownership. */ }
  }

  async close(): Promise<void> {
    if (this.closed) return;
    this.inputFence++;
    this.closed = true;
    const run = this.run;
    if (run) {
      this.archiveCurrentTranscript();
      run.stopping = true; this.run = null; run.queue.length = 0; run.queueBytes = 0;
      try { this.capture.stop(); } catch { /* Close continues. */ }
      const stop = run.stream?.stop('user_stop');
      await Promise.resolve(stop).catch(() => {});
      run.abort.abort();
    } else this.archiveCurrentTranscript();
    this.state = 'closed'; this.notice = '会话已关闭，未发送文字仍保留在当前页面。';
    this.options.onPhase?.(false);
    try { await this.capture.close(); } catch { /* The browser permission prompt may remain pending. */ }
    this.publish();
  }
}
