# Current status and historical corrections: 20261003T1448Z

## Verified current stage

The frozen candidate and its extracted privacy-filtered public projection each passed **1,155 Python + 185 Node tests, all 12 release lanes**, including offline wheel installation and actual local loopback HTTP smoke. Both recorded no source drift. These later receipts supersede only the pending-release sentence in the frozen `docs/mission/acceptance-status-1448.md`; that historical document is preserved unchanged.

## Corrected defects

- The 12:56 image-readiness defect is corrected: visibility and presentation receipts wait for successful load/decode and recheck current authority. Stop, new input, permit revocation and close suppress late completion. Failed cached decode can be retried. Independent software checks include 44 readiness/cue cases, actual history/receipt probes and cancellation/retry probes. See `docs/verification/media-readiness-independent/postdecode-retry-rerun-20261003T1416Z/results.md` and `docs/verification/media-readiness-repair/verification.md`. No browser compositor or human perception claim is implied.
- The existing Stop control appears before the long collapsed rehearsal guide. Directed tests passed, but real pixel/device layout remains unobserved.
- Live startup copy identifies missing verified admission instead of incorrectly calling an implemented adapter absent; admission and no-fallback guards remain in force.
- Restore safety is repaired. The new helper uses explicit validation, bounded directory parsing and staged output, including under Python optimization. The old assertion-based helpers are superseded by the additive `RESTORE-SAFETY-NOTICE-20261003T1448Z.md`. Earlier archive bytes, manifests and helpers remain historical artifacts.
- Earlier nested-credential filtering, cue/audio ordering, context projection, Unicode token rejection, deterministic microphone teardown, async diagnostic locators, shared evaluator budget-root and correct interruption-cause fixes are retained. Historical audit findings apply to their named earlier snapshots, not automatically to this one.

The separate final restore-helper signoff is publication evidence for exact helper SHA-256 `3fdb4eeebf61f608401cdf4e17ef5be2f56f5d811eeda9f1d3b704d7ad8517aa`; it reports 42 directed cases plus independent malformed-format checks. It is delivered separately and is not silently injected as pre-freeze source.

## Rehearsal scope

Explicit `rehearsal` is a finite authored command catalog with exact fixture review, using the existing Actor, permits, captions and cancellation-safe audio path. Eight original synthetic English Flite/slt clips total 52.56 seconds; both PCM/WAV assets, generator and provenance are included. Labeled synthetic listening requests no microphone permission and performs no speech recognition. Physical playback and human intelligibility are not established by file integrity or software audio contexts.

## Still open / not established

- Real browser pixels/current visual layout, phone/device operation, physical microphone/speaker behavior, acoustic interruption and Chinese speech quality.
- Continuous 3–5 minute human interaction with a matching acceptance recording; complete product/architecture acceptance.
- Frozen-runtime live-provider admission, real Google voice connectivity, and production JEV Chinese calibration. Separate later ambient development-provider success does not establish this candidate's runtime admission.
- Fresh dependency installation and all-platform compatibility. Existing approved dependencies were reused for the verified projection checks.
- Remote CI, deployment and merge success; these require separate evidence for the exact remote commit.
- Hostile same-user filesystem races or Windows/macOS runtime semantics for restore. Use a trusted manifest source and a private destination parent without competing writers.

The independent static-render attempt obtained no pixels because OS socket restrictions blocked it. This is a blocked check, not a successful browser acceptance.

## Public evidence exclusions

Raw logs, private auth/env/diagnostics and incident material, user PDF, generated previews/builds and duplicate workspaces are excluded. Only the 16 explicitly declared rehearsal PCM/WAV files bypass the raw-media exclusion. Forty relative setup/status file links were checked: 39 present; the missing `docs/verification/fnd-02/runs/` is intentionally excluded raw historical evidence. `tools/verify_tdd_evidence.py` cannot reproduce that old FND-02 log audit from this public archive. The current offline release suite passed separately.

Active Google voice-smoke work and documents completed after the 14:48 freeze are outside this archive. Earlier prepared stages keep their own identities and results.
