import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
const read = path => readFileSync(new URL(`../../${path}`, import.meta.url), 'utf8');
const html = read('apps/web/index.html');
const css = read('apps/web/public/app.css');

test('scene preserves integration selectors and adds explicit voice and phase hooks', () => {
  for (const name of ['stage', 'scene-label', 'status', 'pose', 'photo', 'subtitle', 'diagnostic', 'stop', 'close', 'error', 'ptt', 'phase-label', 'mode-label', 'voice-hint', 'character-description']) {
    assert.match(html, new RegExp(`data-${name}(?:[\\s=>])`), name);
  }
  assert.match(html, /name="message"/);
  assert.match(html, /<fieldset[^>]*disabled/);
});
test('art identifies an original adult and contains real independently animated character layers', () => {
  assert.match(html, /26 岁/);
  for (const layer of ['mira-breath', 'mira-head', 'mira-eyes', 'mira-camera', 'mouth-speaking', 'expression-warm', 'expression-curious', 'expression-reflective']) {
    assert.match(html, new RegExp(`class="[^"]*${layer}`), layer);
  }
  assert.match(css, /@keyframes\s+mira-breathe/);
  assert.match(css, /@keyframes\s+mira-blink/);
  assert.match(css, /@keyframes\s+mira-talk/);
});
test('all four phases and persistent character actions have visual styles', () => {
  for (const phase of ['idle', 'listening', 'thinking', 'speaking']) assert.ok(css.includes(`[data-phase="${phase}"]`), phase);
  for (const action of ['camera_lowered', 'look_at_rain']) assert.ok(css.includes(`[data-action="${action}"]`), action);
  for (const expression of ['warm', 'curious', 'reflective']) assert.ok(css.includes(`[data-expression="${expression}"]`), expression);
});
test('layout includes narrow viewport and reduced motion support with accessible controls', () => {
  assert.match(css, /@media\s*\(max-width:\s*480px\)/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
  assert.match(css, /animation:\s*none\s*!important/);
  assert.match(css, /:focus-visible/);
  assert.match(html, /aria-live="polite"/);
  assert.match(html, /aria-describedby="voice-hint"/);
  assert.match(html, /<label[^>]*for="message"/);
});
test('diagnostics stay collapsed and photo is initially absent', () => {
  assert.match(html, /<details class="technical-details">/);
  assert.match(html, /data-photo hidden/);
  assert.doesNotMatch(html, /<details[^>]*\bopen\b/);
});
test('original visual assets are local with no remote font or image dependency', () => {
  assert.doesNotMatch(html + css, /(?:src|href)=["']https?:\/\//);
  assert.doesNotMatch(css, /url\(["']?https?:\/\//);
  for (const asset of ['cafe-night.svg', 'trip-memory.svg']) {
    assert.ok(existsSync(new URL(`../../apps/web/public/scene/${asset}`, import.meta.url)), asset);
  }
});
