import type { EffectView } from '../../shared/generated/contracts.js';
import type { EffectExecutor } from './ports.js';
import { initialSceneState, reduceSceneEffect } from './scene-state.js';
import type { SceneExpression, ScenePhase, SceneState } from './scene-state.js';

const PHASE_LABELS: Record<ScenePhase, string> = {
  idle: '陪你听雨', listening: '正在认真听', thinking: '想一想…', speaking: '正在说话',
};
const EXPRESSION_LABELS: Record<SceneExpression, string> = {
  calm: '平静', warm: '温暖微笑', curious: '好奇', reflective: '若有所思',
};
const ACTION_LABELS: Record<SceneState['action'], string> = {
  camera_ready: '手中拿着相机', camera_lowered: '放低了相机', look_at_rain: '转头看向窗外的雨',
};
const SCENE_LABELS: Record<SceneState['environment'], string> = {
  cafe: '雨夜 · 窗边咖啡馆', rain_window: '雨窗 · 城市慢了下来', cafe_warm: '暖灯 · 留一会儿吧',
};

/**
 * Synchronous visual consumer beneath the existing presentation gate.
 * CSS supplies animation; this class schedules nothing and never starts audio.
 * Real recording/playback owners call setPhase; subtitle delivery is not speech evidence.
 */
export class SceneEffectExecutor implements EffectExecutor {
  private state = initialSceneState();
  constructor(private readonly root: HTMLElement) { this.render(); }

  private element(name: string): HTMLElement {
    const target = this.root.querySelector<HTMLElement>(`[data-${name}]`);
    if (!target) throw new Error(`Missing scene slot: ${name}`);
    return target;
  }

  apply(effect: EffectView): void {
    const next = reduceSceneEffect(this.state, effect);
    this.state = next;
    this.render();
  }

  prepareInput(): void {
    this.state = { ...this.state, phase: 'thinking', subtitle: '' };
    this.render();
  }

  stop(): void {
    this.state = { ...this.state, phase: 'idle', subtitle: this.state.photoVisible ? '已停下。那张旅行插画还留在这里。' : '已停下。我们可以慢慢说。' };
    this.render();
  }

  setPhase(phase: ScenePhase): void {
    this.state = { ...this.state, phase };
    this.render();
  }

  setExpression(expression: SceneExpression): void {
    this.state = { ...this.state, expression };
    this.render();
  }

  private render(): void {
    const state = this.state;
    this.root.dataset.phase = state.phase;
    this.root.dataset.expression = state.expression;
    this.root.dataset.action = state.action;
    this.root.dataset.scene = state.environment;
    this.element('subtitle').textContent = state.subtitle;
    this.element('photo').hidden = !state.photoVisible;
    this.element('pose').textContent = ACTION_LABELS[state.action];
    this.element('scene-label').textContent = SCENE_LABELS[state.environment];
    this.element('phase-label').textContent = PHASE_LABELS[state.phase];
    this.element('character-description').textContent =
      `MIRA，26 岁的旅行摄影师。神情${EXPRESSION_LABELS[state.expression]}，${ACTION_LABELS[state.action]}。${PHASE_LABELS[state.phase]}。`;
  }
}
