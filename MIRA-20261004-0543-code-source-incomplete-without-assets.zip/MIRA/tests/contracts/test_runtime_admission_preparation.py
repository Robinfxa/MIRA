"""Synthetic contracts for explicit public-route Codex metadata preparation."""
import argparse
import asyncio
import json
import os
import stat
import sys
import tempfile
from pathlib import Path

import pytest

from mira.adapters.generation.codex_support import process, types
from mira.adapters.generation.codex_support.payload import canonical
from mira.adapters.generation.codex_support.preflight import MetadataOnlyTransport
from tools import prepare_runtime_admission as prepare

FLAGS = ("apps", "plugins", "browser_use", "computer_use", "multi_agent", "shell_tool",
         "image_generation", "tool_suggest", "sleep_tool", "token_budget")


def _external_temp_parent() -> Path:
    """Choose a system temp parent that stays outside the checkout."""
    repository = prepare.ROOT.resolve()
    candidates = (Path(tempfile.gettempdir()), Path("/tmp"), Path("/var/tmp"))
    for candidate in candidates:
        try:
            parent = candidate.resolve(strict=True)
        except OSError:
            continue
        if parent.is_dir() and parent != repository and repository not in parent.parents:
            return parent
    raise RuntimeError("No temporary directory outside the MIRA checkout is available")


@pytest.fixture
def private_tmp_path():
    """Own and clean synthetic private inputs outside any pytest basetemp."""
    with tempfile.TemporaryDirectory(prefix="mira-admission-test-",
                                     dir=_external_temp_parent()) as directory:
        yield Path(directory)


def _public_config():
    return {
        "features": {**dict.fromkeys(FLAGS, False), "respect_system_proxy": True},
        "mcp_servers": {}, "web_search": "disabled", "model": "gpt-6-luna",
        "model_provider": "openai", "forced_login_method": "chatgpt",
        "approval_policy": "never", "sandbox_mode": "read-only",
    }


class SyntheticMetadataTransport:
    def __init__(self, *, user_agent="codex/0.159.2 (linux)", config=None,
                 unsolicited=None):
        self.user_agent = user_agent
        self.config = config or _public_config()
        self.unsolicited = unsolicited
        self.sent = []
        self.incoming = asyncio.Queue()
        self.closed = False

    async def send(self, message):
        self.sent.append(message)
        if "id" not in message:
            return
        if self.unsolicited is not None:
            response = self.unsolicited
        elif message["method"] == "initialize":
            response = {"id": message["id"], "result": {
                "userAgent": self.user_agent, "codexHome": "/synthetic/home",
                "platformFamily": "unix", "platformOs": "linux"}}
        elif message["method"] == "config/read":
            response = {"id": message["id"], "result": {
                "config": self.config, "origins": {}, "layers": None}}
        else:
            response = {"id": message["id"], "result": {}}
        await self.incoming.put(json.dumps(response).encode() + b"\n")

    async def receive(self):
        return await self.incoming.get()

    async def close(self):
        self.closed = True


def _runtime():
    return types.CodexRuntime(Path("/synthetic/codex"), Path("/synthetic/home"),
                              Path("/synthetic/run"), policy_environment_confirmed=True)


def test_no_args_is_unarmed_and_performs_zero_setup_io(monkeypatch, capsys):
    called = False

    async def forbidden(*_args, **_kwargs):
        nonlocal called
        called = True
        raise AssertionError("metadata transport must not start")

    monkeypatch.setattr(prepare, "observe_public_metadata", forbidden)
    monkeypatch.setattr(sys, "argv", ["prepare_runtime_admission.py"])
    assert prepare.main() == 0
    result = json.loads(capsys.readouterr().out)
    assert result == {"status": "unarmed", "metadata_probe": "not_run",
                      "admission_written": False,
                      "next": "Run --help for explicit setup options."}
    assert not called


@pytest.mark.asyncio
async def test_preflight_sends_only_initialize_initialized_and_config_read_without_claims():
    transport = SyntheticMetadataTransport()
    observed = await MetadataOnlyTransport(transport, _runtime()).observe(2)
    assert [message.get("method") for message in transport.sent] == [
        "initialize", "initialized", "config/read"]
    assert all(message.get("method") not in {
        "account/read", "account/list", "thread/start", "turn/start", "tools/list"}
        for message in transport.sent)
    assert observed.config_sha256 == __import__("hashlib").sha256(
        canonical(_public_config())).hexdigest()
    assert observed.codex_version == "0.159.2" and observed.route_kind == "public"
    assert not hasattr(observed, "account") and not hasattr(observed, "entitlement")
    assert transport.closed


@pytest.mark.asyncio
async def test_preflight_rejects_wrong_version_custom_route_and_server_rpc():
    cases = [SyntheticMetadataTransport(user_agent="codex/0.160.0 (linux)"),
             SyntheticMetadataTransport(config={**_public_config(),
                                                "openai_base_url": "https://route.invalid"}),
             SyntheticMetadataTransport(config={**_public_config(),
                                                "openai_api_key": "secret-never-returned"}),
             SyntheticMetadataTransport(unsolicited={"method": "account/updated",
                                                     "params": {"email": "private"}})]
    for transport in cases:
        with pytest.raises(types.CodexGenerationError):
            await MetadataOnlyTransport(transport, _runtime()).observe(2)
        assert transport.closed
        assert not any(message.get("method") in {"account/read", "thread/start", "turn/start"}
                       for message in transport.sent)


@pytest.mark.asyncio
async def test_preflight_rejects_disallowed_rpc_before_transport_send():
    transport = SyntheticMetadataTransport()
    client = MetadataOnlyTransport(transport, _runtime())
    with pytest.raises(types.CodexGenerationError, match="rpc_forbidden"):
        await client._request(3, "account/read", {"refreshToken": False})
    assert transport.sent == []
    await client.close()


def test_environment_rejects_api_key_presence_and_proxy_userinfo_without_echoing_values():
    class SecretMapping(dict):
        def __getitem__(self, key):
            if key == "OPENAI_API_KEY":
                raise AssertionError("secret value must never be read")
            return super().__getitem__(key)

    with pytest.raises(prepare.PreparationError, match="override_present") as caught:
        prepare._public_environment(SecretMapping(OPENAI_API_KEY="synthetic-secret"))
    assert "synthetic-secret" not in str(caught.value)
    with pytest.raises(prepare.PreparationError, match="proxy_userinfo"):
        prepare._public_environment({"HTTPS_PROXY": "http://user:secret@proxy.invalid:3128"})


def test_private_writer_creates_exact_mode_no_overwrite_and_rejects_symlink_parent(tmp_path):
    private = tmp_path / "private"
    private.mkdir(mode=0o700)
    private.chmod(0o700)
    target = private / "admission.json"
    document = {"authorized": True, "route_kind": "public"}
    with pytest.raises(prepare.PreparationError, match="content_authorization_required"):
        prepare.write_admission(target, document, repo_root=tmp_path / "repo")
    assert not target.exists()
    prepare.write_admission(target, document, content_authorized=True,
                            repo_root=tmp_path / "repo")
    assert stat.S_IMODE(target.stat().st_mode) == 0o600
    assert json.loads(target.read_text()) == document
    with pytest.raises(prepare.PreparationError, match="already_exists"):
        prepare.write_admission(target, document, content_authorized=True,
                                repo_root=tmp_path / "repo")
    symlink = tmp_path / "linked"
    symlink.symlink_to(private, target_is_directory=True)
    with pytest.raises(prepare.PreparationError, match="parent_missing_or_unsafe"):
        prepare.write_admission(symlink / "other.json", document, content_authorized=True,
                                repo_root=tmp_path / "repo")


def test_policy_confirmation_alone_cannot_probe_or_write(monkeypatch, tmp_path, capsys):
    called = False

    async def forbidden(*_args, **_kwargs):
        nonlocal called
        called = True
        raise AssertionError("content authorization is required before metadata traffic")

    monkeypatch.setattr(prepare, "observe_public_metadata", forbidden)
    monkeypatch.setattr(sys, "argv", ["prepare_runtime_admission.py", "--prepare",
        "--confirm-policy-environment", "--codex-requests", "1", "--session-turns", "1",
        "--input-jev-requests", "1", "--output-jev-requests", "1",
        "--input-jev-timeout-seconds", "5", "--output-jev-timeout-seconds", "5",
        "--probe-timeout-seconds", "5", "--write-admission", str(tmp_path / "no.json")])
    assert prepare.main() == 2
    result = json.loads(capsys.readouterr().out)
    assert result["status"] == "blocked" and not result["admission_written"]
    assert not called and not (tmp_path / "no.json").exists()


@pytest.mark.asyncio
async def test_explicit_content_ack_writes_reader_compatible_public_declaration(monkeypatch, private_tmp_path):
    executable = private_tmp_path / "codex"
    executable.write_text("synthetic pinned executable placeholder")
    executable.chmod(0o700)
    codex_home = private_tmp_path / "home"
    runtime_cwd = private_tmp_path / "run"
    codex_home.mkdir(mode=0o700)
    runtime_cwd.mkdir(mode=0o700)
    codex_home.chmod(0o700)
    runtime_cwd.chmod(0o700)
    output_parent = private_tmp_path / "output"
    output_parent.mkdir(mode=0o700)
    output_parent.chmod(0o700)
    output = output_parent / "admission.json"
    args = prepare._parser().parse_args(["--prepare", "--codex", str(executable),
        "--codex-home", str(codex_home), "--runtime-cwd", str(runtime_cwd),
        "--codex-requests", "2", "--session-turns", "2", "--input-jev-requests", "3",
        "--output-jev-requests", "3", "--input-jev-timeout-seconds", "10",
        "--output-jev-timeout-seconds", "10", "--probe-timeout-seconds", "10",
        "--confirm-policy-environment", "--authorize-codex-and-jev-content",
        "--write-admission", str(output)])
    observed_config_hash = "a" * 64

    async def synthetic_observation(runtime, **kwargs):
        assert runtime.expected_config_sha256 is None and runtime.development_context is None
        return type("Observation", (), {"config_sha256": observed_config_hash,
            "executable_sha256": types.PINNED_EXECUTABLE_SHA256,
            "environment_sha256": "b" * 64})()

    monkeypatch.setattr(prepare, "observe_public_metadata", synthetic_observation)
    result = await prepare._prepare(args, {
        "PATH": "/synthetic/bin", "HOME": str(private_tmp_path)})
    assert result["inference_verified"] == "not_run"
    assert result["account_entitlement"] == "not_assessed"
    assert result["quota_or_dollar_cap"] == "not_assessed"
    assert result["dialogue_sent_during_preparation"] is False
    assert result["content_authorized_for_live_text_entry"] is True
    assert "dialogue and relevant prior application context" in result["content_flow"]
    assert "Codex/OpenAI and TypeSafe/JEV" in result["content_flow"]
    assert "generated candidate to TypeSafe/JEV" in result["content_flow"]
    assert result["jev_billable"] is True and result["request_ceilings_are_dollar_caps"] is False
    assert result["request_ceilings_scope"] == (
        "per_app_invocation_in_memory; restart_starts_fresh_allowance")
    assert stat.S_IMODE(output.stat().st_mode) == 0o600
    document = json.loads(output.read_text())
    assert set(document) == {"authorized", "route_kind", "runtime", "limits"}
    assert document["route_kind"] == "public" and document["authorized"] is True
    assert document["runtime"]["development_context"] is None
    assert document["runtime"]["expected_config_sha256"] == observed_config_hash
    assert "CODEX_HOME" not in document["runtime"]["environment"]
    assert document["limits"] == {"codex_requests": 2, "session_turns": 2,
        "input_jev_requests": 3, "output_jev_requests": 3,
        "input_jev_timeout_seconds": 10, "output_jev_timeout_seconds": 10}
    from tools.live_dev import _read_admission
    admission = _read_admission(output)
    assert admission.authorized is True and admission.route_kind == "public"
    assert admission.runtime.expected_config_sha256 == observed_config_hash
    assert admission.runtime.development_context is None
    assert admission.limits.codex_requests == 2 and admission.limits.session_turns == 2
    assert admission.limits.input_jev_requests == 3 and admission.limits.output_jev_requests == 3
