# MIRA · 原创角色互动开发版

**可运行的零密钥演示；真实服务、设备与完整互动验收仍有独立准入条件。**
MIRA 是一位26岁的原创虚构摄影师，场景是雨夜咖啡馆。当前实现包含原创 SVG 角色/场景、四态表现、表情与受控动作、文字输入、可取消音频传输/播放、独立语义审核，以及有界脱敏诊断和显式开发录制。离线排练中的按住手势只提交固定合成文本，不采集麦克风；真实语音入口仍待授权后的设备验收。

## 当前实现与验收边界

以下状态核对至 **2026-10-04 01:24 UTC（重置后真实会话验证尚未执行）**；各次测试和真实调用绑定各自源码快照。

- 默认 `mock` / `replay` 可离线启动，不读取私密 `.env`，不调用模型或真实语音服务。另有显式 `rehearsal`：固定口令、多轮呈现历史、预录英文合成音频及双语字幕，真实麦克风始终关闭。
- 受批准的既有原生 Codex 开发环境已通过实际 MIRA 适配器产出一份 `gpt-6-luna` 结构化候选；Google Speech-to-Text V2 已识别一段6.135秒的合成英文。精确 `gemini-3.8-flash-tts` 已返回完整3.4秒合成中文 PCM，耗时16.056秒（含私有落盘），首PCM/可听延迟未测。JEV 的用户指定≥0.6开发判定策略已在1955阶段发布。重置前一次实际文字 ASGI 检查通过原生生成和 v2 输入判断，随后因 JEV 输出概率结构错误而停止，没有呈现。当前重建的显式文字入口、准入准备与可定位错误已通过定向软件测试，23:11公开投影已通过12项完整离线发布检查（1416 Python、218 Node、打包与启动），恢复bundle已在远端逐字核对；后续小切片重新验收，默认入口继续离线。
- 字幕/动作通过应用生成的 cue 身份与对应语音关联。Stop、新输入和权限撤销先在本地阻断；软件渲染样本不证明用户听见，也不是逐字对齐。
- 普通日志无原文。开发原文录制需要单独开关与确认，保持可见标记；凭据结构与不确定内容拒绝记录。原始音频录制仍默认关闭，只在显式注入的开发语音模式中提供应用范围的开关；最多512 KiB、短时暂存，提供精确缓冲试听，由用户确认已审核、再单独确认排入本机私有诊断队列；软件不能证明人实际听过。ASR转写不能代替原音审核，也没有自动口述秘密检测；队列接收不代表已写入磁盘。默认 mock/replay/rehearsal 麦克风与录制保持关闭。
- 独立审查已发现并修复字幕提前呈现、嵌套凭据过滤、累计音频上下文、错误文案和异常 token 等问题。每个后续阶段须重新冻结源码验证，旧阶段的绿色测试不能替代新版本验收。
- 真实浏览器/手机/扬声器/麦克风、完整3–5分钟交互录屏、真实模型表现与中文审核校准尚未完成。没有云部署或正式产品就绪声明。

[项目北极星](docs/NORTH_STAR.md) · [最终需求与验收](docs/mission/requirements-and-acceptance.md) · [当前版本与缺口](docs/mission/acceptance-status-1927.md) · [固定归档快速指引](docs/development/QUICKSTART.md) · [测试政策](docs/development/TESTING.md)

## 服务配置准备

在既有loader中加入具名服务配置和私密模板；提供默认无网络检查、显式有界模型目录检查。
**适配器代码与接入参数不代表账户开通或 live 准入。** 默认应用仍是 mock/replay；真实服务只能在显式装配、授权、预算和对应验收通过后使用。
[API环境与一次性准备](docs/development/API_ENV.md) · [Provider Matrix](docs/development/PROVIDER_MATRIX.md) · [当前交接](docs/handoff/ENV-01.md) · [规格](specs/features/ENV-01-development-services/spec.md)

```bash
python tools/api_env.py init     # 创建空.env；已有文件拒绝覆盖
python tools/api_env.py check    # 默认不联网；字段缺失退出2，不表示MVP失败
python tools/check.py --lane env --jobs 2
```

密钥仅在本机私密文件／进程提供，不发送聊天，不写进spec、日志、前端或截图。

## 历史基础阶段：增量分块测试

以下数字保留原阶段的历史含义，不是当前完整实现的测试总数。

默认开发检查改为affected；定向RED/GREEN不必先跑全量。9个默认离线块可并行，package/smoke留发布。
[测试工作流](docs/development/TESTING.md) · [FND03规格](specs/features/FND-03-scoped-quality/spec.md) · [验证](docs/changes/FND-03/verification.md)

最终本地181 Python＋20 Node、18条规格映射通过；4组真实RED/GREEN。定向示例与分块收据均在验证目录，未选检查明确not_run。

## 继承的开发示范

[SDD/TDD示范手册](docs/development/TDD-SDD.md) · [功能规格](specs/features/FND-02-fixture-replay/spec.md) ·
[开发日志](docs/development/LOG.md) · [本轮验证](docs/changes/FND-02/verification.md) · [最新交接](docs/handoff/FND-03.md)

FND-02是一个新adapter的完整例子，不是空目录：先写规格，真实RED/GREEN，再重构和集成。最终132 Python＋20前端通过；此前73 Python为基线，未伪造其TDD顺序。无新增依赖版本升级。

## 快速启动

需要 Python 3.11–3.13、Node.js 22.12+ 和锁文件声明的依赖。在工程根目录运行：

```bash
sh scripts/dev
```

此命令**不会安装依赖**。先验证 `.venv` 和当前解释器的实际应用导入能力；不完整的 `.venv` 不会遮住可用的当前解释器。
缺依赖会退出 2 并提示显式安装。首次准备需要包注册表：`python3 tools/bootstrap.py`，只写项目 `.venv` 和 `node_modules`。
如果已在其他隔离环境安装依赖，用显式解释器路径，不自动扫描或猜测虚拟环境名称：

```bash
sh scripts/dev --python /absolute/path/to/ready/python
# Windows：python tools/dev.py --python C:\\path\\to\\python.exe（本轮未实测）
```

启动前检查合同、编译 TypeScript，再以单进程提供 API 和静态工作台。浏览器手动打开 `http://127.0.0.1:8000`；可用 `--port 8123` 改端口。
**默认演示固定为 mock，忽略根 `.env` 和进程中的 MIRA 服务配置／常用凭据变量**；不启用 live provider、付费调用或原文记录。`--no-bootstrap` 保留兼容，但现在所有启动都不自动安装。
归档可没有脚本执行位，所以推荐 `sh scripts/dev`，不要求 `chmod`。

### 有声离线排练（推荐演示入口）

```bash
sh scripts/dev --profile rehearsal
# 已验证可用的其他解释器可追加 --python /absolute/path/to/ready/python
```

页面常显 `OFFLINE · 固定互动排练`。这条路线只有 7 个固定口令和一个失败注入，不支持自由对话；目录外文字只得到明确口令提示，不被假装识别或转述。真实麦克风按钮保持关闭，独立「按住演练输入 · 不录音」只展示 listening 状态，松开后提交固定的「照片里有什么」，不会调用录音或 STT。

原始音频/文字录制默认关闭。8 段预先生成的英文合成声音共约 52.56 秒，来自本地 Flite `slt`，不是 Google 语音、真人声音或中文发音验收；中文翻译与完整英文句子按现有语音 cue 显示，非逐字对齐。音频只经既有 Actor、有效许可、认证音频流和唯一取消安全播放队列进入页面。

12:56 历史归档存在图片未就绪就记录呈现回执的问题。当前源码已加入可取消的图片就绪等待、最新许可复核与失败重试修复，并通过独立软件层复验；旧归档保持原样并附已知问题说明。前端还会等待已有呈现回执同步后再提交下一轮，Stop 不等待网络。服务端也已加入缺失回执前缀的拒绝与同请求重试控制，独立11个场景和1843组合软件发布检查已通过。当前未验证浏览器实际绘制或用户看见。见[当前状态](docs/mission/acceptance-status-1927.md)。

按自己的节奏走一遍约 3–5 分钟的指引（包含观察、重复与停止，不是已录制的验收时长）：

1. 「你好」→「不要拍我」：观察好奇、微笑与相机放低。
2. 「看照片」：等语音与原创海岸/灯塔插画出现。
3. 「讲讲旅途」：讲话中点「停止回应」。声音、字幕不继续，已经看到的插画保留。
4. 按住「演练输入」，确认画面显示 listening 且没有麦克风请求；松开只发送「照片里有什么」。回应用实际呈现过的插画；新会话未看图就问，会先提示看图。
5. 「听雨」→「暖灯」：看环境和表情变化。用 `/fail` 测失败，再点「你好」恢复；输入目录外文字检查口令提示。

完整口令：`你好`、`不要拍我`、`看照片`、`照片里有什么`、`讲讲旅途`、`听雨`、`暖灯`、`/fail`。前后空格和改写也不会被当作识别成功。Stop、失焦、取消、关闭或更新的文字输入都会使待发送的合成输入失效。

这条路径用于验证受控体验，不证明真实模型、真实语音识别、物理扬声器听感、手机或真人 3–5 分钟互动录屏已经完成。[规格与实测边界](specs/features/DEMO-01-offline-rehearsal/spec.md) · [素材来源](docs/changes/DEMO-02-offline-speech-assets/README.md)

回放固定照片场景（不调用模型）：

```bash
sh scripts/dev --profile replay
# 其他现成 Python 环境同样追加 --python /absolute/path/to/ready/python
```

可以加 `--replay-scenario delayed-photo` 测停止，或 `--replay-scenario failed-tail` 测失败。
这只是固定生成夹具回放，不是自然语言理解或完整会话恢复。语音、账户、真实设备能力不能从本启动检查推出。

配置感知入口仍是 `PYTHONPATH=apps/api/src /path/to/ready/python -m mira`，它会按原 loader 读取根 `.env` 和进程配置；仅在已明确配置、授权和审核的开发流程中手动使用，不属于上述离线演示。live 工厂守卫不因启动工具改变而放宽。

离线 wheel 验证：`/path/to/ready/python tools/verify_package.py`。构建 Python 需要现成的 pip 与 `pyproject.toml` 固定版本的 setuptools、wheel（已列入开发锁文件）；必要时加 `--build-python /path/to/build/python`，运行烟测仍使用调用脚本的解释器。工具在临时副本编译前端、无网络构建／安装 wheel，并从安装目录验证配置、fixture、HTTP 与全部静态资源；不靠 checkout 的 PYTHONPATH 补资源。直接手动构建 wheel 前须先 `npm run build`，漏编译会明确失败。
实测和限制见 [STARTUP-01 验证](docs/verification/startup-01/verification.md)。

## 质量命令

```bash
python tools/check.py --list
python tools/check.py --files apps/api/src/mira/adapters/generation/replay/backend.py --plan
python tools/check.py --lane providers actor --jobs 2  # 精确相关块
python tools/check.py --affected --base <共同Git基点> --jobs 3  # 合并前
python tools/check.py --full --jobs 3      # 集成收口，不是每次修改
python tools/check.py --release --jobs 3   # 再加离线wheel与loopback
python tools/verify_tdd_evidence.py         # 原FND02历史完整性；公开归档不含其所需原日志
python tools/export_contracts.py --check
```

无Git的ZIP用`--files`或`--lane`；默认命令只检查Git工作区，已提交变更请带base。报告在`var/quality/<run>/summary.json`，未选块为not_run，没有测试结果缓存。

环境里同时存在多个 Python 时，用已验证且依赖完整的解释器绝对路径执行质量命令；不要仅凭 `.venv` 目录存在就认为可用。
14:48 已验证源码已完整展开至提交 `45b716d7ae80ce9d55934b81372dd1a7b411caf3`，543个源码文件的 Git blob 与模式逐项匹配，46个历史备份文件保留。其[首个真实远端 CI](https://github.com/Robinfxa/MIRA/actions/runs/37140155063)通过10个离线质量块；该次未跑 package/smoke。其后修复了发布任务缺少 Node/npm 的准备步骤；33410f5手动发布检查通过。1756阶段6ab19a8的推送与手动CI也已通过，手动检查包括package/smoke；结果仍绑定各自提交。更新中的源码必须重新冻结和验证。

## 工作台能验证什么

输入“不要拍我”“看照片”“听雨”进入固定Mock场景；`/fail`注入生成失败。
可查看activity/output/permit版本、有效集合和回执数。停止先在浏览器生效，旧结果不能恢复。
支持新请求、重复请求、会话能力token、范围累加、停止截止范围和迟到回执。

默认模式不会产生真实 ASR/TTS/LLM 请求。原创角色和旅行插画已实现，属于本地矢量素材，不能说成实时生图。真实语音代码、软件级取消测试和控制台能力标记，也不能代替账户、声卡、麦克风与完整需求验收。

## 目录入口

```text
apps/api/src/mira/
  domain/             纯模型、错误、状态转换
  application/        用例与会话生命周期；ports声明外部能力
  adapters/           Mock/回放、默认关闭的真实服务、私有诊断适配器
  config/             类型与唯一env读取入口
  bootstrap/          工厂、组合根、生命周期装配
  entrypoints/http/   DTO、映射、依赖、路由、app factory
apps/web/src/
  app/                浏览器组合根
  features/session/   transport与交互协调
  features/presentation/  本地许可门、cue身份与原创场景执行器
  features/audio/     唯一播放队列、可取消麦克风采集
  features/diagnostics/  实际录制状态与安全错误文案
  shared/             公开配置、协议验证、generated类型
config/               非秘密默认值与profile
packages/contracts/   自动导出的OpenAPI
requirements/         精确安装版本闭包
scripts/ tools/       启动、安装、合同导出、验证
tests/                unit、integration、architecture、web、browser
docs/                 50h计划、实施ADR、来源快照、交接与验证
```

完整文件树见 `docs/implementation/FILE_TREE.md`。

## 配置与抽象的约束

- `Settings`不可变；默认值→profile→显式dotenv→进程env→测试overrides；未知配置启动失败。
- 业务层不读env、不知道provider名称；仅 `bootstrap/providers.py` 选实现。
- `create_app(settings)`可注入依赖；没有全局容器、import-time连接或反射插件扫描。
- domain标准库限定，application不反向依赖adapters；有自动边界测试。
- 公共DTO单点定义，OpenAPI／TS只导出；新增schema先改owner，再跑drift check。
- live provider 不会因环境字段齐全而自行启用；显式装配仍须通过身份、质量、数据和预算准入，不会偷偷 Mock 或改走付费路线。

## 必读文档

[50小时计划](docs/plans/50-hour-delivery.md) · [实施ADR](docs/implementation/ADR-F001-foundation.md) ·
[配置约定](config/README.md) · [开发范例](docs/implementation/config-and-extension-guide.md) ·
[最新交接](docs/handoff/FND-03.md) · [原架构/复用 v0.6](docs/reference/architecture-v0.6/MIRA_架构全书_v0.6.md)

## 运行与安全界限

仅loopback＋单worker，内存会话，有限容量；停止与实例隔离是基础子集，不是生产认证系统。
浏览器token只在内存，诊断不输出用户原文/凭据；只服务明确public/dist文件，不服务仓库根。
刷新不恢复旧会话，关闭按钮释放本地session；完整持久化/隐私清除在WP05后续实现。

依赖来源与素材见THIRD_PARTY.md；AI使用与未进行的人工验证见AI_USAGE.md。
已在同一 Linux 环境的新隔离目录验证46个固定 Python 依赖、TypeScript5.8.3和启动；远端固定提交的10块CI也已通过。它们不代表全新操作系统、Windows/macOS、手机或物理音频验收。详见[安装证据与限制](docs/verification/fresh-install/verification.md)。

## 为什么选择按住输入

本 MVP 选择明确的按住/松开与停止控制，而不是自动 VAD：移动端更容易看清何时开始采集，能够利用用户手势解锁音频，并避免把背景声误作打断。真实路径仍需验证麦克风许可、识别结果、释放和新一轮衔接。离线 rehearsal 用单独标记的合成输入演练这些状态，不把它称为真实语音识别。

## 当前阶段与剩余范围

本轮截止仍为2026-10-04 08:53:50 UTC。01:24 UTC 状态：云工作环境重置后，已从验证过的1955公开基线恢复源码；后续v2、文字入口、元数据准备和计时改动重新实现并重测，不能把旧收据当作重建文件的证明。恢复后的23:11完整离线集成已保存为远端50文件恢复增量；之后00:35源码与公开投影各自通过12项完整离线检查（1482 Python、218 Node、打包与启动），68文件增量待发布。后加的语音CLI单独验收，不能借用00:35收据作为它的完整集成证明。

- **已公开的基线：** main提交 `424b3bfbb4a9b21db9ffe15bf025cdbddfd10650`，其完整远端质量、打包与启动检查通过。恢复分支 `recovery/verified-slices-20261003T2239Z` 的提交 `b9acce5a7b9d86a55e8888b94f1488339555dde2` 保存了50文件的完整文本恢复bundle，远端全文校验一致；bundle不是已展开的新应用源码或新全量CI结果。
- **可运行离线演示：** rehearsal只包含固定口令、预录英文合成音频、字幕及原创场景。Linux安装、打包和HTTP启动有证据，真实浏览器绘制、用户听感、Mac/Windows/手机尚未验收。
- **重置后原生前置检查：** 官方CLI版本/哈希与本地ChatGPT登录状态已核实；只读托管安装的所有者兼容适配按明确批准实现。支持的独立SQLite运行目录已准备，但实际官方app-server仍在initialize响应前以只读文件系统错误退出；完整脱敏错误已留存，尚无新的元数据或模型准入。不会复制旧准入。
- **真实文字：** 模型与v2输入判断曾实际通过；输出JEV的概率结构错误没有留下精确失效分布，原因仍未知。新的产品错误区分provider格式错误、语义拒绝与不确定，附可定位ID，安全诊断保留有限数值而不保存原始body/headers。没有因此放宽parser、阈值或自动重试。
- **普通用户准备：** 显式文字入口支持分开的public/managed声明；元数据准备只检查固定RPC。生成可执行声明必须同时确认环境政策和内容/费用范围，明确对话及相关上下文会送给Codex/OpenAI和TypeSafe/JEV。请求上限按每次应用启动计数，不是跨重启账本或美元上限；配置声明不证明登录额度、模型权限或推理成功。[准备流程](docs/development/RUNTIME_PREPARATION.md) · [文字入口](docs/development/DEVELOPMENT_APP.md)
- **语音：** 历史上已完成英文合成STT和精确Gemini3.8 Flash TTS的3.4秒中文PCM。TTS响应头14.7693秒、保存完成16.0560秒；没有首PCM或可听延迟测量。重连凭据后没有新模型测试；显式语音组合工厂已加入应用生命周期并通过合成验收；新增独立命令行入口保留默认关闭、显式Google数据/费用确认、私有ADC路径及每次启动的次数/时长上限，正在独立离线验收。该入口不提供跨重启美元预算保证；有界新调用、中文识别与真机仍未完成。[语音入口与范围](docs/development/DEVELOPMENT_VOICE.md)
- **开发记录：** 原文/原音默认关闭，凭据不记录；原音需要针对精确缓冲的人工审查及单独保存确认。软件不能证明人实际听过，也没有自动口述秘密识别保证。队列接收不等于持久写入。
- **全架构：** 这仍是24小时对话MVP子集。长期人格/记忆学习、完整storylet、动态素材、G06生图与D–M未完整实现；原164条验收目录仍按实际未执行状态记录，不能由单元测试数量替代。持续3–5分钟真实互动与设备验收仍开放。

[重置与恢复记录](docs/mission/reset-recovery-20261003.md) · [用户设备走查](docs/development/DEVICE-ACCEPTANCE.md)
