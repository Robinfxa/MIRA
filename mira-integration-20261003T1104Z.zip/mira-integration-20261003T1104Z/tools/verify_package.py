"""Build a wheel offline in a temporary source copy; verify fixture resources from the wheel."""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="mira-wheel-check-") as temporary:
        root = Path(temporary)
        source = root / "source"
        source.mkdir()
        shutil.copy2(ROOT / "pyproject.toml", source / "pyproject.toml")
        shutil.copytree(ROOT / "apps/api/src", source / "apps/api/src",
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.egg-info"))
        wheels = root / "wheels"
        subprocess.run([sys.executable, "-m", "pip", "wheel", str(source), "--no-deps",
                        "--no-build-isolation", "--no-index", "--wheel-dir", str(wheels)], check=True)
        wheel, = wheels.glob("*.whl")
        code = '''import sys
sys.path.insert(0, sys.argv[1])
from mira.adapters.generation.replay.script import load_script
assert len(load_script("photo-tour").steps) == 2
assert load_script("failed-tail").finish == "fail"
assert len(load_script("delayed-photo").steps) == 2
print("All three fixture resources loaded from wheel; not a full installed deployment test.")
'''
        subprocess.run([sys.executable, "-I", "-c", code, str(wheel)], check=True, cwd=root)


if __name__ == "__main__":
    main()
