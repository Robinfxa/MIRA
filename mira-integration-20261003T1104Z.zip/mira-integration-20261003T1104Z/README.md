# MIRA · Foundation v0.4.1

**可运行的基础工程，不是已完成的实时语音产品。**
当前提供零私人密钥的Mock控制闭环与受控生成夹具回放，用来承接已批准的架构与后续并行开发。

## 本版：开发API环境

在既有loader中加入具名服务配置和私密模板；提供默认无网络检查、显式有界模型目录检查。
**已准备的是接入参数与工具，不是账户开通或live adapter。** 当前应用仍是mock/replay。
[API环境与一次性准备](docs/development/API_ENV.md) · [Provider Matrix](docs/development/PROVIDER_MATRIX.md) · [当前交接](docs/handoff/ENV-01.md) · [规格](specs/features/ENV-01-development-services/spec.md)

```bash
python tools/api_env.py init     # 创建空.env；已有文件拒绝覆盖
python tools/api_env.py check    # 默认不联网；字段缺失退出2，不表示MVP失败
python tools/check.py --lane env --jobs 2
```

密钥仅在本机私密文件／进程提供，不发送聊天，不写进spec、日志、前端或截图。

## 继承：增量分块测试

默认开发检查改为affected；定向RED/GREEN不必先跑全量。9个默认离线块可并行，package/smoke留发布。
[测试工作流](docs/development/TESTING.md) · [FND03规格](specs/features/FND-03-scoped-quality/spec.md) · [验证](docs/changes/FND-03/verification.md)

最终本地181 Python＋20 Node、18条规格映射通过；4组真实RED/GREEN。定向示例与分块收据均在验证目录，未选检查明确not_run。

## 继承的开发示范

[SDD/TDD示范手册](docs/development/TDD-SDD.md) · [功能规格](specs/features/FND-02-fixture-replay/spec.md) ·
[开发日志](docs/development/LOG.md) · [本轮验证](docs/changes/FND-02/verification.md) · [最新交接](docs/handoff/FND-03.md)

FND-02是一个新adapter的完整例子，不是空目录：先写规格，真实RED/GREEN，再重构和集成。最终132 Python＋20前端通过；此前73 Python为基线，未伪造其TDD顺序。无新增依赖版本升级。

## 快速启动

需要 Python 3.11–3.13（实测3.13.5）、Node.js 22+（实测22.16.0）。在工程根目录运行：

```bash
./scripts/dev
```

缺依赖时，该命令只在项目内安装声明的开发依赖；首次需要能访问包注册表。
已有环境会先检查合同、编译TypeScript，再以单进程运行API和静态工作台。
默认打开 `http://127.0.0.1:8000`。无需 `.env`、无私人 API key，不调用真实模型。
Windows可用 `python tools/dev.py`；本轮未在Windows实测。

可选配置：

```bash
cp .env.example .env
# 编辑本地 .env；只从 config/loader.py 进入，不向浏览器暴露。
```

显式安装到隔离环境：`python3 tools/bootstrap.py`。
`.venv`创建后可用其python执行检查；未提交虚拟环境、node_modules或真实凭据。

回放固定照片场景（不调用模型）：

```bash
MIRA_PROFILE=replay MIRA_PROVIDERS__GENERATION=replay ./scripts/dev
```

可以加 `MIRA_PROVIDERS__REPLAY_SCENARIO=delayed-photo` 测停止，或 `failed-tail` 测失败。
这只是生成夹具回放，任何文字只启动选定scenario，不是自然语言理解或完整会话恢复。已有.env的显式字段优先于profile，所以命令同时指定generation。

## 质量命令

```bash
python tools/check.py --list
python tools/check.py --files apps/api/src/mira/adapters/generation/replay/backend.py --plan
python tools/check.py --lane providers actor --jobs 2  # 精确相关块
python tools/check.py --affected --base <共同Git基点> --jobs 3  # 合并前
python tools/check.py --full --jobs 3      # 集成收口，不是每次修改
python tools/check.py --release --jobs 3   # 再加离线wheel与loopback
python tools/verify_tdd_evidence.py         # 原FND02历史完整性
python tools/export_contracts.py --check
```

无Git的ZIP用`--files`或`--lane`；默认命令只检查Git工作区，已提交变更请带base。报告在`var/quality/<run>/summary.json`，未选块为not_run，没有测试结果缓存。

环境里同时存在多个Python时，使用 `.venv/bin/python tools/check.py`。
CI定义已经提供；本轮仅本地运行，没有推送GitHub触发CI。

## 工作台能验证什么

输入“不要拍我”“看照片”“听雨”进入固定Mock场景；`/fail`注入生成失败。
可查看activity/output/permit版本、有效集合和回执数。停止先在浏览器生效，旧结果不能恢复。
支持新请求、重复请求、会话能力token、范围累加、停止截止范围和迟到回执。

**尚无语音、ASR、真实LLM/JEV、角色模型或生图**。工作台仅有文字卡片和状态占位，
不能据此宣称四种角色表演、音频打断、多模态原创资产或完整需求已经完成。

## 目录入口

```text
apps/api/src/mira/
  domain/             纯模型、错误、状态转换
  application/        用例与会话生命周期；ports声明外部能力
  adapters/           Mock生成／审核、内存诊断；未来真实adapter落这里
  config/             类型与唯一env读取入口
  bootstrap/          工厂、组合根、生命周期装配
  entrypoints/http/   DTO、映射、依赖、路由、app factory
apps/web/src/
  app/                浏览器组合根
  features/session/   transport与交互协调
  features/presentation/  本地许可门与占位执行器
  shared/             公开配置、协议验证、generated类型
config/               非秘密默认值与profile
packages/contracts/   自动导出的OpenAPI
requirements/         精确安装版本闭包
scripts/ tools/       启动、安装、合同导出、验证
tests/                unit、integration、architecture、web、browser
docs/                 50h计划、实施ADR、来源快照、交接与验证
```

完整文件树见 `docs/implementation/FILE_TREE.md`。

## 配置与抽象的约束

- `Settings`不可变；默认值→profile→显式dotenv→进程env→测试overrides；未知配置启动失败。
- 业务层不读env、不知道provider名称；仅 `bootstrap/providers.py` 选实现。
- `create_app(settings)`可注入依赖；没有全局容器、import-time连接或反射插件扫描。
- domain标准库限定，application不反向依赖adapters；有自动边界测试。
- 公共DTO单点定义，OpenAPI／TS只导出；新增schema先改owner，再跑drift check。
- live provider槽位明确未实现，选它会失败，不会偷偷Mock或付费。

## 必读文档

[50小时计划](docs/plans/50-hour-delivery.md) · [实施ADR](docs/implementation/ADR-F001-foundation.md) ·
[配置约定](config/README.md) · [开发范例](docs/implementation/config-and-extension-guide.md) ·
[最新交接](docs/handoff/FND-03.md) · [原架构/复用 v0.6](docs/reference/architecture-v0.6/MIRA_架构全书_v0.6.md)

## 运行与安全界限

仅loopback＋单worker，内存会话，有限容量；停止与实例隔离是基础子集，不是生产认证系统。
浏览器token只在内存，诊断不输出用户原文/凭据；只服务明确public/dist文件，不服务仓库根。
刷新不恢复旧会话，关闭按钮释放本地session；完整持久化/隐私清除在WP05后续实现。

依赖来源与素材见THIRD_PARTY.md；AI使用与未进行的人工验证见AI_USAGE.md。
当前fresh依赖下载与远端CI未执行；容器既有依赖下的实测见验证报告，不能混写成全平台可用。
