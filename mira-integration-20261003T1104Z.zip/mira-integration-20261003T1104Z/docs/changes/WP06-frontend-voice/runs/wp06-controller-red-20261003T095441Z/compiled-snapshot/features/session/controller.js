import { PresentationGate } from '../presentation/permit-gate.js';
export class SessionController {
    api;
    effects;
    view;
    config;
    gate = null;
    running = false;
    constructor(api, effects, view, config) {
        this.api = api;
        this.effects = effects;
        this.view = view;
        this.config = config;
    }
    async connect() {
        const clientId = crypto.randomUUID();
        const created = await this.api.create(clientId);
        this.gate = new PresentationGate(created.session.session_id, clientId);
        this.running = true;
        this.view.connected();
        this.install(created.session);
        void this.poll();
    }
    install(snapshot) {
        const gate = this.gate;
        if (!gate || !gate.install(snapshot))
            return;
        if (snapshot.activity_seq !== gate.currentActivity())
            return;
        this.view.update(snapshot);
        for (const effect of snapshot.active_grants) {
            if (!gate.allows(effect))
                continue;
            try {
                this.effects.apply(effect);
                // Foundation evidence is a DOM-applied receipt, not proof of GPU/audio output.
                const receipt = gate.consume(effect);
                if (receipt)
                    void this.api.receipt(receipt).catch(error => this.report(error));
            }
            catch (error) {
                gate.block();
                this.report(error);
            }
        }
    }
    async input(text) {
        if (!this.gate || !text.trim())
            return;
        const id = crypto.randomUUID();
        const basis = this.gate.beginInput(id);
        this.effects.prepareInput();
        try {
            this.install(await this.api.input({ ...basis, request_id: id, text }));
        }
        catch (error) {
            if (this.gate.currentActivity() === basis.activity_seq)
                this.report(error);
        }
    }
    async stop() {
        if (!this.gate)
            return;
        const basis = this.gate.stop(); // local latch first, network second
        this.effects.stop();
        this.view.localStop();
        try {
            this.install(await this.api.stop(basis));
        }
        catch (error) {
            this.report(error);
        }
    }
    async poll() {
        while (this.running) {
            try {
                const snapshot = await this.api.snapshot();
                if (this.running)
                    this.install(snapshot);
            }
            catch (error) {
                this.gate?.block();
                this.report(error);
            }
            await new Promise(resolve => setTimeout(resolve, this.config.pollIntervalMs));
        }
    }
    report(error) {
        this.view.error(error instanceof Error ? error.message : 'Transport unavailable');
    }
    async close() {
        this.running = false;
        this.gate?.block();
        await this.api.close();
    }
}
//# sourceMappingURL=controller.js.map