function object(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('Invalid protocol object');
    return value;
}
function integer(value) {
    return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0;
}
function effect(value) {
    const item = object(value);
    if (typeof item.id !== 'string' || typeof item.value !== 'string'
        || typeof item.digest !== 'string' || !/^[a-f0-9]{64}$/.test(item.digest)
        || !['subtitle', 'pose', 'scene', 'media'].includes(String(item.kind))
        || !integer(item.output_epoch) || !integer(item.activity_seq))
        throw new Error('Invalid effect');
    return item;
}
export function parseSession(value) {
    const item = object(value);
    if (item.schema_version !== '0.1.0-foundation'
        || typeof item.session_id !== 'string' || typeof item.client_instance_id !== 'string'
        || !['revision', 'activity_seq', 'input_epoch', 'output_epoch', 'permit_revision'].every(k => integer(item[k]))
        || !['idle', 'thinking', 'ready', 'stopped', 'error'].includes(String(item.phase))
        || !(item.request_id === null || typeof item.request_id === 'string')
        || !(item.last_error === null || typeof item.last_error === 'string')
        || typeof item.sealed !== 'boolean'
        || !Array.isArray(item.active_grants) || !Array.isArray(item.presented_effects)) {
        throw new Error('Incompatible session contract');
    }
    item.active_grants.forEach(effect);
    item.presented_effects.forEach(effect);
    return item;
}
export function parseCreated(value) {
    const item = object(value);
    if (typeof item.session_token !== 'string')
        throw new Error('Missing session capability');
    return { session: parseSession(item.session), session_token: item.session_token };
}
//# sourceMappingURL=protocol.js.map