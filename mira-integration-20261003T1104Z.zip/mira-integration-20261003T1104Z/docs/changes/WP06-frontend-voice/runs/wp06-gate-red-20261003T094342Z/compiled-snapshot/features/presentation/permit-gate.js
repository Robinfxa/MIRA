/** Browser-owned immediate suppression. A newer server grant cannot clear a local stop. */
export class PresentationGate {
    sessionId;
    clientInstanceId;
    activity = 0;
    presentation = 0;
    expectedRequest = null;
    snapshot = null;
    highestPermit = -1;
    controlFingerprint = null;
    knownEffects = new Map();
    consumed = new Set();
    locallyBlocked = true;
    constructor(sessionId, clientInstanceId) {
        this.sessionId = sessionId;
        this.clientInstanceId = clientInstanceId;
    }
    beginInput(requestId) {
        this.activity++;
        this.expectedRequest = requestId;
        this.locallyBlocked = true;
        return { activity_seq: this.activity, presentation_cutoff: this.presentation };
    }
    stop() {
        this.activity++;
        this.expectedRequest = null;
        this.locallyBlocked = true;
        return { activity_seq: this.activity, presentation_cutoff: this.presentation };
    }
    block() { this.locallyBlocked = true; }
    currentActivity() { return this.activity; }
    install(next) {
        if (next.session_id !== this.sessionId || next.client_instance_id !== this.clientInstanceId)
            return false;
        if (next.permit_revision < this.highestPermit)
            return false;
        if (this.snapshot && next.revision < this.snapshot.revision)
            return false;
        const fingerprint = JSON.stringify([next.activity_seq, next.output_epoch,
            next.request_id, next.active_grants]);
        if (next.permit_revision === this.highestPermit && this.controlFingerprint !== fingerprint) {
            this.locallyBlocked = true;
            throw new Error('Conflicting payload for the same control revision');
        }
        for (const grant of next.active_grants) {
            const identity = JSON.stringify([grant.kind, grant.value, grant.digest, grant.output_epoch, grant.activity_seq]);
            const previous = this.knownEffects.get(grant.id);
            if (previous !== undefined && previous !== identity) {
                this.locallyBlocked = true;
                throw new Error('An issued effect identity cannot change content');
            }
            this.knownEffects.set(grant.id, identity);
        }
        this.highestPermit = next.permit_revision;
        this.controlFingerprint = fingerprint;
        this.snapshot = next;
        this.locallyBlocked = !(next.activity_seq === this.activity
            && this.expectedRequest !== null && next.request_id === this.expectedRequest
            && (next.phase === 'ready' || next.phase === 'idle'));
        return true;
    }
    allows(effect) {
        return !this.locallyBlocked && this.snapshot !== null
            && effect.output_epoch === this.snapshot.output_epoch
            && effect.activity_seq === this.activity
            && this.snapshot.active_grants.some(grant => grant.id === effect.id && grant.digest === effect.digest && grant.kind === effect.kind && grant.value === effect.value)
            && !this.consumed.has(effect.id);
    }
    consume(effect) {
        if (!this.allows(effect))
            return null;
        this.consumed.add(effect.id);
        this.presentation++;
        return {
            effect_id: effect.id, digest: effect.digest, output_epoch: effect.output_epoch,
            activity_seq: effect.activity_seq, presentation_seq: this.presentation,
        };
    }
}
//# sourceMappingURL=permit-gate.js.map