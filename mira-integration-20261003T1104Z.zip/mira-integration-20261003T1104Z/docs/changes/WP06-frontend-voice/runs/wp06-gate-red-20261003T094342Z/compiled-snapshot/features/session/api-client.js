import { parseCreated, parseSession } from '../../shared/protocol.js';
export class MiraApiClient {
    config;
    sessionId = null;
    token = null;
    constructor(config) {
        this.config = config;
    }
    async request(path, method, body, parse) {
        const response = await fetch(this.config.apiBase + path, {
            method,
            headers: { 'Content-Type': 'application/json', ...(this.token ? { 'X-Mira-Session-Token': this.token } : {}) },
            body: body === undefined ? null : JSON.stringify(body),
            signal: AbortSignal.timeout(5000),
            cache: 'no-store',
        });
        if (!response.ok)
            throw new Error(`Request failed (${response.status}); local output stays blocked.`);
        return parse(await response.json());
    }
    async create(clientInstanceId) {
        const created = await this.request('/sessions', 'POST', { client_instance_id: clientInstanceId }, parseCreated);
        this.sessionId = created.session.session_id;
        this.token = created.session_token; // In memory only; no localStorage, URL or logs.
        return created;
    }
    path(suffix = '') {
        if (!this.sessionId)
            throw new Error('Session not connected');
        return `/sessions/${this.sessionId}${suffix}`;
    }
    snapshot() { return this.request(this.path(), 'GET', undefined, parseSession); }
    input(body) { return this.request(this.path('/inputs'), 'POST', body, parseSession); }
    stop(body) { return this.request(this.path('/stop'), 'POST', body, parseSession); }
    receipt(body) { return this.request(this.path('/receipts'), 'POST', body, parseSession); }
    async close() {
        if (this.sessionId && this.token) {
            await fetch(this.config.apiBase + this.path(), {
                method: 'DELETE', headers: { 'X-Mira-Session-Token': this.token }, keepalive: true,
            });
        }
        this.sessionId = null;
        this.token = null;
    }
}
//# sourceMappingURL=api-client.js.map