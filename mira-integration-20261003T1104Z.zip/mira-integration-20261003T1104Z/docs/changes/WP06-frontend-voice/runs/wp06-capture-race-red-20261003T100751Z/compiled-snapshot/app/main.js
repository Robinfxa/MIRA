import { loadPublicConfig } from '../shared/config.js';
import { SceneEffectExecutor } from '../features/presentation/scene-executor.js';
import { MiraApiClient } from '../features/session/api-client.js';
import { SessionController } from '../features/session/controller.js';
function element(selector) {
    const value = document.querySelector(selector);
    if (!value)
        throw new Error(`Missing application element ${selector}`);
    return value;
}
const config = loadPublicConfig();
const status = element('[data-status]');
const diagnostic = element('[data-diagnostic]');
const error = element('[data-error]');
const ptt = element('[data-ptt]');
const voiceHint = element('[data-voice-hint]');
let microphoneAvailable = false;
let held = null;
let closed = false;
function defaultVoiceHint() {
    return microphoneAvailable ? '按住说话，松开后等待可靠转写。停止会立即释放麦克风。' : '麦克风识别未配置或浏览器不支持。可以继续用文字。';
}
const controller = new SessionController(new MiraApiClient(config), new SceneEffectExecutor(element('[data-stage]')), {
    connected() { if (!closed)
        element('fieldset').disabled = false; },
    update(view) {
        status.textContent = view.phase;
        diagnostic.textContent = JSON.stringify({
            state: view.revision, activity: view.activity_seq, output: view.output_epoch,
            permit: view.permit_revision, grants: view.active_grants.length,
            presented: view.presented_effects.length, audioFacts: view.audio_progress.length, sealed: view.sealed,
        }, null, 2);
        if (view.last_error)
            error.textContent = view.last_error;
    },
    error(message) { error.textContent = message; },
    localStop() { status.textContent = 'stopped · 本地已制止'; },
    capabilities(value) {
        if (closed)
            return;
        microphoneAvailable = value.microphone_enabled && typeof navigator.mediaDevices?.getUserMedia === 'function'
            && typeof globalThis.AudioContext === 'function' && typeof globalThis.AudioWorkletNode === 'function' && globalThis.isSecureContext;
        ptt.disabled = !microphoneAvailable;
        const modes = { mock: 'Mock · 固定场景', replay: 'Fixture · 生成夹具回放', injected: '注入后端 · 尚未验收' };
        element('[data-mode-label]').textContent = modes[value.generation_mode];
        element('[data-mode-description]').textContent = `${modes[value.generation_mode]}。${value.qualification === 'unavailable'
            ? '真实语音尚未配置，当前使用文字。' : '语音后端已注入；账户、扬声器、麦克风与真实打断仍需单独验收。'}角色和旅行插画是原创矢量素材，不代表实时生图。字幕显示不代表已经听见或逐字对齐。`;
        voiceHint.textContent = defaultVoiceHint();
    },
    microphone(state) {
        ptt.setAttribute('aria-pressed', String(state === 'recording' || state === 'starting'));
        voiceHint.textContent = state === 'starting' ? '正在打开麦克风；请在浏览器中自行决定是否授权。'
            : state === 'recording' ? '正在听。松开后结束录音并等待转写。'
                : state === 'finishing' ? '录音已停止，正在等待可靠的最终转写…' : defaultVoiceHint();
    },
}, config);
function releaseGesture(cancel) {
    if (held === null)
        return;
    held = null;
    if (cancel)
        void controller.stop();
    else
        void controller.finishMicrophone();
}
function startGesture(identity) {
    if (closed || ptt.disabled || held !== null)
        return;
    held = identity;
    error.textContent = '';
    void controller.startMicrophone();
}
ptt.addEventListener('pointerdown', event => {
    if (event.button !== 0)
        return;
    event.preventDefault();
    startGesture(`pointer:${event.pointerId}`);
    try {
        ptt.setPointerCapture(event.pointerId);
    }
    catch { /* Window pointerup still releases capture. */ }
});
const pointerUp = (event) => {
    if (held === `pointer:${event.pointerId}`)
        releaseGesture(false);
};
ptt.addEventListener('pointerup', pointerUp);
window.addEventListener('pointerup', pointerUp);
ptt.addEventListener('pointercancel', () => releaseGesture(true));
ptt.addEventListener('lostpointercapture', () => releaseGesture(true));
ptt.addEventListener('keydown', event => {
    if (event.key !== ' ' && event.key !== 'Enter')
        return;
    event.preventDefault();
    if (!event.repeat)
        startGesture(`key:${event.key}`);
});
ptt.addEventListener('keyup', event => {
    if (event.key !== ' ' && event.key !== 'Enter')
        return;
    event.preventDefault();
    if (held === `key:${event.key}`)
        releaseGesture(false);
});
// Assistive-technology activation can use a start/finish toggle without pointer events.
ptt.addEventListener('click', event => {
    if (event.detail !== 0)
        return;
    if (held === 'accessible')
        releaseGesture(false);
    else if (held === null)
        startGesture('accessible');
});
window.addEventListener('blur', () => releaseGesture(true));
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden')
    releaseGesture(true); });
element('form').addEventListener('submit', event => {
    event.preventDefault();
    const input = element('[name=message]');
    error.textContent = '';
    held = null;
    void controller.input(input.value);
    input.value = '';
});
element('[data-stop]').addEventListener('click', () => { held = null; void controller.stop(); });
for (const button of document.querySelectorAll('[data-command]')) {
    button.addEventListener('click', () => {
        error.textContent = '';
        held = null;
        void controller.input(button.dataset.command ?? '');
    });
}
element('[data-close]').addEventListener('click', () => {
    closed = true;
    held = null;
    ptt.disabled = true;
    element('fieldset').disabled = true;
    void controller.close().then(() => { status.textContent = 'closed · 刷新可新建'; });
});
window.addEventListener('pagehide', () => { closed = true; held = null; void controller.close(); });
void controller.connect().catch(() => { error.textContent = '连接失败。请刷新后重试；未启动任何语音。'; });
//# sourceMappingURL=main.js.map