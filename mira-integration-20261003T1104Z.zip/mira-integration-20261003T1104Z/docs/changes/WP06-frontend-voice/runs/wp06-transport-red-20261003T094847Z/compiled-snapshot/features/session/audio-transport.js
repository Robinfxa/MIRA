export class BrowserAudioTransport {
    constructor(_config, _credentials, _primitives = {}) { }
    async speech(_effect, _signal, _onPcm) { throw new Error('Speech transport not implemented'); }
    microphone(_origin, _signal) { throw new Error('Microphone transport not implemented'); }
    close() { }
}
//# sourceMappingURL=audio-transport.js.map