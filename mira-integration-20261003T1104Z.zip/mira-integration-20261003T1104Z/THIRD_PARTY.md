# 第三方与素材说明

## 本次实际运行依赖

FastAPI、Starlette、Pydantic、python-dotenv、Uvicorn；测试使用pytest、pytest-asyncio、HTTPX、pytest-cov；
前端只用TypeScript编译器，运行时无前端包；对应版本见requirements/*.lock与package-lock.json。
源码通过包导入，没有复制其底层实现。发布前按所分发具体包保留许可证及NOTICE。

## 只作参考，尚未接入

Codex／CLIProxyAPI／Pi、Pipecat／LiveKit、Charivo、Hindsight等：来源证据和许可边界保留在v0.6 A5。
本次未安装、未运行、未赋予它们真实调用权限，不能把参考列表当实际依赖表。

## 工作台素材

只有CSS布局、文字和抽象字母标记；无照片、字体包、角色模型、第三方音频或用户图片分发。
所有角色／媒体卡片均明确标为占位，不声称完成原创Mira资产或动画要求。

## 许可范围

本交付没有代用户选择项目总体开源许可证；源架构和用户内容不因代码生成被重新授权。
真实依赖的公开文档与入口见 `docs/implementation/official-references.md`。
