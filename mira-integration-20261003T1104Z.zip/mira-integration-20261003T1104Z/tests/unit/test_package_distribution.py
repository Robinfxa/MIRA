"""Cheap packaging policy tests; the real build/install smoke belongs to package lane."""
import runpy
import sys
import tomllib
import types
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]


def test_declared_install_data_contains_config_and_built_workbench():
    config = tomllib.loads((ROOT / "pyproject.toml").read_text())
    data = config["tool"]["setuptools"].get("data-files", {})
    assert "config/defaults.toml" in data.get("config", [])
    assert "apps/web/index.html" in data.get("apps/web", [])
    for folder in ("public", "public/audio", "public/scene", "dist/app",
                   "dist/features/audio", "dist/features/session", "dist/features/presentation",
                   "dist/shared", "dist/shared/generated"):
        assert "apps/web/" + folder in data, folder


def test_wheel_build_fails_loudly_when_javascript_was_not_built(monkeypatch, tmp_path):
    hook = ROOT / "setup.py"
    assert hook.is_file(), "A wheel must reject missing compiled web assets rather than omit them."
    registered = {}
    setuptools = types.ModuleType("setuptools")
    setuptools.setup = lambda **kwargs: registered.update(kwargs)
    command = types.ModuleType("setuptools.command.build_py")
    command.build_py = type("BuildPy", (), {"run": lambda self: None})
    monkeypatch.setitem(sys.modules, "setuptools", setuptools)
    monkeypatch.setitem(sys.modules, "setuptools.command.build_py", command)
    monkeypatch.chdir(tmp_path)
    runpy.run_path(str(hook))
    with pytest.raises(RuntimeError, match="build"):
        registered["cmdclass"]["build_py"]().run()
