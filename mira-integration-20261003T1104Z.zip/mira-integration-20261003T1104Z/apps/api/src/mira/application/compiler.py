"""Assign application-owned effect identity only after a complete range is reviewed."""
import hashlib
import json
from uuid import uuid4

from mira.application.contracts import CandidateRange
from mira.domain.errors import DomainError
from mira.domain.models import Effect


def compile_range(candidate: CandidateRange, *, epoch: int, activity: int) -> tuple[Effect, ...]:
    if not candidate.effects or len(candidate.effects) > 8:
        raise DomainError("invalid_range", "A range must contain between one and eight effects.")
    effects = []
    for proposal in candidate.effects:
        content = json.dumps({"kind": proposal.kind.value, "value": proposal.value},
                             ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        effects.append(Effect(
            id=str(uuid4()), kind=proposal.kind, value=proposal.value,
            digest=hashlib.sha256(content.encode()).hexdigest(),
            output_epoch=epoch, activity_seq=activity,
        ))
    return tuple(effects)
