"""Allowlist encoding plus defensive credential filtering, not a universal DLP claim."""
import base64
import hashlib
import math
import re
from dataclasses import fields

from mira.application.diagnostic_events import (
    CancellationReason,
    ContentReview,
    DiagnosticCode,
    DiagnosticContext,
    DiagnosticEvent,
    DiagnosticKind,
    DiagnosticOutcome,
    DiagnosticStage,
    RecordingKind,
    ReviewedRecording,
)

_CONTEXT_KEYS = tuple(field.name for field in fields(DiagnosticContext))
_HASH = re.compile(r"h_[0-9a-f]{32}\Z")
_FORBIDDEN_ENVELOPE = re.compile(
    r'(?i)(?:authorization\s*[":=]|["\'](?:headers|private_key|client_secret|credentials|'
    r'access_token|refresh_token|id_token|password|api_key|x-api-key)["\']\s*:|'
    r'-----BEGIN [A-Z ]*PRIVATE KEY-----)')
_SECRET_SHAPES = (
    re.compile(r"(?i)\b(?:[A-Za-z][A-Za-z0-9_-]*[_-])?(?:api[_-]?key|password|passwd|private[_-]?key|access[_-]?token|refresh[_-]?token|"
               r"client[_-]?secret|secret|credentials|token)\s*(?:=|:|\bis\b)\s*"
               r"(?:\"[^\"\r\n]*\"|'[^'\r\n]*')"),
    re.compile(r"(?i)\bBearer\s+[^\s,;\"']+"),
    re.compile(r"\b(?:sk-[A-Za-z0-9_-]{8,}|AIza[A-Za-z0-9_-]{20,}|AKIA[A-Z0-9]{16})\b"),
    re.compile(r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b"),
    re.compile(r"(?i)\b(?:[A-Za-z][A-Za-z0-9_-]*[_-])?(?:api[_-]?key|password|passwd|private[_-]?key|access[_-]?token|refresh[_-]?token|"
               r"client[_-]?secret|secret|credentials|token)\s*(?:=|:|\bis\b)\s*[^\s,;\"']+"),
    re.compile(r"(?i)https?://[^\s/@:]+:[^\s/@]+@[^\s]+"),
)


def context_dict(context: DiagnosticContext) -> dict:
    if type(context) is not DiagnosticContext:
        raise ValueError("invalid correlation")
    result = {}
    for key in _CONTEXT_KEYS:
        value = getattr(context, key)
        if value is not None:
            if type(value) is not str or not 1 <= len(value) <= 256:
                raise ValueError("invalid correlation")
            result[key] = "h_" + hashlib.sha256(value.encode()).hexdigest()[:32]
    return result


def _number(value, *, minimum=0, maximum=86400000):
    if type(value) not in (int, float) or not math.isfinite(value) or not minimum <= value <= maximum:
        raise ValueError("invalid numeric field")
    return round(value, 3)


def encode_event(event: DiagnosticEvent, now: float) -> dict:
    if type(event) is not DiagnosticEvent:
        raise ValueError("invalid event")
    result = {"schema": 1, "record_type": "event", "timestamp": _number(now, maximum=1e12),
              "stage": DiagnosticStage(event.stage).value,
              "kind": DiagnosticKind(event.kind).value,
              "outcome": DiagnosticOutcome(event.outcome).value,
              "context": context_dict(event.context)}
    if event.code is not None:
        result["code"] = DiagnosticCode(event.code).value
    if event.cancellation_reason is not None:
        if event.outcome != DiagnosticOutcome.CANCELLED:
            raise ValueError("cancellation reason requires cancelled outcome")
        result["cancellation_reason"] = CancellationReason(event.cancellation_reason).value
    if event.duration_ms is not None:
        result["duration_ms"] = _number(event.duration_ms)
    if event.http_status is not None:
        if type(event.http_status) is not int or not 100 <= event.http_status <= 599:
            raise ValueError("invalid status")
        result["http_status"] = event.http_status
    return result


def validate_event_record(record: dict) -> dict:
    required = {"schema", "record_type", "timestamp", "stage", "kind", "outcome", "context"}
    optional = {"code", "cancellation_reason", "duration_ms", "http_status"}
    if (type(record) is not dict or not required <= record.keys()
            or record.keys() - required - optional or type(record["schema"]) is not int
            or record["schema"] != 1 or record["record_type"] != "event"):
        raise ValueError("invalid event schema")
    context = record["context"]
    if (type(context) is not dict or context.keys() - set(_CONTEXT_KEYS)
            or any(type(value) is not str or not _HASH.fullmatch(value) for value in context.values())):
        raise ValueError("invalid correlation")
    event = DiagnosticEvent(stage=record["stage"], kind=record["kind"], outcome=record["outcome"],
        code=record.get("code"), cancellation_reason=record.get("cancellation_reason"),
        duration_ms=record.get("duration_ms"), http_status=record.get("http_status"))
    checked = encode_event(event, record["timestamp"])
    checked["context"] = dict(context)
    return checked


class PrivacyFilter:
    """Trusted injection of active secrets; repr never exposes them.

    Pattern checks are a second defense. Exact-record privacy review is still
    mandatory, especially for audio and unknown credential formats.
    """
    def __init__(self, secrets=()):
        self._secrets: tuple[str, ...] = ()
        for value in secrets:
            self.add_secret(value)

    def add_secret(self, value: str) -> None:
        if type(value) is not str or not value or len(value) > 8192:
            raise ValueError("invalid trusted secret")
        if value in self._secrets:
            return
        if len(self._secrets) >= 4096:
            raise ValueError("trusted secret budget reached")
        self._secrets += (value,)

    def text(self, value: str) -> str:
        if _FORBIDDEN_ENVELOPE.search(value):
            raise ValueError("credential envelope is ineligible")
        for secret in sorted(self._secrets, key=len, reverse=True):
            value = value.replace(secret, "[REDACTED]")
        for pattern in _SECRET_SHAPES:
            value = pattern.sub("[REDACTED]", value)
        return value

    def recording(self, record: ReviewedRecording, *, now: float,
                  max_text_bytes: int, max_audio_bytes: int) -> dict:
        if (type(record) is not ReviewedRecording
                or record.review not in (ContentReview.APPROVED, ContentReview.REDACTED)):
            raise ValueError("privacy review required")
        kind = RecordingKind(record.kind)
        result = {"schema": 1, "record_type": "reviewed_raw",
                  "timestamp": _number(now, maximum=1e12), "kind": kind.value,
                  "privacy_review": ContentReview(record.review).value,
                  "context": context_dict(record.context)}
        if kind in (RecordingKind.DIALOGUE, RecordingKind.MODEL_INPUT, RecordingKind.MODEL_OUTPUT):
            if (type(record.text) is not str or record.audio is not None
                    or record.sample_rate_hz is not None
                    or len(record.text) > max_text_bytes
                    or len(record.text.encode()) > max_text_bytes):
                raise ValueError("invalid text buffer")
            result["text"] = self.text(record.text)
        else:
            if (type(record.audio) is not bytes or record.text is not None
                    or not record.audio or len(record.audio) % 2
                    or len(record.audio) > max_audio_bytes
                    or type(record.sample_rate_hz) is not int
                    or record.sample_rate_hz not in (16000, 24000, 48000)):
                raise ValueError("invalid audio buffer")
            # A known credential embedded as bytes is also forbidden. This is not
            # spoken-secret detection; approval must cover listening/privacy review.
            if any(secret.encode() in record.audio for secret in self._secrets):
                raise ValueError("credential bytes")
            ascii_view = record.audio.decode("ascii", errors="ignore")
            if _FORBIDDEN_ENVELOPE.search(ascii_view) or any(
                    pattern.search(ascii_view) for pattern in _SECRET_SHAPES):
                raise ValueError("credential bytes")
            result["audio_base64"] = base64.b64encode(record.audio).decode("ascii")
            result["sample_rate_hz"] = record.sample_rate_hz
        return result


def validate_raw_record(record: dict) -> dict:
    required = {"schema", "record_type", "timestamp", "kind", "privacy_review", "context"}
    if (type(record) is not dict or not required <= record.keys()
            or record.keys() - required - {"text", "audio_base64", "sample_rate_hz"}
            or type(record["schema"]) is not int or record["schema"] != 1
            or record["record_type"] != "reviewed_raw"):
        raise ValueError("invalid recording schema")
    context = record["context"]
    if (type(context) is not dict or context.keys() - set(_CONTEXT_KEYS)
            or any(type(value) is not str or not _HASH.fullmatch(value) for value in context.values())):
        raise ValueError("invalid correlation")
    audio = None
    if "audio_base64" in record:
        audio = base64.b64decode(record["audio_base64"], validate=True)
    checked = PrivacyFilter().recording(ReviewedRecording(kind=record["kind"],
        review=record["privacy_review"], text=record.get("text"), audio=audio,
        sample_rate_hz=record.get("sample_rate_hz")), now=record["timestamp"],
        max_text_bytes=128 * 1024, max_audio_bytes=512 * 1024)
    checked["context"] = dict(context)
    return checked
