# Current direct-provider stage — 2026-10-04 22:08 UTC

User clarified that the product connects directly to providers; native Codex is an optional development adapter. The next source adds explicitly selected subscription OAuth and official API-key Responses routes, separate MIRA-owned auth, and an application launcher. Offline synthetic HTTPX plus actual ASGI/Actor/JEV composition is being tested. No real OAuth grant, direct inference, microphone/playback or full direct-stage release has been verified yet.

Latest immutable published component is2103:984 files,13 release lanes,2127 pytest plus13 subtests,355 Node,107 installed-resource hashes. Root verified all seven archive files at [9b6a2b1](https://github.com/Robinfxa/MIRA/commit/9b6a2b1a38c8f29ab8c6108a4afec12ec92f224a). Initial upload was blocked pending per-match secret review; review was completed and the same upload succeeded. Expanded source/main were not changed. This backup includes finite click-start/manual-send continuous listening, not automatic gapless dialogue or the new direct provider.

New visual mesh/composition/transition artifacts remain review prototypes outside this application source. The approved twelve portraits remain the production assets; no layered rig is claimed.

## Preserved earlier-stage evidence

# MIRA current acceptance boundaries — 2026-10-04 20:57 UTC

Published1845 is the latest verified archive: all12 release lanes passed (2,010 pytest tests plus13 subtests,329 Node tests,package/HTTP smoke),962 restored file hashes/modes matched, and all seven delivery files were remotely verified at [a6de84e](https://github.com/Robinfxa/MIRA/commit/a6de84e3fc64767222bb8a312266be77ec6f71f0). This is an archive publication; expanded repository application code remains older. Prior stages remain immutable.

Published1845 adds the provider-free local memory console, actual-byte request guard, bounded official startup notifications, reviewed macOS npm-native discovery, provisional STT preview and separate numeric clocks, plus the optional table-free V3 background. Its independent local-console and native-resolution controls passed, including the actual pre-fix oversized-body/launcher failures and their repairs. It does not prove the user's Mac RPC issue was fixed or that the new background was visually accepted. Linux npm optional packages do exist;1845's misleading source comment was corrected in its START-HERE, and this next source corrects the comment without changing pins.

Next candidate2021 combines finite application usage and click-start continuous listening with explicit revision-bound manual send. Its exact983-file capture passed13 release lanes (2079 pytest plus13 subtests,342 Node;107 wheel resources/101 HTTP assets). The subsequent v3 frontend passed40 targeted and4 real local synthetic HTTP/WebSocket cases, including receipt-prefix, final-cap/Stop and PTT/raw-recording/audition boundaries. A confirmed Stop→Start unsent-preview loss was fixed with a bounded prior-preview list and explicit empty-composer restoration. The complete merged source still requires a fresh release/restore receipt. No paid provider call was added. The user reported the1845 offline page operating normally on their Mac at20:23 and saw an unwanted old foreground rain overlay when choosing the painterly background. This establishes only that observed offline interaction; all-frame visual, voice and full device acceptance remain open.


The next candidate's application usage profile and click-start/manual-send continuous listening remain subject to coherent integration and independent lifecycle acceptance. The original usage slice's double CLI validation failure is preserved and repaired; local software tests are not a new provider call or real microphone acceptance.

Memory editing remains explicit, paired, scoped and reversible. No automatic recording, personality learning or real memory-dialogue quality is established. User12:07–12:20 observed the offline portrait and whole-frame movement, reporting stiffness and background mismatch. Real microphone/audible continuous dialogue and the3–5 minute recording remain unaccepted.

A subsequent real TCP check found that a fresh0837 installation lacks a Uvicorn WebSocket implementation: health200 but legitimate microphone upgrade404. The isolated wsproto1.3.2 repair passed5 directed plus8 independent real-socket cases. That establishes software transport behavior only; no browser, microphone or provider was involved. The current slice also narrowly updates the optional auth helper's PyJWT pin to2.15.1. On an isolated Python3.12 runtime,21 original/new auth tests and7 independent boundary tests passed, with unchanged auth implementation; these repairs are included in the later full-green0952 and1212 archives. Published0837 remains immutable and superseded.
Normal text generation/review sealed subtitle+pose grants without presentation. Synthetic audio completed STT and generation/review but correctly stopped as UNKNOWN before TTS. Separately, fixed production TTS yielded3.24 seconds of complete PCM with1.274-second dispatch-to-first-PCM timing and no playback. See [exact provider evidence](PROVIDER-EVIDENCE-20261004.md); none is a human device test.

## Published1515 recall and1659 manual management

Published1212 includes the explicit-consent local SQLite store/CLI and bounded
context preview, plus official Codex0.159.2 macOS arm64/x86_64 binary pins.
The user has observed the offline character on their Mac. Their live metadata
setup remains blocked at a protocol-envelope check; a separate two-file
sanitized diagnostic was delivered. A verified binary hash does not establish
account entitlement or portable live inference.

Published1515 adds opt-in text Actor recall and a local operator pairing
boundary. Only manual USER_STATEMENT records are eligible; default
startup does not read memory, and automatic recording/personality learning is
still absent. The1356 candidate exposed unauthenticated session access to the
configured scope and failed legacy-evaluator compatibility tests. These are
retained real failures. The fixes passed the new1515 coherent release and78
independent privacy/lifecycle checks;1212's earlier green receipt was not reused.

## PDF core requirements

| Item | Implemented or actual evidence | Still unaccepted |
|---|---|---|
| PDF-01 continuous 3–5 min session | Interactive scene, text/voice seams and offline rehearsal exist. | No human-recorded continuous live session. |
| PDF-02 scene is visual focus | Pixi full-frame adult character and scene integration in source. | User12:07 observed the offline portrait; phone and all state combinations remain unverified. |
| PDF-03 background, character, captions, text and voice entry | UI and controls implemented; rehearsal supports fixed text. | Real-browser controls not user-verified; rehearsal input is simulated. |
| PDF-04 mobile-first and desktop | Responsive rules and 390×844 checklist exist. | No real-phone/Safari check; narrow desktop is only emulation. |
| PDF-05 idle/listen/think/speak states | Phase labels and character mappings with software tests. | User-perceived distinctions unverified; rehearsal listen is simulated. |
| PDF-06 text chat | One native Luna text probe sealed after 4 JEV 200 checks in 6.332s, with subtitle+pose grants. | Zero presentation receipts; no user-visible continuous live text session. |
| PDF-07 real microphone | Capture/PTT path exists; isolated wsproto repair passed real TCP authentication/close/limits after exposing the missing0837 dependency. | No human microphone/device input accepted. 07:29 synthetic-audio STT probe is not a user mic. |
| PDF-08 audible speech + matching subtitle | Offline cue subtitles and 8 prerecorded synthetic English Flite/slt clips (~52.56s total); historical TTS produced one complete 3.4s Chinese PCM artifact. | Independent production TTS succeeded; human playback/audibility/subtitle and natural whole-session checks remain open. 07:29 probe did not call TTS. |
| PDF-09 multi-turn continuity | Finite rehearsal steps and scene state exist. | No continuous human live multi-turn session. |
| PDF-10 interrupt by starting new speech | PTT/capture and software stop paths exist. | No real new-speech interruption while audible playback is occurring. |
| PDF-11 stop sound immediately | Local-first stop code/tests. | No physical acoustic tail measurement. |
| PDF-12 cancel/invalidate reply | Software cancellation/stale-result tests. | No human live-provider delay/interrupt result. |
| PDF-13 block pending caption/action/media | Gate and stale-callback tests. | No live browser/audio/media observation. |
| PDF-14 return to listen and handle new input | UI phases and PTT path exist. | Real microphone continuation after interruption untested. |
| PDF-15 late/rapid replies never revive | Race/cancellation tests. | No user-observed real-service race. |
| PDF-16 clear interrupt gesture/reason | Current published path uses hold-to-talk/Stop; user-requested click-start continuous listening is under development. | User understanding of live control untested. |
| PDF-17 structured effects drive image | Sealed text probe granted subtitle and look-at-rain pose. | That probe presented zero effects; no human-observed live effect. |
| PDF-18 ≥3 expressions | 12 Pixi action×expression frames include 4 expressions; mapping tests. | User has seen the offline character, but all12 frame combinations and phone rendering are not accepted. |
| PDF-19 ≥2 non-speaking actions | Camera-lowered and look-at-rain states are implemented. | Actual pixels/legibility unverified. |
| PDF-20 environment change | Rain/window and warm-light commands exist with tests. | User observed the optional drawn background and reported a foreground-rain layering defect; state-by-state acceptance remains pending. |
| PDF-21 content-driven visual event | Fixed photo event is tied to approved interaction; gate tests exist. | No live presented browser event verified. |
| PDF-22 one multimodal branch | Selected branch: Pixi character CSS motion plus state-driven12 full frames, with animated SVG fallback. Idle/listening/speaking compositor motion has no mouth-sync; software integration is accepted on0810, actual browser perception remains open. | Browser/GPU/phone/user perception still open. |
| PDF-23 video lifecycle | Video branch not selected. | N/A for selected animation branch. |
| PDF-24 generated-media lifecycle | Runtime generated media not selected. | N/A for selected animation branch. |
| PDF-25 page→server→model | One Luna+JEV text probe sealed permits in 6.332s, no presentation. | No successful user-visible live loop. **07:29 separately source-bound probe:** a 4.66-second synthetic English audio input produced the exact 79-character transcript. Native generation and four JEV HTTP 200 responses followed; final review returned UNKNOWN because o1/o2 confidence was .58/.55 (<.6). No TTS, playback or presentation; this was not a transport failure. |
| PDF-26 failure/recovery | `/fail`, error handling, and offline fallback have software tests. | No human live timeout/network/audio/media recovery accepted. |
| PDF-27 no-key demo | Fixed offline rehearsal is explicitly labeled and makes no provider calls. | User has seen the offline portrait and whole-frame movement; full scripted control/speaker acceptance and recording remain open. |
| PDF-28 sources/secrets | `THIRD_PARTY.md`, asset notes, templates and secret exclusion are present. | Audit the final exact delivery bundle before release. |

## PDF delivery items

| Item | State | Needed to close |
|---|---|---|
| PDF-D01 source | **Verified1845 archive available:**962 files,12-lane release and exact restore passed; remote commita6de84e. Expanded repository code remains older. This candidate requires its own source-bound release. | Publish exact current source with matching three-part code/assets bundle and pair its ID with the video. |
| PDF-D02 startup route | **Documented:** matching restore manifests/helpers ship beside, not inside, each three-part source pack. | Verify the same-stage pack and instructions from a new destination. |
| PDF-D03 ≤15-minute clean start | **Linux fresh-project check passed:** Python3.12.14 with cold project caches, bootstrap54.837s and rehearsal readiness3.518s, whole attempt5m55s. User's clean OS/device remains untested; Python3.13.5 without ensurepip failed the original bootstrap. | Time restore, locked install, server-ready, browser open separately; record OS and tool versions. |
| PDF-D04 3–5-minute video | **Not run; no video file.** | User records an actual playable 3–5-minute take with interaction, changes, audible interruption, Pixi branch, and failure/recovery. |
| PDF-D05 README | **Present:** README links this current matrix and labels the older device checklist historical; elapsed calendar time is not human labor. | Keep the final stage and actual release result current; do not claim measured labor hours. |
| PDF-D06 AI_USAGE.md | **Present/candid:** AI work, examples, and no human acceptance recorded. | Add only actual human device/browser observations after run. |
| PDF-D07 gap disclosure | **Present:** README lists open browser, phone, audio, mic, live session and recording. | Update with observed results and next steps. |

## Current closing conditions

1. The new frozen stage must pass its own full source/public release and restore checks before publication. Published1845 is the latest verified archive and retains the WebSocket dependency repair.
2. Use one matching delivery's manifest/helper and all three ZIPs. Sidecars ship beside the ZIPs; a source tree does not contain its own self-referential archive manifest. Do not mix stages or hand-edit checksums.
3. Human browser/device acceptance and an actual 3–5-minute recording remain open. Follow [the recording guide](../development/DEMO-RECORDING.md). Software state, an ASGI response, or a permit does not prove human perception. Never bypass a browser/network access restriction.

The07:17 failed receipt is retained: Python/spec lanes passed; web build refused its in-project artifact path; package/smoke were not run. The repair moves disposable web output outside the project, preserving the guard. Read the matching delivery START-HERE for the subsequent full release result. Older DEVICE-ACCEPTANCE and19:27 reports remain historical.

## Current user-device setup facts

At20:47 the user applied the schema-aware remoteControl/status/changed patch to1845 on their Mac; the next prepare counted one accepted passive notification. The next blocker was config/read profile drift, and at20:56 the safe diagnostic identified `developer_instructions:null`: an inactive optional value, not a configured instruction. This source fixes the key-presence false rejection, with null/empty positive controls and nonempty/nested/malformed negative controls. A bounded diagnostic patch now distinguishes response shape/type, a known unsafe field, and named effective-config checks using fixed labels, type and emptiness only. It does not print config values or relax those decisions. This is not a claim of completed Mac metadata/model admission.

Optional painterly V3 now suppresses the old foreground rain animation while classic retains it; original rain-window/warm environment changes remain. The repair follows user feedback and software regressions, with the revised composite awaiting user review.
