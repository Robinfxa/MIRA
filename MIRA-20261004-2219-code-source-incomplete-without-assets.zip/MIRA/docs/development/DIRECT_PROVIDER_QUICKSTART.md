# Direct provider startup

This source provides two explicit routes. Neither requires the Codex executable,
an app-server process, a binary pin, or a native-environment admission file.
Real OAuth and model access remain unverified for this new stage. `check` proves
only local configuration, never account eligibility or a successful conversation.

## 1. Install and configure

Use the package's START-HERE to restore and run `python tools/bootstrap.py`.
Keep the existing private `.env` if you already configured JEV/Google. Do not
copy another app's auth file or send credentials in chat. The explicit env file
may be inside this project, but must be owner-readable/writable only and excluded
from Git. No automatic login occurs on startup or on `check`.

JEV is needed by both live modes:

```text
MIRA_SERVICES__JEV__API_KEY=<enter locally>
MIRA_SERVICES__JEV__MODEL=jev-1.13.0
```

Choose a model actually available to your chosen account/route; no model catalog
or entitlement check is performed implicitly, and no substitute model is chosen.

## 2A. Subscription login and direct text

```sh
.venv/bin/python tools/provider_login.py login
```

Read the displayed warning and confirm LOGIN only if you want this separate
MIRA session. Open the official link and enter the temporary device code there.
This grants MIRA ongoing access; credentials are stored in its own private local
app-data directory, unencrypted and excluded from the project. No Codex/Hermes
credential discovery or copy is used. The implementation targets the private
ChatGPT/Codex subscription Responses backend: its support, terms, quota and
account eligibility are not the official public OpenAI API contract. Login
completion alone does not prove model access.

On macOS the default session is under
`~/Library/Application Support/MIRA/auth/openai-codex-session.json`.
Linux uses `~/.local/share/mira/auth/openai-codex-session.json`.

```sh
PYTHONPATH=apps/api/src .venv/bin/python tools/live_provider.py check \
  --provider chatgpt_subscription --model YOUR_MODEL --env-file .env

PYTHONPATH=apps/api/src .venv/bin/python tools/live_provider.py serve \
  --provider chatgpt_subscription --model YOUR_MODEL --env-file .env \
  --authorize-provider-data
```

`--authorize-provider-data` acknowledges sending your dialogue and candidate
responses to the selected OpenAI service and TypeSafe/JEV for independent
review. It does not enable memory recall or raw recording. An expired MIRA
session may refresh automatically at an explicitly requested generation call.

## 2B. Official API billing route

Add your own official OpenAI API key locally:

```text
MIRA_SERVICES__OPENAI__API_KEY=<enter locally>
```

```sh
PYTHONPATH=apps/api/src .venv/bin/python tools/live_provider.py check \
  --provider openai_api --model YOUR_API_MODEL --env-file .env

PYTHONPATH=apps/api/src .venv/bin/python tools/live_provider.py serve \
  --provider openai_api --model YOUR_API_MODEL --env-file .env \
  --authorize-provider-data --authorize-api-billing
```

This route sends requests only to `https://api.openai.com/v1/responses` and can
incur API charges. It never uses the subscription session, and subscription
failure never enables it. Arbitrary third-party endpoint/key forwarding is not
implemented. Request counts below are technical limits, not dollar guarantees.

## 3. Browser and finite voice

Open the printed loopback URL. The default port is8000; choose `--port` if it is
already in use. Do not terminate an unknown process or open the app to a network
by changing system/firewall settings. Remote/LAN serving is not enabled here.

For Google voice, retain the Google fields from [API_ENV](API_ENV.md) and supply
your own existing ADC path with separate audio/text transmission and spend
consent. Append to either `serve` command:

```sh
  --voice --adc-file /absolute/path/to/application_default_credentials.json \
  --authorize-google-voice-data-and-spend \
  --stt-requests 10 --tts-requests 20 --stt-max-seconds 120 --tts-max-seconds 30
```

The microphone still requires a click and browser permission. Continuous
listening has a finite lease, keeps silence packets, displays provisional text,
and requires explicit Send for stable text. It can stay open across a reply;
Stop closes the microphone and stops the reply. At a limit it visibly stops;
there is no gapless rollover or automatic utterance submission. Headphones are
recommended until real-device echo behavior is verified. Never claim the local
software tests establish microphone permission, audibility or latency.

Default per-process text ceilings are20 generation requests/20 turns and40
input plus40 output JEV requests. Use `--help` to choose smaller finite limits.
These are not monthly controls or currency caps, and restart resets them.

## Recovery and limits

- `provider_login.py status` checks only the MIRA store, without refresh/network.
- `logout` creates a local signed-out state. A recoverable backup remains;
  provider-side grant revocation is not claimed, and an already dispatched
  in-flight request cannot be recalled by local logout.
- `restore-backup` is explicit; no silent fallback to old credentials occurs.
- `forget` needs a separate DELETE confirmation and permanently removes only
  MIRA's local active/backup records, not the provider's grant.
- Provider errors remain distinguishable from JEV semantic rejection/UNKNOWN.
  UNKNOWN yields the existing deterministic system clarification, without
  turning uncertain content into an approved action or retrying the provider.
- The local memory console remains separately usable without any model login.
  The direct CLI currently leaves memory recall off; existing recorder consent
  does not authorize sending stored memory through these new recipients.
- This implementation has synthetic auth/HTTP/ASGI verification. Real login,
  complete direct voice dialogue, Windows/macOS auth behavior and user-device
  visual/audio acceptance remain to be checked on the actual release.
