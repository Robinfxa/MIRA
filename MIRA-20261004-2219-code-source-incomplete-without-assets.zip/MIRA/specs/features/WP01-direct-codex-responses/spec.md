# WP01 Direct Codex Responses generation adapter

Status: offline implementation slice; default-OFF. The ChatGPT Codex Responses route is
private/undocumented for third-party compatibility; offline mocks establish request shape,
not service availability, permitted use, quota, model access, semantic review, or presentation.
No real request, auth grant, login, or credentials were used. `httpx==0.28.1` is already pinned.
The existing GenerationBackend, SessionActor, independent JEV review, compiler, and output
epoch remain the authority. This adapter only proposes untrusted candidate effects.

### WP01DR-001 Explicit fixed route and model
Given no explicit admission and positive request budget, generation fails before credential
access or network. Given an explicit `chatgpt_subscription` or `openai_api` route and one
validated model identifier, send only to that route's fixed endpoint. Never retry, change
model, change route, or switch billing. Subscription defaults are the factory's responsibility.

### WP01DR-002 Opaque route-specific credentials
Given an injected `get_credentials()` source, read only a SecretStr access token. Send it as
Bearer auth only to the fixed route endpoint. Subscription may additionally send the supplied
`ChatGPT-Account-ID` and `x-openai-internal-codex-residency`; the public API route must omit
both. Never inspect auth storage, log raw body/headers/token, or derive metadata in this adapter.

### WP01DR-003 Bounded Responses request
Given valid generation context, reuse fixed local prompt/instructions and send Responses
`instructions` plus a single user `input` message, `stream: true`, and `store: false`. Expose
no tools, tool choices, or side-effect execution. Subscription route does not assume support
for `text.format`; both routes still use strict local candidate parsing.

### WP01DR-004 Complete SSE assembly only
Given fragmented/multiline SSE, enforce finite line, event, wire, output, prompt, request,
startup, and turn bounds. Completed `response.output_item.done` assistant message items are
authoritative; output-text deltas are fallback only when no completed item exists for that
message. `response.completed` may have a null output snapshot. Only a clean terminal success,
EOF, one complete text item, and successful local parse produce one CandidateRange.
Errors, incomplete/failed/cancelled terminal states, EOF before success, malformed content,
tool-call items, late cancellation, or unsupported content never yield.

### WP01DR-005 Safe actionable failures and cleanup
Given 401, 403, 429, timeout, transport, contract, incomplete stream, cancellation, or bound
failure, close the stream/client and expose only fixed safe codes plus local stage and known HTTP
status where applicable. Never expose provider error bodies, credentials, raw response headers,
or event payloads. A cancellation never yields a CandidateRange; remote completion/billing
termination is not guaranteed by local cancellation.

## Contract and tests
Port: `GenerationBackend`; route and model selected by the composition/factory owner; no
bootstrap, config, CLI, process, preflight, auth-store, Actor, review, or shared-payload edits
in this slice. Credentials: injected structural protocol agreed with the auth owner. MockHTTP
transport only; no live endpoint or account. The adapter does not claim the private endpoint
is an official public API contract or that either route has quota/model access.

Test lane: providers, owned by the integration director in `tests/quality.toml`.
Required consumer: existing independent generation/review and cancellation contracts.
RED/GREEN target: `python -m pytest tests/contracts/test_direct_codex_responses.py -q`.
Common base and affected plan are owned by the integration director. Synthetic `httpx.MockTransport`
only; no external account, network request, persistent artifact, or actual provider call.
