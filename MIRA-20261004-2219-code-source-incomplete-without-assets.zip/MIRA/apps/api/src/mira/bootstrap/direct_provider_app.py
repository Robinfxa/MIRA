"""Direct-provider app composition. No native executable, auth discovery or network IO.

Callers select subscription OAuth or official API billing explicitly and inject the
matching direct HTTP generation adapter. Review, presentation and cancellation keep
the existing application contracts. Authentication is owned by MIRA's separate flow.
"""
from __future__ import annotations

import math
import re
from collections.abc import Callable
from pathlib import Path
from typing import Literal

from fastapi import FastAPI

from mira.application.ports.generation import GenerationBackend
from mira.adapters.review.jev import JevTransport
from mira.application.decision_policy import (
    DecisionThresholdPolicy, USER_DEVELOPMENT_0_6_V2, is_supported_development_policy,
)
from mira.bootstrap.providers import GoogleVoiceProviders, Providers
from mira.config.loader import ConfigurationError
from mira.config.settings import Settings
from mira.config.memory import MemoryRecallOptions
from mira.entrypoints.http.operator_pairing import OperatorPairing
from mira.entrypoints.http.app import create_app
from mira.application.continuous_listening import ListeningLimits
from mira.bootstrap.development_usage import (
    UsageDeclaration, UsageProfile, UsageSnapshot, parse_usage_profile,
    validate_count,
)

_MAX_TIMEOUT_SECONDS = 30.0


def _bounded_timeout(value: object, name: str) -> float:
    """Validate against the small ceiling before float conversion / isfinite."""
    if type(value) not in (int, float):
        raise ConfigurationError(f"{name} must be a finite number in (0, 30].")
    # This comparison also rejects arbitrarily large integers without converting them
    # to float (which can raise OverflowError inside math.isfinite).
    if value <= 0 or value > _MAX_TIMEOUT_SECONDS:
        raise ConfigurationError(f"{name} must be a finite number in (0, 30].")
    if type(value) is float and not math.isfinite(value):
        raise ConfigurationError(f"{name} must be a finite number in (0, 30].")
    return float(value)


def create_direct_provider_app(
    *,
    generation: GenerationBackend,
    model: str,
    settings: Settings,
    route: Literal["chatgpt_subscription", "openai_api"],
    api_billing_authorized: bool = False,
    input_transport: JevTransport,
    output_transport: JevTransport,
    authorized: bool,
    decision_policy: DecisionThresholdPolicy = USER_DEVELOPMENT_0_6_V2,
    generation_request_limit: int = 1,
    session_turn_limit: int = 1,
    input_request_limit: int = 2,
    output_request_limit: int = 2,
    input_timeout_seconds: float = 10.0,
    output_timeout_seconds: float = 10.0,
    usage_profile: UsageProfile | str = UsageProfile.PROBE,
    voice_factory: Callable[[], GoogleVoiceProviders] | None = None,
    voice_usage_limits: object | None = None,
    voice_required: bool = False,
    web_root: Path | None = None,
    memory_options: MemoryRecallOptions | None = None,
    operator_pairing: OperatorPairing | None = None,
    authorize_local_memory_management: bool = False,
    authorize_memory_to_direct_provider_and_jev: bool = False,
) -> FastAPI:
    """Compose one loopback app after the caller has admitted all transmissions.

    An absent voice bundle selects text-only candidate generation. ``voice_required``
    needs an already-authorized in-process voice factory; the CLI intentionally does
    not load one from a module or plugin.
    """
    if type(settings) is not Settings or not callable(getattr(generation, "generate", None)):
        raise ConfigurationError("Direct provider requires typed settings and a generation adapter.")
    if route not in ("chatgpt_subscription", "openai_api"):
        raise ConfigurationError("Choose an explicit supported direct provider route.")
    if type(model) is not str or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:/-]{0,199}", model) is None:
        raise ConfigurationError("Direct provider requires an explicit bounded model identifier.")
    if type(api_billing_authorized) is not bool:
        raise ConfigurationError("API billing acknowledgement must be explicit.")
    if route == "openai_api" and not api_billing_authorized:
        raise ConfigurationError("Official API billing requires a separate explicit acknowledgement.")
    if type(authorize_memory_to_direct_provider_and_jev) is not bool:
        raise ConfigurationError("Direct-provider memory transmission consent must be explicit.")
    if memory_options is not None and not authorize_memory_to_direct_provider_and_jev:
        raise ConfigurationError("Stored memory needs new direct-provider and JEV transmission consent.")
    if authorized is not True:
        raise ConfigurationError("Direct provider requires explicit dialogue transmission and applicable spend consent.")
    if not is_supported_development_policy(decision_policy):
        raise ConfigurationError("Development app requires the supported immutable policy.")
    usage_profile = parse_usage_profile(usage_profile)
    validate_count(generation_request_limit, usage_profile, name="Generation request ceiling")
    validate_count(input_request_limit, usage_profile, name="Input JEV request ceiling")
    validate_count(output_request_limit, usage_profile, name="Output JEV request ceiling")
    validate_count(session_turn_limit, usage_profile, name="Session turn ceiling", turns=True)
    if generation_request_limit > session_turn_limit:
        raise ConfigurationError("Generation requests cannot exceed the session turn ceiling.")
    input_timeout = _bounded_timeout(input_timeout_seconds, "Input JEV timeout")
    output_timeout = _bounded_timeout(output_timeout_seconds, "Output JEV timeout")
    if type(voice_required) is not bool:
        raise ConfigurationError("Voice mode must be an explicit boolean.")
    if voice_required and voice_factory is None:
        raise ConfigurationError("Voice-required mode needs an admitted in-process voice factory.")
    if voice_factory is not None and not voice_required:
        raise ConfigurationError("An admitted voice factory requires voice-required mode.")
    if voice_factory is not None and not callable(voice_factory):
        raise ConfigurationError("Voice factory is invalid.")
    if voice_factory is not None:
        from mira.bootstrap.development_voice import DevelopmentVoiceLimits

        if type(voice_usage_limits) is not DevelopmentVoiceLimits:
            raise ConfigurationError("Voice mode requires its exact typed usage limits.")
        if voice_usage_limits.usage_profile is not usage_profile:
            raise ConfigurationError("Voice and text usage profiles must match.")
    elif voice_usage_limits is not None:
        raise ConfigurationError("Voice usage limits require an admitted voice factory.")
    if type(authorize_local_memory_management) is not bool:
        raise ConfigurationError("memory_management_consent_invalid")
    if authorize_local_memory_management and memory_options is None:
        raise ConfigurationError("memory_management_requires_memory_mode")
    if memory_options is None and operator_pairing is not None:
        raise ConfigurationError("operator_pairing_requires_memory_mode")
    if memory_options is not None and type(operator_pairing) is not OperatorPairing:
        raise ConfigurationError("memory_operator_pairing_required")
    memory_factory = None
    memory_management_factory = None
    if memory_options is not None:
        if voice_factory is not None or voice_required:
            raise ConfigurationError("memory_recall_text_only")
        from mira.bootstrap.development_memory import create_development_memory_factory
        memory_factory = create_development_memory_factory(memory_options)
        if authorize_local_memory_management:
            from mira.bootstrap.development_memory_management import create_development_memory_management_factory
            memory_management_factory = create_development_memory_management_factory(
                memory_options, authorized=True)

    # Use the existing independent semantic review ports; never substitute fixture
    # approval or the native process adapter on a direct-provider failure.
    from mira.bootstrap.development_review import create_development_review_providers

    providers: Providers = create_development_review_providers(
        generation=generation,
        input_transport=input_transport,
        output_transport=output_transport,
        authorized=True,
        decision_policy=decision_policy,
        usage_profile=usage_profile,
        input_request_limit=input_request_limit,
        output_request_limit=output_request_limit,
        input_timeout_seconds=input_timeout,
        output_timeout_seconds=output_timeout,
    )

    port = settings.http.port
    safe_settings = settings.model_copy(update={
        "http": settings.http.model_copy(update={
            "host": "127.0.0.1",
            "allowed_origins": (f"http://127.0.0.1:{port}", f"http://localhost:{port}"),
        }),
        "runtime": settings.runtime.model_copy(update={
            "max_sessions": 1,
            "max_turns": session_turn_limit,
        }),
        "providers": settings.providers.model_copy(update={
            "generation": "mock",
            "review": "fixture",
            "allow_external_calls": False,
            "allow_paid_api": False,
            "api_key": None,
        }),
        "diagnostics": settings.diagnostics.model_copy(update={
            # Preserve bounded sanitized diagnostics; only raw capture stays unarmed.
            "development_recording": False,
            "recording_consent": False,
        }),
    })
    listening_limits = None
    if voice_usage_limits is not None:
        # Floor a declared finite STT bound; never round it up. The shared STT
        # adapter may still support sub-second PTT, but the continuous lease protocol
        # advertises whole seconds, so disable only that feature below its minimum.
        admitted_seconds = voice_usage_limits.stt_max_input_seconds
        lease_seconds = min(120, int(admitted_seconds))
        listening_limits = ListeningLimits(max_seconds=lease_seconds,
            max_samples=(16_000 * lease_seconds if lease_seconds else 0),
            max_streams_per_session=4,
            max_total_streams=voice_usage_limits.stt_request_limit)
    app = create_app(safe_settings, providers=providers, voice_factory=voice_factory,
                      web_root=web_root, listening_limits=listening_limits,
                      **({"memory_factory": memory_factory, "operator_pairing": operator_pairing}
                         if memory_factory is not None else {}),
                      **({"memory_management_factory": memory_management_factory}
                         if memory_management_factory is not None else {}))
    app.state.usage_declaration = UsageDeclaration(
        profile=usage_profile, codex_requests=generation_request_limit,
        session_turns=session_turn_limit, input_jev_requests=input_request_limit,
        output_jev_requests=output_request_limit,
        input_jev_timeout_seconds=input_timeout,
        output_jev_timeout_seconds=output_timeout,
        tts_requests=(voice_usage_limits.tts_request_limit
                      if voice_usage_limits is not None else None),
        stt_requests=(voice_usage_limits.stt_request_limit
                      if voice_usage_limits is not None else None),
        tts_max_audio_seconds=(voice_usage_limits.tts_max_audio_seconds
                               if voice_usage_limits is not None else None),
        stt_max_stream_seconds=(voice_usage_limits.stt_max_input_seconds
                                if voice_usage_limits is not None else None),
    )
    app.state.usage_snapshot = UsageSnapshot(app.state.usage_declaration)
    app.state.direct_provider_route = route
    app.state.direct_provider_model = model
    return app

