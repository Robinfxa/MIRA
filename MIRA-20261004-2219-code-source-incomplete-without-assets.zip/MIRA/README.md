# MIRA · 原创角色互动开发版

**可运行的零密钥演示；直连服务入口正在验证，完整语音与设备体验仍待验收。**
MIRA 是一位26岁的原创虚构摄影师，场景是雨夜咖啡馆。角色主绘制使用本地PixiJS高细节全帧PNG；原有SVG角色仍作为完整的渲染/资产失败fallback。应用保留四态、表情与受控动作、文字输入、可取消音频传输/播放、独立语义审核，以及有界脱敏诊断和显式开发录制。离线排练中的按住手势只提交固定合成文本，不采集麦克风；真实语音入口仍待授权后的设备验收。

## 新产品入口：直接连接服务（离线验证中的下一阶段）

用户于2026-10-04 21:09明确最终产品应直连provider，Codex CLI只是本地开发测试便利。新入口是`tools/live_provider.py`，显式选择`chatgpt_subscription`或`openai_api`，不要求安装Codex、二进制pin、native目录、环境指纹或app-server准入。

- 订阅模式由`tools/provider_login.py`启动用户自己的独立MIRA登录，使用MIRA私有存储；不读取或复制Codex/Hermes的认证文件。订阅后端是非公开兼容接口，账户资格、额度与条款适用性不能由本项目保证。
- API模式只连接官方OpenAI Responses API，使用用户明确配置的API key和API计费确认。两条路线不会相互自动切换，暂不接受任意第三方endpoint。
- 两条模式复用现有Actor、JEV独立审核、UNKNOWN系统提示、回执和Stop。语音可显式接入既有Google适配器和有限连续监听；记忆传输保持单独同意，新的命令行入口暂不开放记忆召回选项。
- 此次先以合成HTTP/凭据与实际ASGI回路验收；没有新OAuth授权、真实直连推理、设备麦克风/播放或真实账单证明。下面的历史原生探针结果不代表新直连已实测。最终完整测试与发布状态以本包START-HERE为准。

[直接连接与最短启动步骤](docs/development/DIRECT_PROVIDER_QUICKSTART.md)。旧`live_dev.py`/`live_voice.py`保留为可选开发工具，不是产品必需步骤。

## 当前实现与验收边界

> 最近已发布组件阶段为2103：984文件、13个release lanes全绿（2127 pytest＋13 subtests、355 Node），七个分包交付文件已在恢复分支提交并逐个核验远端。包含有限点击持续监听/手动发送稳定文字、Stop与草稿保留，以及旧雨层修复。它尚不包含本节新直连路线。当前新直连整合候选的完整验收尚未完成；不会借用2103绿色结果。记忆仍不自动记录聊天，完整M06、自然分层角色动作和完整设备语音验收仍有缺口。

以下为源码捕获时的能力与历史证据摘要；本包捕获后的最终完整测试/发布结果以同包START-HERE为准，本文不会为补记结果而改写已冻结源码。最新核对请见“当前阶段与剩余范围”。各次测试和真实调用绑定各自源码快照，不能跨阶段替代验收。

- 默认 `mock` / `replay` 可离线启动，不读取私密 `.env`，不调用模型或真实语音服务。另有显式 `rehearsal`：固定口令、多轮呈现历史、预录英文合成音频及双语字幕，真实麦克风始终关闭。
- 已批准的原生 `gpt-6-luna` 文字探针与4次JEV审核在6.332秒内正常封口，给出字幕和动作许可，但未呈现到屏幕。4.66秒合成英文经生产STT准确转写，随后生成与审核因两项低置信度正确走UNKNOWN系统托底，未调用TTS。独立生产TTS组件完整生成3.24秒中文音频，dispatch到首PCM为1.273694秒，没有实际播放；这些是分开的受控证据，不是自然连续语音会话。详见[精确provider证据](docs/mission/PROVIDER-EVIDENCE-20261004.md)。
- 字幕/动作通过应用生成的 cue 身份与对应语音关联。Stop、新输入和权限撤销先在本地阻断；软件渲染样本不证明用户听见，也不是逐字对齐。
- 普通日志无原文。开发原文录制需要单独开关与确认，保持可见标记；凭据结构与不确定内容拒绝记录。原始音频录制仍默认关闭，只在显式注入的开发语音模式中提供应用范围的开关；最多512 KiB、短时暂存，提供精确缓冲试听，由用户确认已审核、再单独确认排入本机私有诊断队列；软件不能证明人实际听过。ASR转写不能代替原音审核，也没有自动口述秘密检测；队列接收不代表已写入磁盘。默认 mock/replay/rehearsal 麦克风与录制保持关闭。
- 独立审查已发现并修复字幕提前呈现、嵌套凭据过滤、累计音频上下文、错误文案和异常 token 等问题。每个后续阶段须重新冻结源码验证，旧阶段的绿色测试不能替代新版本验收。
- 用户已在自己的Mac看到了离线角色，并于20:23反馈1845离线“结果正常”；同时指出切换绘制背景后仍有旧雨层在前景。此为真实局部视觉反馈，不能扩成全部动作、语音、真麦克风或完整3–5分钟交互验收。手机、扬声器/麦克风、完整录屏、真实模型表现与中文审核校准仍待完成。没有云部署或正式产品就绪声明。

[连续聆听与5分钟验收](docs/development/CONTINUOUS_LISTENING.md) · [项目北极星](docs/NORTH_STAR.md) · [最终需求与验收](docs/mission/requirements-and-acceptance.md) · [当前版本与缺口](docs/mission/CURRENT-ACCEPTANCE.md) · [离线启动快速指引](docs/development/QUICKSTART.md) · [测试政策](docs/development/TESTING.md)

## 显式本机记忆与可选文字应用召回

本地SQLite证据库和`tools/memory.py`已实现：明确选择私有scope配置和数据库，确认后保存用户陈述，按用户/角色/世界隔离，重启后召回，更正采用新版本，忘记采用可恢复tombstone而不物理删除。默认不打开数据库、不读取聊天、不记录原文；写入识别为凭据的内容会拒绝。数据库和scope配置须位于源码checkout之外，普通诊断导出不包含它们。

`context`只输出有界本机预览：当前调用者事实先于记忆，必须保留的边界超预算就失败；可选召回有数量、UTF-8字节与查询时限。所有记忆文本明确标成不可信引用证据；组包前后scope revision变化就拒绝混合快照，不自动重试。它不授予动作权限，也不会把作者往事、推断或未验证的呈现标签当共同经历。

1212的本机工具通过43项组合及12项独立安全检查。后续文字应用可在独立的记忆内容传输授权后，读取同一私有scope中手动保存的陈述；生成和输出审核共享版本绑定的ContextPacket，输入权限审核不收到记忆正文。更正/忘记导致版本变化时，尚未获准的旧结果会停止；Stop、新输入、Close仍可打断读取。Actor召回连接只读，不从聊天自动写入。已发布1659的配对管理面板需额外`--authorize-local-memory-management`选项和逐项确认，使用独立写入连接执行有版本保护的手动修改；Stop不伪称已提交记录被撤销。当前**没有自动记忆提取、人格学习、LearnedStance或Hindsight接入**；真实模型如何使用记忆仍须另行验证，不能称为完整M06。

这项应用召回通过`tools/live_dev.py`单独显式开启，并要求每次启动的一次性本机配对（私有文件交付代码，页面输入，不放网址/日志）；未配对前不打开数据库。接收方为Codex生成和TypeSafe/JEV输出审核；它不继承本地记忆记录或开发原文录制同意。首个切片为文字模式，未披露Google接收方的记忆+语音组合会拒绝。默认离线排练不会读库。详见[本机记忆操作](docs/development/LOCAL_MEMORY.md)和[应用召回、同意与限制](docs/development/ACTOR_MEMORY.md)。

```sh
python tools/memory.py --help
```

## 历史开发工具：macOS Codex准入

0952的真实模型准入只固定了Linux二进制。后续版本新增从OpenAI官方0.159.2发布artifact校验得出的macOS arm64/x86_64 native binary pin，保留Linux pin且未知平台拒绝；这是本地软件校验修复，**本轮未运行Mac进程、登录或模型调用**。正常`codex`命令可能是JavaScript wrapper；显式准备流程现可在不运行wrapper的前提下，从已知官方npm包布局发现唯一、与当前host匹配的native binary，并仍执行既有路径、权限与digest校验。它不复制二进制、不改变权限或版本pin；陌生布局/歧义/不匹配仍拒绝。不要把单个新helper复制进旧0952绕过校验。[平台来源与验证边界](docs/development/CODEX_PLATFORM_PIN_PROVENANCE.md) · [正常准备流程](docs/development/RUNTIME_PREPARATION.md)。当前源码另提供[只读本地配置诊断](docs/development/CODEX_SETUP_DIAGNOSTIC.md)：不运行Codex、不读取认证文件，不自动修改权限。实际Mac的RPC信封失败原因仍待用户下一次统一验收确认，诊断工具不是该失败已修复的证明。

## 服务配置准备

在既有loader中加入具名服务配置和私密模板；提供默认无网络检查、显式有界模型目录检查。
**适配器代码与接入参数不代表账户开通或 live 准入。** 默认应用仍是 mock/replay；真实服务只能在显式装配、授权、预算和对应验收通过后使用。
[API环境与一次性准备](docs/development/API_ENV.md) · [Provider Matrix](docs/development/PROVIDER_MATRIX.md) · [初始环境交接（历史）](docs/handoff/ENV-01.md) · [规格](specs/features/ENV-01-development-services/spec.md)

```bash
python tools/api_env.py init     # 创建空.env；已有文件拒绝覆盖
python tools/api_env.py check    # 默认不联网；字段缺失退出2，不表示MVP失败
python tools/check.py --lane env --jobs 2
```

密钥仅在本机私密文件／进程提供，不发送聊天，不写进spec、日志、前端或截图。

## 历史基础阶段：增量分块测试

以下数字保留原阶段的历史含义，不是当前完整实现的测试总数。

默认开发检查改为affected；定向RED/GREEN不必先跑全量。full当前选择11个离线lane，package/smoke留发布；WP03连续聆听有独立bounded lane，不把设备/真服务验收混进离线测试。
[测试工作流](docs/development/TESTING.md) · [FND03规格](specs/features/FND-03-scoped-quality/spec.md) · [验证](docs/changes/FND-03/verification.md)

最终本地181 Python＋20 Node、18条规格映射通过；4组真实RED/GREEN。定向示例与分块收据均在验证目录，未选检查明确not_run。

## 继承的开发示范

[SDD/TDD示范手册](docs/development/TDD-SDD.md) · [功能规格](specs/features/FND-02-fixture-replay/spec.md) ·
[开发日志](docs/development/LOG.md) · [本轮验证](docs/changes/FND-02/verification.md) · [基础阶段交接（历史）](docs/handoff/FND-03.md)

FND-02是一个新adapter的完整例子，不是空目录：先写规格，真实RED/GREEN，再重构和集成。最终132 Python＋20前端通过；此前73 Python为基线，未伪造其TDD顺序。无新增依赖版本升级。

## 快速启动

需要 Python 3.11–3.13、Node.js 22.12+ 和锁文件声明的依赖。在工程根目录运行：

```bash
sh scripts/dev
```

此命令**不会安装依赖**。先验证 `.venv` 和当前解释器的实际应用导入能力；不完整的 `.venv` 不会遮住可用的当前解释器。
缺依赖会退出 2 并提示显式安装。首次准备需要包注册表：`python3 tools/bootstrap.py`，只写项目 `.venv` 和 `node_modules`。
如果已在其他隔离环境安装依赖，用显式解释器路径，不自动扫描或猜测虚拟环境名称：

```bash
sh scripts/dev --python /absolute/path/to/ready/python
# Windows尚未列入本轮受支持交付范围，见下方平台限制。
```

启动前检查合同、通过本地bundle构建前端，再以单进程提供 API 和静态工作台。浏览器手动打开 `http://127.0.0.1:8000`；可用 `--port 8123` 改端口。
**默认演示固定为 mock，忽略根 `.env` 和进程中的 MIRA 服务配置／常用凭据变量**；不启用 live provider、付费调用或原文记录。`--no-bootstrap` 保留兼容，但现在所有启动都不自动安装。
归档可没有脚本执行位，所以推荐 `sh scripts/dev`，不要求 `chmod`。

### 有声离线排练（推荐演示入口）

```bash
sh scripts/dev --profile rehearsal
# 已验证可用的其他解释器可追加 --python /absolute/path/to/ready/python
```

页面常显 `OFFLINE · 固定互动排练`。这条路线只有 7 个固定口令和一个失败注入，不支持自由对话；目录外文字只得到明确口令提示，不被假装识别或转述。真实麦克风按钮保持关闭，独立「按住演练输入 · 不录音」只展示 listening 状态，松开后提交固定的「照片里有什么」，不会调用录音或 STT。

原始音频/文字录制默认关闭。8 段预先生成的英文合成声音共约 52.56 秒，来自本地 Flite `slt`，不是 Google 语音、真人声音或中文发音验收；中文翻译与完整英文句子按现有语音 cue 显示，非逐字对齐。音频只经既有 Actor、有效许可、认证音频流和唯一取消安全播放队列进入页面。

12:56 历史归档存在图片未就绪就记录呈现回执的问题。当前源码已加入可取消的图片就绪等待、最新许可复核与失败重试修复，并通过独立软件层复验；旧归档保持原样并附已知问题说明。前端还会等待已有呈现回执同步后再提交下一轮，Stop 不等待网络。服务端也已加入缺失回执前缀的拒绝与同请求重试控制，独立11个场景和1843组合软件发布检查已通过。当前未验证浏览器实际绘制或用户看见。见[当前状态](docs/mission/CURRENT-ACCEPTANCE.md)。

按自己的节奏走一遍约 3–5 分钟的指引（包含观察、重复与停止，不是已录制的验收时长）：

1. 「你好」→「不要拍我」：观察好奇、微笑与相机放低。
2. 「看照片」：等语音与原创海岸/灯塔插画出现。
3. 「讲讲旅途」：讲话中点「停止回应」。声音、字幕不继续，已经看到的插画保留。
4. 按住「演练输入」，确认画面显示 listening 且没有麦克风请求；松开只发送「照片里有什么」。回应用实际呈现过的插画；新会话未看图就问，会先提示看图。
5. 「听雨」→「暖灯」：看环境和表情变化。用 `/fail` 测失败，再点「你好」恢复；输入目录外文字检查口令提示。

完整口令：`你好`、`不要拍我`、`看照片`、`照片里有什么`、`讲讲旅途`、`听雨`、`暖灯`、`/fail`。前后空格和改写也不会被当作识别成功。Stop、失焦、取消、关闭或更新的文字输入都会使待发送的合成输入失效。

这条路径用于验证受控体验，不证明真实模型、真实语音识别、物理扬声器听感、手机或真人 3–5 分钟互动录屏已经完成。[规格与实测边界](specs/features/DEMO-01-offline-rehearsal/spec.md) · [素材来源](docs/changes/DEMO-02-offline-speech-assets/README.md)

回放固定照片场景（不调用模型）：

```bash
sh scripts/dev --profile replay
# 其他现成 Python 环境同样追加 --python /absolute/path/to/ready/python
```

可以加 `--replay-scenario delayed-photo` 测停止，或 `--replay-scenario failed-tail` 测失败。
这只是固定生成夹具回放，不是自然语言理解或完整会话恢复。语音、账户、真实设备能力不能从本启动检查推出。

配置感知入口仍是 `PYTHONPATH=apps/api/src /path/to/ready/python -m mira`，它会按原 loader 读取根 `.env` 和进程配置；仅在已明确配置、授权和审核的开发流程中手动使用，不属于上述离线演示。live 工厂守卫不因启动工具改变而放宽。

离线 wheel 验证：`/path/to/ready/python tools/verify_package.py`。构建 Python 需要现成的 pip 与 `pyproject.toml` 固定版本的 setuptools、wheel（已列入开发锁文件）；必要时加 `--build-python /path/to/build/python`，运行烟测仍使用调用脚本的解释器。工具在临时副本编译前端、无网络构建／安装 wheel，并从安装目录验证配置、fixture、HTTP 与全部静态资源；不靠 checkout 的 PYTHONPATH 补资源。直接手动构建 wheel 前须先 `npm run build`，漏编译会明确失败。
实测和限制见 [STARTUP-01 验证](docs/verification/startup-01/verification.md)。

## 质量命令

```bash
python tools/check.py --list
python tools/check.py --files apps/api/src/mira/adapters/generation/replay/backend.py --plan
python tools/check.py --lane providers actor --jobs 2  # 精确相关块
python tools/check.py --affected --base <共同Git基点> --jobs 3  # 合并前
python tools/check.py --full --jobs 3      # 集成收口，不是每次修改
python tools/check.py --release --jobs 3   # 再加离线wheel与loopback
python tools/verify_tdd_evidence.py         # 原FND02历史完整性；公开归档不含其所需原日志
python tools/export_contracts.py --check
```

无Git的ZIP用`--files`或`--lane`；默认命令只检查Git工作区，已提交变更请带base。报告在`var/quality/<run>/summary.json`，未选块为not_run，没有测试结果缓存。

环境里同时存在多个 Python 时，用已验证且依赖完整的解释器绝对路径执行质量命令；不要仅凭 `.venv` 目录存在就认为可用。
14:48 已验证源码已完整展开至提交 `45b716d7ae80ce9d55934b81372dd1a7b411caf3`，543个源码文件的 Git blob 与模式逐项匹配，46个历史备份文件保留。其[首个真实远端 CI](https://github.com/Robinfxa/MIRA/actions/runs/37140155063)通过10个离线质量块；该次未跑 package/smoke。其后修复了发布任务缺少 Node/npm 的准备步骤；33410f5手动发布检查通过。1756阶段6ab19a8的推送与手动CI也已通过，手动检查包括package/smoke；结果仍绑定各自提交。更新中的源码必须重新冻结和验证。

## 工作台能验证什么

输入“不要拍我”“看照片”“听雨”进入固定Mock场景；`/fail`注入生成失败。
可查看activity/output/permit版本、有效集合和回执数。停止先在浏览器生效，旧结果不能恢复。
支持新请求、重复请求、会话能力token、范围累加、停止截止范围和迟到回执。

默认模式不会产生真实 ASR/TTS/LLM 请求。原创角色使用已备的高细节PNG，旅行插画是本地SVG，不能说成实时生图。真实语音代码、软件级取消测试和控制台能力标记，也不能代替账户、声卡、麦克风与完整需求验收。

## 目录入口

```text
apps/api/src/mira/
  domain/             纯模型、错误、状态转换
  application/        用例与会话生命周期；ports声明外部能力
  adapters/           Mock/回放、默认关闭的真实服务、私有诊断适配器
  config/             类型与唯一env读取入口
  bootstrap/          工厂、组合根、生命周期装配
  entrypoints/http/   DTO、映射、依赖、路由、app factory
apps/web/src/
  app/                浏览器组合根
  features/session/   transport与交互协调
  features/presentation/  本地许可门、cue身份与原创场景执行器
  features/audio/     唯一播放队列、可取消麦克风采集
  features/diagnostics/  实际录制状态与安全错误文案
  shared/             公开配置、协议验证、generated类型
config/               非秘密默认值与profile
packages/contracts/   自动导出的OpenAPI
requirements/         精确安装版本闭包
scripts/ tools/       启动、安装、合同导出、验证
tests/                unit、integration、architecture、web、browser
docs/                 50h计划、实施ADR、来源快照、交接与验证
```

完整文件树见 `docs/implementation/FILE_TREE.md`。

## 配置与抽象的约束

- `Settings`不可变；默认值→profile→显式dotenv→进程env→测试overrides；未知配置启动失败。
- 业务层不读env、不知道provider名称；仅 `bootstrap/providers.py` 选实现。
- `create_app(settings)`可注入依赖；没有全局容器、import-time连接或反射插件扫描。
- domain标准库限定，application不反向依赖adapters；有自动边界测试。
- 公共DTO单点定义，OpenAPI／TS只导出；新增schema先改owner，再跑drift check。
- live provider 不会因环境字段齐全而自行启用；显式装配仍须通过身份、质量、数据和预算准入，不会偷偷 Mock 或改走付费路线。

## 必读文档

[50小时计划](docs/plans/50-hour-delivery.md) · [实施ADR](docs/implementation/ADR-F001-foundation.md) ·
[配置约定](config/README.md) · [开发范例](docs/implementation/config-and-extension-guide.md) ·
[基础阶段交接（历史）](docs/handoff/FND-03.md) · [原架构/复用 v0.6](docs/reference/architecture-v0.6/MIRA_架构全书_v0.6.md)

## 运行与安全界限

仅loopback＋单worker，内存会话，有限容量；停止与实例隔离是基础子集，不是生产认证系统。
浏览器token只在内存，诊断不输出用户原文/凭据；只服务明确public/dist文件，不服务仓库根。
刷新不恢复旧会话，关闭按钮释放本地session；完整持久化/隐私清除在WP05后续实现。

依赖来源与素材见THIRD_PARTY.md；AI使用与未进行的人工验证见AI_USAGE.md。
已在同一 Linux 环境的新隔离目录验证46个固定 Python 依赖、TypeScript5.8.3和启动；远端固定提交的10块CI也已通过。它们不代表全新操作系统、Windows/macOS、手机或物理音频验收。详见[安装证据与限制](docs/verification/fresh-install/verification.md)。

## 语音交互演进

本候选保留原有按住/松开路径；2026-10-04 17:49用户已要求改为点击启动持续聆听、再次点击停止，静音时仍等待下一句话。持续模式正在独立实现，不能把现有PTT改名当作已经完成。后续版本须显示有限时长与调用次数、提供逐段临时转写，并验证全局Stop、关闭、权限撤销和旧结果抑制。未确认的转写不会自动触发模型或动作。离线rehearsal仍是单独标记的固定合成输入，不会采集麦克风。

## 当前阶段与剩余范围

状态核对：2026-10-04 20:57 UTC。用户12:58明确再延长10小时，当前截止为 **2026-10-04 22:58:44 UTC（多伦多18:58:44）**；22:00开始整合收口，不把截止时间当作全架构完成证明。原始开发起点2026-10-03 08:53:50 UTC保留。

- **可恢复交付：** 最新已核验1845三份源码/美术ZIP与四个恢复文件位于[GitHub恢复分支提交a6de84e](https://github.com/Robinfxa/MIRA/commit/a6de84e3fc64767222bb8a312266be77ec6f71f0)，962个还原文件，源码完整12块通过（2010 pytest＋13 subtests、329 Node、打包与HTTP烟测），七文件远端大小和Git blob逐项匹配。该提交是归档备份，main仍保留用户合并的26b5904，展开应用源码较旧。请使用同一阶段的完整七文件，不能只clone旧展开代码。
- **临时转写：** 按住输入期间，合法识别修订显示在独立的“未发送用户输入”区域；松开/Stop/新输入会清空，只有最终完成包才进入原输入路径。浏览器与服务端分别记录单调时钟计时，未测得新的真实服务延迟；点击持续监听仍在后续实现。
- **1845已发布组合：** 纯本地记忆管理无需Codex登录或API；一次性配对前不读库，本地写入另需明确同意。新增外层实际请求字节限制，防止缺失或虚假Content-Length绕过32KiB上限。已核官方npm wrapper可解析到同平台固定native程序；官方configWarning/deprecationNotice仅按已核schema、数量和字节边界接收，不能代替配置准入。V3无桌面背景是可选预览，保留原背景和暖灯/雨窗状态；12张角色图未改，浏览器合成效果尚未验收。
- **真实文字：** 固定原生Luna+4次JEV探针6.332秒封口并产生字幕与动作许可；未提交呈现回执。这不是用户可见的连续实机会话。
- **真实语音：** 合成英文STT→原生生成→JEV审核正确进入UNKNOWN，未调用TTS。另一次生产TTS完成3.24秒中文音频，dispatch到首PCM1.273694秒，未播放；该音频的中文STT成功，标点归一化后与固定文本一致。14.318904秒是dispatch到整个识别流消费结束，既不是首字也不是独立final到达计时。详见[精确证据](docs/mission/PROVIDER-EVIDENCE-20261004.md)。
- **实际设备观察：** 用户12:07–12:20在Mac看到了离线人物和整体起伏，反馈动作僵硬、呼吸像全身浮动、背景不融合。目前未验收局部分层眨眼、头发、嘴巴或胸肩绑定；原型不能当作交付效果。
- **正常Mac接入：** 官方native0.159.2的Mac pin已支持；用户metadata仍在RPC信封处受阻，真实原因待统一验收。本候选有安全阶段诊断和官方启动通知兼容，不能据此宣布用户的实际失败已修复。配置声明齐全不代表已调用模型或额度可用。
- **仍缺：** 连续真实文字/语音、真机麦克风和听感、完整3–5分钟互动录屏；自动记忆提取、人格学习、完整故事、动态素材和持久Actor恢复仍未实现。持续监听已进入下一阶段组合验收，移植性仍以公开支持路径和实际设备结果为准；未验收内容不算交付完成。

[重置恢复记录](docs/mission/reset-recovery-20261003.md) · [录制与设备走查](docs/development/DEMO-RECORDING.md) · [1756历史走查](docs/development/DEVICE-ACCEPTANCE.md)

## 实际投入与后续两周计划

本轮记录起点为2026-10-03 08:53:50 UTC；截至2026-10-04 20:57 UTC说明，历时约34小时34分，期间包含并行开发、研究、账户接入、环境重置与恢复。此数为经过的日历时间，不是人力工时，也不把多个并行任务相加。实际人工工时未独立计量。

若继续开发两周，第一周先完成最新PDF必需验收：可操作的移动场景、完整连续文字/语音、准确中断、至少三种情绪与两种非说话状态、一个环境变化及对话视觉事件、Pixi资源/降级路径、可复现安装与真实3–5分钟录屏，并以用户设备反馈修复最影响体验的缺陷。第二周在核心验收通过后，按实测延迟与失败率改善语音首包/播放队列、移动端资源和恢复体验，补充有代表性的中英文语义评估与性能证据；随后再评估长期记忆/故事与动态素材的最小增量，范围由验收结果决定，不承诺两周内实现完整架构书。

### 构建输出目录保护

新构建仅清理已带本工具固定标记的输出目录；源码、祖先、符号链接和未标记非空目录会明确拒绝。若旧版留下未标记的 `apps/web/dist`，先检查并将该目录改名保留，或在新的源码目录构建；不要为绕过检查手工伪造标记。正常源码包不携带dist，构建会重新生成。

### 本地会话容量提示

若返回明确的 `429 session_capacity`，界面说明这是本地会话/轮次/录音流容量限制。请先点“结束本次会话”或关闭不用的会话，再刷新重建；连续重发当前输入不会解除该限制。其他429仍保留通用限流提示，不推断具体服务配额，也不自动重试。未知server正文不会显示到界面。

### 平台与依赖边界

[本轮运行依赖审查与限制](docs/development/RUNTIME-SECURITY-NOTES.md)

本轮安装与真实socket证据来自Linux；用户Mac仍需亲自验收。Windows尚未验证，锁定Starlette0.50.0的[Windows UNC StaticFiles公告](https://github.com/Kludex/starlette/security/advisories/GHSA-wqp7-x3pw-xc5r)涉及该平台的静态文件路径，不能把Linux结果当作Windows安全证明。当前不为未选平台跨栈升级；不要在Windows启用本开发服务器。可选ChatGPT登录helper已固定PyJWT2.15.1，精确版本与artifact来源见同包锁文件及provenance；全部原权限和RS256-only边界不变。
