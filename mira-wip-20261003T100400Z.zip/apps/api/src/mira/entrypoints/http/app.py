"""Application factory; imports neither open sockets nor load configuration."""
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from pathlib import Path
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.openapi.utils import get_openapi
from fastapi.staticfiles import StaticFiles
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from mira.application.ports.media import SpeechRecognitionBackend, SpeechSynthesisBackend
from mira.bootstrap.container import build_container
from mira.bootstrap.providers import Providers
from mira.config.loader import load_settings, project_root
from mira.config.settings import Settings
from mira.domain.errors import DomainError
from mira.entrypoints.http.routes import router
from mira.entrypoints.http.media_routes import router as media_router
from mira.entrypoints.http.schemas import MEDIA_WIRE_MODELS


def create_app(settings: Settings | None = None, *, providers: Providers | None = None,
               web_root: Path | None = None,
               speech_synthesis: SpeechSynthesisBackend | None = None,
               speech_recognition: SpeechRecognitionBackend | None = None,
               media_shutdown: Callable[[], Awaitable[None]] | None = None) -> FastAPI:
    configured = settings if settings is not None else load_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        container = build_container(configured, providers=providers,
                                    speech_synthesis=speech_synthesis,
                                    speech_recognition=speech_recognition, media_shutdown=media_shutdown)
        app.state.container = container
        try:
            yield
        finally:
            await container.close()

    app = FastAPI(title="MIRA Foundation", version="0.1.0", lifespan=lifespan)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "testserver"])
    app.add_middleware(CORSMiddleware, allow_origins=list(configured.http.allowed_origins),
                       allow_methods=["GET", "POST", "DELETE"],
                       allow_headers=["Content-Type", "X-Mira-Session-Token"])

    @app.middleware("http")
    async def local_boundary(request: Request, call_next):
        request.state.request_id = str(uuid4())
        if (origin := request.headers.get("origin")) and origin not in configured.http.allowed_origins:
            return JSONResponse({"code": "origin_denied", "message": "Origin is not allowed.",
                                 "request_id": request.state.request_id}, status_code=403)
        # Small JSON control-plane requests only. Media uploads need a dedicated later endpoint.
        try:
            size = int(request.headers.get("content-length", "0"))
        except ValueError:
            size = 1_000_000
        if size < 0 or size > 32768 or request.headers.get("transfer-encoding"):
            return JSONResponse({"code": "body_limit", "message": "Control request is too large.",
                                 "request_id": request.state.request_id}, status_code=413)
        response = await call_next(request)
        response.headers["X-Request-ID"] = request.state.request_id
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    @app.exception_handler(DomainError)
    async def domain_error(request: Request, error: DomainError) -> JSONResponse:
        status = 404 if error.code == "session_not_found" else (
            503 if error.code in {"speech_unavailable", "microphone_unavailable"} else
            429 if error.code in {"session_capacity", "busy"} else 409
        )
        return JSONResponse({"code": error.code, "message": str(error),
                             "request_id": request.state.request_id}, status_code=status)

    @app.exception_handler(RequestValidationError)
    async def invalid_input(request: Request, error: RequestValidationError) -> JSONResponse:
        # No reflected raw input, credentials, or complete validation error bodies.
        return JSONResponse({"code": "invalid_request", "message": "Request does not match the contract.",
                             "request_id": request.state.request_id}, status_code=422)

    app.include_router(router)
    app.include_router(media_router)

    def public_openapi():
        if app.openapi_schema is None:
            schema = get_openapi(title=app.title, version=app.version, routes=app.routes)
            components = schema.setdefault("components", {}).setdefault("schemas", {})
            for model in MEDIA_WIRE_MODELS:
                shape = model.model_json_schema(ref_template="#/components/schemas/{model}")
                components.update(shape.pop("$defs", {}))
                components[model.__name__] = shape
            app.openapi_schema = schema
        return app.openapi_schema

    app.openapi = public_openapi
    root = web_root if web_root is not None else project_root() / "apps/web"
    if (root / "index.html").is_file():
        # Serve only public files and compiled JS, never project root or .env.
        app.mount("/assets", StaticFiles(directory=root / "public"), name="assets")
        app.mount("/dist", StaticFiles(directory=root / "dist", check_dir=False), name="dist")
        from fastapi.responses import FileResponse

        @app.get("/", include_in_schema=False)
        async def index() -> FileResponse:
            return FileResponse(root / "index.html")
    return app
