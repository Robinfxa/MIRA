"""Explicitly admitted, category-isolated Codex generation. Disabled by default."""
from dataclasses import dataclass, field
from pathlib import Path
from collections.abc import Mapping


class CodexGenerationError(RuntimeError):
    """Only fixed diagnostic codes cross the adapter boundary."""


@dataclass(frozen=True)
class CodexRuntime:
    executable: Path
    codex_home: Path
    runtime_cwd: Path
    environment: Mapping[str, str] = field(default_factory=dict, repr=False)


@dataclass(frozen=True)
class CodexLimits:
    startup_seconds: float = 10.0
    turn_seconds: float = 60.0
    shutdown_seconds: float = 1.0
    max_line_bytes: int = 131072
    max_wire_bytes: int = 1048576
    max_output_bytes: int = 16384
    max_prompt_bytes: int = 65536
    max_events: int = 1024
    queue_capacity: int = 128


class CodexAppServerGenerationBackend:
    def __init__(self, *, runtime, admitted=False, request_limit=0, limits=None,
                 transport_factory=None):
        self.runtime = runtime

    async def generate(self, context):
        raise CodexGenerationError("codex_not_implemented")
        yield  # Complete-candidate asynchronous port; behavior deliberately absent for RED.
