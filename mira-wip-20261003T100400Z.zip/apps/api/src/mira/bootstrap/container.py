"""Composition root. No service locator, dynamic plugin loading, or global singleton."""
from dataclasses import dataclass
from collections.abc import Awaitable, Callable

from mira.adapters.journal.memory import MemoryEventJournal
from mira.application.ports.journal import EventJournal
from mira.application.ports.media import SpeechRecognitionBackend, SpeechSynthesisBackend
from mira.application.session_actor import RuntimeLimits, SessionActor
from mira.application.sessions import SessionRegistry
from mira.bootstrap.providers import Providers, create_providers
from mira.config.settings import Settings


@dataclass(frozen=True, slots=True)
class Container:
    settings: Settings
    sessions: SessionRegistry
    journal: EventJournal
    speech_enabled: bool = False
    microphone_enabled: bool = False
    generation_mode: str = "mock"
    media_shutdown: Callable[[], Awaitable[None]] | None = None

    async def close(self) -> None:
        try:
            await self.sessions.close()
        finally:
            if self.media_shutdown is not None:
                await self.media_shutdown()


def build_container(settings: Settings, *, providers: Providers | None = None,
                    speech_synthesis: SpeechSynthesisBackend | None = None,
                    speech_recognition: SpeechRecognitionBackend | None = None,
                    media_shutdown: Callable[[], Awaitable[None]] | None = None) -> Container:
    selected = providers or create_providers(settings.providers)
    journal = MemoryEventJournal(settings.runtime.journal_capacity)
    limits = RuntimeLimits(settings.runtime.timeout_seconds, settings.runtime.max_turns,
                           settings.runtime.max_effects)
    sessions = SessionRegistry(
        lambda state: SessionActor(state, selected.generation, selected.review, journal, limits,
                                   speech_synthesis=speech_synthesis,
                                   speech_recognition=speech_recognition),
        journal, settings.runtime.max_sessions,
    )
    return Container(settings, sessions, journal, speech_synthesis is not None,
                     speech_recognition is not None,
                     "injected" if providers is not None else settings.providers.generation, media_shutdown)
