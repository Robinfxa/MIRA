"""One state writer per session. Provider waits never hold the transition lock.

This is a small application coordinator, not a general actor/FSM framework.
All transitions are synchronous while the lock is held. The in-memory journal
is deliberately nonblocking; durable state/outbox is a separate WP05 migration.
"""
import asyncio
from dataclasses import dataclass, replace
from datetime import UTC, datetime

from mira.application.compiler import compile_range
from mira.application.media_runtime import MediaOperation, MicrophoneBuffer, speech_packets
from mira.application.ports.media import SpeechRecognitionBackend, SpeechSynthesisBackend
from mira.application.contracts import AuditEvent, GenerationContext, ReviewVerdict
from mira.application.ports.generation import GenerationBackend
from mira.application.ports.journal import EventJournal
from mira.application.ports.review import ReviewBackend
from mira.domain import transitions
from mira.domain.errors import DomainError
from mira.domain.models import AudioProgress, AudioStatus, Effect, EffectKind, Receipt, SessionState


@dataclass(frozen=True, slots=True)
class RuntimeLimits:
    timeout_seconds: float
    max_turns: int
    max_effects: int


class SessionActor:
    def __init__(self, state: SessionState, generation: GenerationBackend,
                 review: ReviewBackend, journal: EventJournal, limits: RuntimeLimits, *,
                 speech_synthesis: SpeechSynthesisBackend | None = None,
                 speech_recognition: SpeechRecognitionBackend | None = None) -> None:
        self._state = state
        self._generation = generation
        self._review = review
        self._journal = journal
        self._limits = limits
        self._lock = asyncio.Lock()
        self._tasks: set[asyncio.Task[None]] = set()
        self._request_fingerprints: dict[str, tuple[int, int, str]] = {}
        self._closed = False
        self._speech_synthesis = speech_synthesis
        self._speech_recognition = speech_recognition
        self._media_operations: set[MediaOperation] = set()
        self._speech_started: set[str] = set()
        self._microphone_started: set[str] = set()

    def _commit(self, state: SessionState, kind: str) -> None:
        if state is self._state:
            return
        self._state = state
        self._journal.append(AuditEvent(
            sequence=state.revision, session_id=state.session_id, kind=kind,
            state_revision=state.revision, output_epoch=state.output_epoch,
            occurred_at=datetime.now(UTC).isoformat(),
        ))

    async def snapshot(self) -> SessionState:
        async with self._lock:
            return self._state

    def _cancel_tasks(self) -> None:
        for task in tuple(self._tasks):
            task.cancel()
        self._cancel_media()

    def _cancel_media(self) -> None:
        for operation in tuple(self._media_operations):
            operation.cancel()

    async def submit(self, *, request_id: str, activity_seq: int,
                     cutoff: int, text: str) -> SessionState:
        async with self._lock:
            if self._closed:
                raise DomainError("session_closed", "Session has closed.")
            fingerprint = (activity_seq, cutoff, text)
            previous = self._request_fingerprints.get(request_id)
            if previous is not None:
                if previous != fingerprint:
                    raise DomainError("request_conflict", "Request ID was reused with different data.")
                return self._state
            if len(self._request_fingerprints) >= self._limits.max_turns:
                raise DomainError("session_capacity", "Foundation turn budget reached; create a new session.")
            # Cancellation-resistant providers are not allowed to create an unbounded task set.
            if len(self._tasks) >= 4:
                raise DomainError("busy", "Previous work is still terminating.")
            state = transitions.begin_input(self._state, activity_seq=activity_seq,
                                             cutoff=cutoff, request_id=request_id, text=text)
            self._cancel_tasks()
            self._request_fingerprints[request_id] = fingerprint
            self._commit(state, "input_committed")
            context = GenerationContext(text, state.user_inputs, state.presented_effects,
                                        state.output_epoch, audio_progress=state.audio_progress)
            task = asyncio.create_task(self._generate(context, activity_seq))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
            return state

    async def stop(self, *, activity_seq: int, cutoff: int) -> SessionState:
        async with self._lock:
            state = transitions.stop(self._state, activity_seq=activity_seq, cutoff=cutoff)
            if state is not self._state:
                self._cancel_tasks()
                self._commit(state, "stopped")
            return self._state

    async def receipt(self, receipt: Receipt) -> SessionState:
        async with self._lock:
            self._commit(transitions.record_receipt(self._state, receipt), "receipt_recorded")
            return self._state

    async def audio_progress(self, progress: AudioProgress) -> SessionState:
        async with self._lock:
            if self._closed:
                raise DomainError("session_closed", "Session has closed.")
            self._commit(transitions.record_audio_progress(self._state, progress),
                         "audio_progress_recorded")
            return self._state

    def _media_capacity(self) -> None:
        if self._closed:
            raise DomainError("session_closed", "Session has closed.")
        if len(self._media_operations) >= 4:
            raise DomainError("busy", "Previous media work is still terminating.")

    def _track_media(self, operation: MediaOperation) -> MediaOperation:
        self._media_operations.add(operation)
        return operation

    async def close_media(self, operation: MediaOperation) -> None:
        try:
            await operation.close()
        finally:
            if operation.task.done():
                self._media_operations.discard(operation)
            else:
                operation.task.add_done_callback(lambda task: self._media_operations.discard(operation))

    async def open_speech(self, *, effect_id: str, digest: str, output_epoch: int,
                          activity_seq: int) -> MediaOperation:
        async with self._lock:
            self._media_capacity()
            effect = next((e for e in self._state.active_grants if e.id == effect_id), None)
            if effect is None or effect.kind != EffectKind.SPEECH:
                raise DomainError("speech_not_granted", "There is no current speech grant.")
            if (effect.digest, effect.output_epoch, effect.activity_seq) != (
                    digest, output_epoch, activity_seq):
                raise DomainError("receipt_mismatch", "Speech origin differs from the current grant.")
            if self._speech_synthesis is None:
                raise DomainError("speech_unavailable", "No speech synthesis provider is injected.")
            if effect.id in self._speech_started or any(
                    p.effect_id == effect.id and p.status != AudioStatus.RENDERED
                    for p in self._state.audio_progress):
                raise DomainError("speech_consumed", "This speech grant has already been consumed.")
            if any(op.effect is not None and not op.cancelled.is_set() for op in self._media_operations):
                raise DomainError("busy", "The session voice slot is already in use.")
            self._speech_started.add(effect.id)
            backend = self._speech_synthesis
            return self._track_media(MediaOperation(lambda: speech_packets(backend, effect),
                activity_seq=activity_seq, input_epoch=self._state.input_epoch,
                output_epoch=output_epoch, effect=effect))

    async def open_microphone(self, *, stream_id: str, activity_seq: int,
                              input_epoch: int, buffer: MicrophoneBuffer) -> MediaOperation:
        async with self._lock:
            self._media_capacity()
            if (activity_seq, input_epoch) != (self._state.activity_seq, self._state.input_epoch):
                raise DomainError("stale_activity", "Microphone origin is no longer current.")
            if self._speech_recognition is None:
                raise DomainError("microphone_unavailable", "No speech recognition provider is injected.")
            if stream_id in self._microphone_started:
                raise DomainError("stream_consumed", "Microphone stream identity has already been used.")
            if len(self._microphone_started) >= self._limits.max_turns:
                raise DomainError("session_capacity", "Microphone stream budget reached.")
            if any(op.effect is None and not op.cancelled.is_set() for op in self._media_operations):
                raise DomainError("busy", "A microphone stream is already open.")
            self._microphone_started.add(stream_id)
            backend = self._speech_recognition
            return self._track_media(MediaOperation(lambda: backend.transcribe(buffer.packets()),
                activity_seq=activity_seq, input_epoch=input_epoch,
                output_epoch=self._state.output_epoch))

    async def validate_media(self, operation: MediaOperation) -> None:
        async with self._lock:
            state = self._state
            if (self._closed or operation.cancelled.is_set()
                    or (operation.activity_seq, operation.input_epoch, operation.output_epoch)
                    != (state.activity_seq, state.input_epoch, state.output_epoch)
                    or (operation.effect is not None and operation.effect not in state.active_grants)):
                operation.cancel()
                raise DomainError("media_cancelled", "Media authority has been revoked.")

    async def media_failed(self, operation: MediaOperation, code: str) -> None:
        async with self._lock:
            if operation.effect is not None and operation.output_epoch == self._state.output_epoch:
                self._commit(transitions.fail(self._state, output_epoch=operation.output_epoch,
                                              code=code), "media_failed")
                self._cancel_media()

    async def _generate(self, context: GenerationContext, activity_seq: int) -> None:
        try:
            async with asyncio.timeout(self._limits.timeout_seconds):
                count = 0
                async for candidate in self._generation.generate(context):
                    async with self._lock:
                        if self._closed or self._state.output_epoch != context.output_epoch:
                            return
                        review_context = replace(context, accepted_prefix=self._state.active_grants,
                                                 presented_effects=self._state.presented_effects,
                                                 audio_progress=self._state.audio_progress)
                    observation = await self._review.review(review_context, candidate)
                    if observation.verdict != ReviewVerdict.ALLOW:
                        raise DomainError("review_not_allowed", "Candidate did not pass review.")
                    effects = compile_range(candidate, epoch=context.output_epoch, activity=activity_seq)
                    async with self._lock:
                        if self._closed or self._state.output_epoch != context.output_epoch:
                            return
                        if len(self._state.issued_effects) + len(effects) > self._limits.max_effects:
                            raise DomainError("effect_capacity", "Foundation effect budget reached.")
                        self._commit(transitions.accept_range(
                            self._state, output_epoch=context.output_epoch, effects=effects
                        ), "range_accepted")
                        count += 1
                if not count:
                    raise DomainError("empty_generation", "Provider returned no complete range.")
                async with self._lock:
                    self._commit(transitions.seal(self._state, output_epoch=context.output_epoch),
                                 "plan_sealed")
        except asyncio.CancelledError:
            # Local stop owns invalidation. Cancellation is not natural PlanEnd.
            raise
        except Exception as error:
            code = error.code if isinstance(error, DomainError) else (
                "generation_timeout" if isinstance(error, TimeoutError) else "generation_failed"
            )
            async with self._lock:
                failed = transitions.fail(self._state, output_epoch=context.output_epoch, code=code)
                if failed is not self._state:
                    self._commit(failed, "generation_failed")
                    self._cancel_media()

    async def close(self) -> None:
        async with self._lock:
            self._closed = True
            self._cancel_tasks()
            tasks = tuple(self._tasks)
            media = tuple(self._media_operations)
        if tasks:
            await asyncio.wait(tasks, timeout=1.0)
        if media:
            await asyncio.gather(*(operation.close() for operation in media))
