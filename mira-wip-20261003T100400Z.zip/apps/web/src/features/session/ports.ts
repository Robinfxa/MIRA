import type { AudioProgressRequest, CreateSessionResponse, EffectView, InputRequest, ReceiptRequest, SessionView, StopRequest } from '../../shared/generated/contracts.js';
import type { CapturedAudio } from '../audio/types.js';

export type { VoiceCapabilities } from '../../shared/generated/contracts.js';
import type { VoiceCapabilities } from '../../shared/generated/contracts.js';
export interface MicrophoneOrigin {
  readonly stream_id: string;
  readonly activity_seq: number;
  readonly input_epoch: number;
}
export interface FinalTranscript {
  readonly text: string;
  readonly had_final: boolean;
}
export interface MicrophoneStream {
  readonly ready: Promise<void>;
  readonly completion: Promise<FinalTranscript>;
  send(chunk: CapturedAudio): void;
  finish(): Promise<FinalTranscript>;
  cancel(): void;
}
/** Session use cases depend on ports, not fetch or a provider SDK. */
export interface SessionTransport {
  create(clientInstanceId: string, signal?: AbortSignal): Promise<CreateSessionResponse>;
  capabilities(signal?: AbortSignal): Promise<VoiceCapabilities>;
  snapshot(signal?: AbortSignal): Promise<SessionView>;
  input(request: InputRequest, signal?: AbortSignal): Promise<SessionView>;
  stop(request: StopRequest, signal?: AbortSignal): Promise<SessionView>;
  receipt(request: ReceiptRequest): Promise<SessionView>;
  audioProgress(request: AudioProgressRequest): Promise<SessionView>;
  speech(effect: EffectView, signal: AbortSignal, onPcm: (pcm: Int16Array) => void | Promise<void>): Promise<void>;
  microphone(origin: MicrophoneOrigin, signal: AbortSignal): MicrophoneStream;
  close(): Promise<void>;
}
