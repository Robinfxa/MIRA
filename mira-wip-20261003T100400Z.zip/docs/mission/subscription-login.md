# MIRA subscription login: bounded helper

Owner: subscription-auth worker. Scope: standalone control-plane helper only; the existing
application loader, provider factory, review contract and live guard are unchanged.
Consumers: parent-controlled sign-in and a future explicitly configured Responses adapter.
Test block: env/tooling, unique owner to be registered by the integration director.
Resources: synthetic unit tests, including a short-lived ephemeral loopback HTTP listener;
actual OAuth and inference are separate opt-in checks. No provider network is used by tests.

## Observable requirements before implementation

- Given a new installation, prepare stable host identity and an app-specific authorization URL
  with fresh PKCE S256, state and nonce; first registration uses dynamic_agent_client and MIRA.
- Given a saved registration, reuse its issued client ID; do not silently replace its identity.
- Given a callback with invalid/duplicated state, denied consent or different client ID, fail
  closed without exchanging a code. Never print callback query strings, codes or tokens.
- Given returned tokens, validate the signed ID token, issuer, audience, expiry and nonce,
  then require the granted plan-usage scope before declaring plan usage connected.
- Given no explicit storage approval, a prepared listener must not initiate OAuth, exchange
  codes or write credentials. Bind loopback only; reject cross-origin start and rebinding Host.
- Given approved storage, keep it outside the checkout with owner-only directories/files,
  atomic writes and symlink refusal; never read an existing Codex authentication cache.

## Deployment constraints

Official plan usage supports eligible Responses requests for open-source/local apps, including
the documented self-hosted VM scenario. This is not approval to offer a paid/hosted service.
MIRA's managed-cloud deployment eligibility and selected account access remain unverified.
Public API/auth connectivity was checked without credentials. The cloud-browser loopback
probe was blocked with ERR_BLOCKED_BY_CLIENT; a working callback browser path is not verified.

## Official sources (checked 2026-10-03)

- https://developers.openai.com/siwc/token-sharing-open-source/sign-in
- https://developers.openai.com/siwc/token-sharing-open-source/profiles-and-sessions
- https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference
- https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations
- https://developers.openai.com/siwc/token-sharing-open-source/self-hosted-vms
- https://developers.openai.com/cookbook/articles/sign-in-with-chatgpt

This is a narrow implementation of the documented protocol, not a copy of the separately
licensed Node DevKit. No API key or partner client secret is required for dynamic registration.

## Invocation and status

Preparation only (no login, network request, host file or credential write on startup):

```sh
python tools/mira_chatgpt_login.py --state-dir /ABSOLUTE/PRIVATE/MIRA/DIRECTORY --port 1455
```

The directory must be outside the checkout. Existing directories must be user-owned mode 0700;
existing credential files must be user-owned mode 0600. Symlink paths are rejected. Preparation
mode intentionally has no sign-in button. Only after the user approves the exact storage
destination and connection purpose may the operator add `--allow-credential-storage`.
The user must then click Continue with ChatGPT and approve on OpenAI's official page.
No caller should log a redirect URL, callback query, token response or credential record.

The CLI prints only the local landing-page URL. `/health` and `/status` contain no secrets.
`OAuthOwner` is separated from the HTTP helper for later integration. Its completion result
contains only booleans, and never claims that inference is verified. This bounded helper does
not implement token renewal, model discovery or application inference yet. Do not treat it
as a production provider or use a legacy Codex token as its session.

Synthetic tests use standard-library unittest. Signed-ID-token tests use existing PyJWT 2.13.0
and cryptography 50.0.0 in the primary Python runtime; they are not yet added to project locks.

```sh
python -m unittest tests.unit.test_mira_auth -v
```

Initial five protocol tests were run against the incomplete implementation and produced three
behavior errors, then passed against the implementation. Expanded storage/JWT/listener tests
were added afterwards and are verification, not retroactive RED evidence. All use disposable
synthetic identities and files. Live sign-in, browser callback, refresh and inference remain
unverified. The integration director owns shared quality registration and aggregate checks.

Final focused result on 2026-10-03: 18 tests passed under the primary Python runtime; compileall
and CLI help passed. A listener-test harness context-manager mistake was fixed before that run;
that harness failure is not claimed as product-behavior RED. Ruff and aggregate checks were not
run here because project test/lint dependencies were unavailable in this worker's interpreter.
The current filesystem-permission implementation targets Unix; Windows has not been validated.

## Separate personal Codex development login

The user also requested genuine Codex-managed device login for private development/testing.
That flow is separately documented at https://learn.chatgpt.com/docs/auth and retains its own
private Codex home outside this checkout. It is not this helper's OAuth session and must never
be copied into this helper or a custom API adapter. A browser authorization acknowledgement
is not proof that the CLI token exchange completed. Do not start inference until the official
CLI confirms authentication; model access additionally requires a completed request.

### Installed app-server isolation investigation

Installed CLI: 0.159.2. Official tag `rust-v0.159.2` resolves to source commit
`ff6aec96948b70d94983af2641a6b67c94faeff5`. Its generated ThreadStartParams schema documents
`environments: []` as disabling environment access. In the pinned source,
`codex-rs/core/src/tools/spec_plan.rs` gates shell/exec/write_stdin, apply_patch and view_image
on the presence of an environment (lines 1083, 1269 and 1283).

A fresh, unauthenticated inspection process accepted these process-only restrictions:
`--disable apps --disable plugins --disable browser_use --disable computer_use
--disable multi_agent --disable shell_tool --disable image_generation --disable tool_suggest
-c web_search="disabled"`. Its config/read reported zero MCP servers and the requested disabled
feature values. thread/start accepted `ephemeral: true`, `environments: []`, `dynamicTools: []`
and `selectedCapabilityRoots: []`. The process was terminated without starting a model turn.

This verifies category-isolation configuration, not an empty model-request tool inventory.
Some model-advertised utility tools can remain. No inventory/filter RPC was found in this
version's generated protocol. Keep product use gated until the required isolation is proven;
do not equate read-only sandbox, approval policy, fresh threads or account login with no tools.

### Native login transport recovery candidate

The initial browser approval did not complete CLI login: the native token exchange hit a
connection timeout and login status remained signed out. All existing proxy and trust-bundle
environment settings were preserved. No authentication data was copied or reconstructed.
Unauthenticated synthetic form POSTs reached the token endpoint, including in one process
before and after a yield, but this does not verify native Codex transport.

The pinned implementation applies a special 10-second connect timeout only when the proxy
policy is ReqwestDefault with fallback enabled. Starting with the supported per-process
feature `respect_system_proxy=true` selects RespectSystemProxy and avoids that particular
timeout path. The installed CLI accepts the option. A second user-completed device authorization
with this process-only option succeeded on 2026-10-03; the official CLI separately confirmed
ChatGPT login status. Existing proxy and CA settings were unchanged. This observes successful
recovery, but does not isolate which internal transport detail caused the first failure.
Authentication success does not establish model inference, quota or production eligibility.

```sh
CODEX_HOME="$APPROVED_PRIVATE_CODEX_HOME" codex -c features.respect_system_proxy=true login --device-auth
```

Retain the environment's existing proxy and CA settings; never disable TLS verification,
change proxy destinations, weaken network policy, or copy/extract legacy tokens into MIRA.

The first bounded synthetic gpt-6-luna turn selected that exact model and started, but did not
establish completed inference. Its reader used buffered text with select and a short per-message
timeout, so a corrected queue-based diagnostic retry was authorized. No real character prompt
or user content is admitted based on the login result alone. At the time of this update,
inference verification remains pending.
