# MIRA source checkpoint

WIP recovery checkpoint. Standalone modules include their individual verification reports, but the combined snapshot is NOT green. Backend scoped run: 167/168 passed, replay health-label compatibility fix queued. Codex generation adapter: deliberate RED scaffold, 33 failed/6 passed. Frontend focused checks passed before capture, additional hardening pending. Live providers, device audio, full integration, and remote CI are not claimed passed.

Source import commit: `ebb578dde665c9c7269e4a64b508182680b2fa66`.

Captured at 2026-10-03 10:04 UTC. The working-tree checkpoint was captured under a coordinated write freeze and all source hashes matched before/after capture. Files in this public projection are byte-identical to the captured source unless listed as publication metadata.

Excluded from capture: private `.env` files, credentials/auth stores, runtime state, dependency folders, Git internals, and caches. Blank public environment templates are included. The public projection additionally omits raw source PDFs, historical document copies/screenshots, raw logs, and files containing machine-specific private paths. See `publication-exclusions.json`.

No deployment or merge is implied. No paid fallback or live-provider verification is claimed. Future stages should be uploaded as non-force, separately verifiable commits.
