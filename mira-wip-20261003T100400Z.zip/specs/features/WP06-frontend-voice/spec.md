# WP06 frontend voice integration

Base: ebb578dde665c9c7269e4a64b508182680b2fa66. Owner: frontend voice integrator. Test block: web (registration by integration owner), consumers: HTTP/generated protocol, scene executor, browser audio. Resource: synthetic fetch/WebSocket/audio primitives only, unique TypeScript output directories. No device permission automation, live provider, loopback, paid API, generated contract edits or full suite.

## Behaviors

- WP06-001: Given a consumed speech grant, current authorization remains true until revoked; speech never creates a DOM receipt. Every accepted software audio fact obtains its own shared monotonic presentation sequence.
- WP06-002: Given active sound, text/PTT/stop/error/revoke/close blocks and stops locally before network work. Terminal facts belong within the next cutoff, including late delivery; stale completions cannot restart.
- WP06-003: Given an authenticated bounded speech stream, validate origin, sequence, PCM16LE mono 24 kHz, explicit completion and errors. Truncated, malformed and overfull streams fail closed.
- WP06-004: Given a user microphone gesture, capture once, bounded-queue PCM16LE mono 16 kHz, authenticate a WebSocket in its first packet, and finish only after queued PCM is accepted. Only a reliable nonempty final transcript with no newer local activity creates input.
- WP06-005: Given close during pending connect/permission/fetch/socket/poll, release and invalidate all resources. Late results keep the controller closed.
- WP06-006: Given real playback/capture events, show speaking/listening. Backend idle alone cannot stop active speaking. Stop retains visual scene/photo; failures preserve text fallback and honest mode labels.

## Qualification

All automated evidence is deterministic offline software behavior, never acoustic output, word alignment, hardware tail latency, user understanding or live provider acceptance. Actual device/browser/provider qualification remains not run.
