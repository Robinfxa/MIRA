# Known gaps and historical defect closure: 20261003T1256Z

## Current stage

The immutable 12:56 candidate and this privacy-filtered, extracted source projection both passed the local automated release selection: **1,110 Python tests, 166 Node tests, 12 lanes**, including offline wheel build/install and a real local loopback HTTP smoke. This is a recoverable development checkpoint, not completed product acceptance.

## Earlier defects closed in this candidate

The 11:04 checkpoint and its known-issues note remain immutable historical evidence. Their defects are not described as still open in the new source:

- IA-01: structured/nested credential-shaped text filtering corrected. Independent final candidate privacy confirmation is in `docs/mission/integrated-audit-1104.md`, section “IA-01 最终修复哈希独立确认”; production privacy hash e02331f91faf7b04e6b75a986121e1fe80794b3af7bbb9617eec7b4df5678d7b. Default raw recording remains OFF; no new recording consent is implied.
- IA-02: future subtitle/visual cues now wait for the corresponding audio start. IA-04: safe recovery wording survives the actual entrypoint; prototype-property error-code lookup was also corrected. See `docs/mission/cue-independent-verification.md` and `docs/verification/wp07-cue-causality/verification.md`.
- IA-03: cumulative audio facts are projected per immutable effect into model context without discarding the authoritative ledger. See `docs/verification/wp08-audio-context/README.md` and the IA-03 follow-up in the historical audit.
- IA-05: non-ASCII session tokens are rejected safely before constant-time comparison. See `docs/verification/wp08-session-boundary/README.md` and the IA-05 follow-up in the historical audit.
- Deterministic microphone teardown: synchronous invalidation and raw queue clearing precede cancellable teardown; owned tasks remain bounded/accounted until completion. See `specs/features/WP03-microphone-teardown/spec.md` and its traceability tests. The release rerun includes these tests.

Some historical reports still say a later full/release was pending at their writing time. The two release receipts in this checkpoint establish the newer automated result without rewriting those historical findings.

## Earlier completed work retained

- Async diagnostic locators: actual application failure correlation reaches the snapshot and safe UI output; TTS/STT/playback error paths retain validated identifiers, and Stop/new input clear stale errors. Ordinary sanitized events and visible IDs share the same hash convention. See `docs/verification/obs-02-async-error-locators/verification.md` and `specs/features/OBS-02-async-error-locators/traceability.json`. This closes the 11:58 checkpoint's dedicated asynchronous-locator gap for the tested software paths.
- Evaluation accounting root: immutable source/corpus checks remain bound to the frozen root while the approved accounting/config root explicitly supplies the shared existing budget ledger and lock. See `docs/changes/WP01-jev-evaluation-runner/verification.md` and `usage.md`. Offline tests do not authorize or establish a live evaluation, budget reset, threshold change or calibration admission.
- Audio interruption cause: an interruption report no longer invents USER_STOP. Playback records UNKNOWN; downstream cancellation records PERMIT_REVOKED; explicit Stop/new-input preserve USER_STOP/SUPERSEDED. See `docs/verification/obs-03-audio-interruption-causes/verification.md` and its feature spec.

The earlier 12:36 checkpoint separately records its own dependency-link correction and successful rerun. Those receipts are preserved under their original stage identity and are not presented as a result for this newer rehearsal candidate.

## Rehearsal work included in this 12:56 candidate

- Explicit `rehearsal` profile: an authored finite command catalog and exact fixture reviewer through existing Actor, permission, cue/caption and cancellation-safe audio paths. Default mock behavior and live-provider admission are unchanged.
- Eight original English synthetic clips, 52.56 seconds total, included as 8 PCM plus 8 WAV files. Exact asset/caption hashes, PCM/WAV identity, 24 kHz mono PCM16 format, generator hash and provenance are verified. Sources: `apps/api/src/mira/adapters/generation/rehearsal/fixtures/audio/manifest.json`, `tools/generate_rehearsal_audio.py`, and `docs/changes/DEMO-02-offline-speech-assets/README.md`. These are finite offline fixtures, not live TTS, Chinese speech or human recordings.
- Labeled synthetic listening control requests no microphone permission and performs no recording or ASR; release/cancel/Stop/new-input use existing causality.
- Additional independent diagnostic tests and metadata identity alignment are included in the frozen source. Installed-wheel verification covers all eight rehearsal clips and 32 exact config/web resources.

The original frozen source and the extracted public projection both passed the current automated release. Independent whole-path and media-readiness audits were still in progress when this checkpoint was prepared. An attempted independent static render was blocked by OS socket restrictions; no browser pixels were obtained. None of these pending/blocked checks is counted as a pass.

This checkpoint excludes source and documents created after the 12:56 freeze. Later audit findings, if any, must be attached separately rather than attributed to unrun frozen-source acceptance.

## Still not established

- Real browser pixels, real mobile devices, microphone/speaker behavior, acoustic stop latency, actual intelligibility, or word-level synchronization.
- Continuous 3–5 minute interaction and a matching acceptance recording; the original complete product/architecture acceptance.
- Live-provider account/model/permission/budget readiness or live application admission. This checkpoint contains no credentials, OAuth state or private configuration.
- Production Chinese semantic-review calibration. Frozen evaluation cases and their original v1 integrity archive are preserved; synthetic expected cases are not measured live quality.
- Guaranteed durable diagnostic delivery/retention: asynchronous failure locators are now implemented and tested, but logging remains best-effort; see the closure below.
- Real media-resource failure/recovery, live network interruptions and real permission-refusal UX.
- Fresh dependency installation, all-platform compatibility, remote CI, deployment or merge success.

## Evidence intentionally excluded

Raw logs, generated test workspaces, private diagnostic/runtime files, authentication setup notes, the user-supplied PDF and duplicate source/build snapshots are not public. The historical `tools/verify_tdd_evidence.py` command requires excluded original FND-02 raw logs and is therefore **not runnable from this public checkpoint**. The current offline release suite is runnable and was rerun successfully.

Relative file links in the current README and setup/handoff documents were checked: 37 checked, 36 present. The sole missing directory is `docs/verification/fnd-02/runs/`, an intentional raw-evidence exclusion. Link anchors, plain code paths and all historical reference links were not exhaustively checked. No required startup/source/test fixture was removed.
