# WP03: Click-start continuous listening lease

Status: bounded backend/session core with an explicit manual-turn control. This does not prove a real browser/device/provider session or acoustic echo cancellation.

## Intent

A deliberate click starts one finite microphone lease and one continuous STT stream. Silence does not stop the lease. Interim revisions and stable finals are provisional display text only; they never become Actor history, memory or a model/provider request by themselves. Google V2 speech-activity events and result offsets are retained for display hints only in this first version. They do not authorize input boundaries, since delayed final pieces can arrive after a VAD END.

The user explicitly chooses “send current utterance.” The client sends the exact currently displayed transcript revision plus a unique commit ID. The backend verifies that revision is still current, requires a nonempty stable-final suffix, and creates one exact one-use binding to the text. The frontend then submits through the existing `SessionController.input()`/`/inputs` path with its current `activity_seq`, presentation cutoff and receipt-prefix barrier. The microphone lease remains open after a manual commit. New interim/final text stays visible until the next manual commit or stop. A late tail is never silently discarded or automatically submitted as a second turn.

Continuous listening lifetime is independent of reply-turn activity/input/output epochs; ordinary PTT keeps existing actor epoch checks. Global Stop, lease Stop, permission loss, disconnect, deletion and app shutdown revoke the active microphone lease. Stop also revokes any commit ID not yet accepted by Actor.submit; exact retries of an input already accepted by the Actor remain idempotent.

## Given/When/Then

### WP03-001 Explicit authenticated lease
  - Given exact configured Origin/Host and a valid session ID, when a client sends first-frame `{type:"start",session_token,lease_id}` with no query string, then the server binds one unique lease to the authenticated session.
  - Given malformed/duplicate JSON, invalid token, invalid Origin/Host, any query parameter or missing continuous backend, when the WebSocket starts, then it is rejected before an STT stream can be dispatched.
  - Given a new lease for a session, when an older lease is active, then the older stream is cancelled and cannot publish transcript revisions afterward.
### WP03-002 Silence remains active
  - Given a ready lease, when the microphone sends silence PCM or no recognized speech arrives, then the WebSocket remains open until explicit stop, disconnect, session teardown or the visible finite cap.
### WP03-003 Transcripts are provisional
  - Given interim or final provider transcript results, when they arrive, then the backend emits monotonic current-pending transcript previews only; no Actor input, generation, memory, or per-word provider call occurs.
  - Given an offset-matched Google `SPEECH_ACTIVITY_END` and stable final result, when both are available, then the server may emit an `endpoint_pending` display hint only; no automatic input is submitted.
  - Given missing offsets, orphan activity END, a late result piece or a stale displayed revision, when a manual commit is requested, then the current preview remains available and the server rejects stale/no-final commits instead of silently losing or duplicating text.
### WP03-004 Manual one-use commit
  - Given the current display revision has stable final text, when the user explicitly sends `{type:"commit",lease_id,commit_id,revision}`, then the server atomically binds that `commit_id` to the exact text, lease, session and next segment sequence and returns `commit_ready`.
  - Given the same commit ID and revision again, when that exact commit result exists, then the same ready snapshot is returned. Reuse with a different revision/body is rejected.
  - Given the standard `/inputs` request contains `listening_utterance_id`, when its commit frame was delivered, then validation reserves that ID for only this exact request ID/text. `Actor.submit` success marks it accepted. Actor rejection leaves a retry reservation only while live; Stop revokes any not-accepted reservation. Exact accepted input retries remain idempotent after Stop.
  - Given a manual commit is accepted while the lease is active, when the stable suffix is cleared from the preview, then the microphone stream stays active, and subsequent transcript tails appear as fresh current-pending text for another explicit manual commit.
### WP03-005 Turn epoch isolation
  - Given a valid listening lease, when a normal Actor reply/new input advances activity/input/output epochs, then the lease remains active. Stop and teardown explicitly close it.
### WP03-006 Finite resource caps and visible end
  - One active lease/session; default lease limit 120 seconds (clamped to profile/provider max), <=1,920,000 PCM16 samples, <=12 manual commits, 2,000 code points of current pending text, <=12,000 bytes/chunk, audio queue <=8 packets, event queue <=32, revisions <=10,000; one provider stream per lease and no retry/rollover.
  - When any duration, sample, queue, output, revision, manual-commit or per-session/application lease-start ceiling is reached, then the server sends a visible stop/rejection and revokes the active microphone.
  - Counts are technical lease starts/reservations, not billed dollars; no live provider/account call was made for tests.

### WP03-007 Shared PTT/continuous STT attempt ceiling
  - Given an explicitly admitted provider bundle, when PTT and continuous listening alternate or start concurrently, then both reserve from the exact same irreversible per-launch STT counter; empty/invalid first audio does not consume an attempt; a valid reservation is never refunded after cancellation or an unknown outcome.
  - Given an application profile declares up to100 STT attempts, when the continuous lease starts, then its finite application lease-start cap is set from that same declaration instead of silently retaining the old probe ceiling8; probe remains capped at8.
- **Evidence:** synthetic wrappers/adapters only, no real billing or live service call.

### WP03-008 Overload and commit-cap terminal events
  - Given a bounded output queue is full, when a revision cannot be enqueued, then previews are discarded and the client still receives a visible `stopped(output_limit)` terminal frame.
  - Given the per-lease manual commit count reaches its cap, when the final allowed snapshot is returned, then it remains submit-capable through history-pending/accepted retry semantics and a visible `stopped(utterance_limit)` follows; no extra automatic user turn is generated.


## Frontend behavioral requirements

See [continuous UI specification](spec-web.md) and traceability-web.json; these Node cases are executed by the web lane, not Python collection.
