# WP03 continuous-listening frontend requirements

Owner: web lane. Synthetic tests do not establish browser, microphone, acoustics or Google acceptance.

### WP03-009 Click-start, silence, and PTT compatibility
  - Given an explicit click on the continuous control, when permission is granted, then continuous capture starts under that user gesture, sends 16kHz silence frames, displays transient text and remains distinct from ordinary PTT/rehearsal behavior.
- **Client cases:** continuous WebSocket/token/audio-silence manual flow; preview remains unsent until explicit commit-ready.

### WP03-010 Explicit revision-bound manual send
  - Given the displayed preview has a new revision or a provider tail arrived after the last commit, when the user clicks send, then the client submits the exact `commit_ready` text once through the ordinary receipt-prefix controller barrier, retains late tails for the next explicit click and never retries an unknown request result.
  - Given the backend returns `stale_revision`, when the click caller receives it, then no automatic retry occurs; the current text remains visible and a new click is required.

### WP03-011 Local Stop, permission and callback fencing
  - Given permission is pending or capture is live, when permission is denied/lost, transport fails, Stop, Close or finite duration occurs, then local capture is released and late transcript/commit events are fenced. New reply/input turn generation leaves the continuous lease open until an explicit Stop.

### WP03-012 Readiness and bounded manual mode
  - Given a server ready frame, when the client parses it, then only declared finite limits and `manual_commit_required:true` are accepted. An unusable provider mode fails closed, the limit is displayed, the client sends one Stop and never rolls into another lease.

### WP03-013 Ordinary input, reply turns and typed fallback
  - Given a successful manual commit, when the frontend sends it through `SessionController.input()` using current activity/cutoff and the receipt-prefix barrier, then a reply turn does not tear down continuous capture. When a typed input is selected instead, capture is stopped first.

## Wire

WebSocket `/api/v1/sessions/{session_id}/continuous-listening`; no query string. First JSON frame `{type:"start",session_token,lease_id}`. Later client frames are `{type:"audio",lease_id,sequence,first_sample,pcm_base64}`, `{type:"commit",lease_id,commit_id,revision}`, or `{type:"stop",lease_id,reason?}`. Server frames are `ready`, `transcript`, `endpoint_pending` (UI hint only), `commit_ready`, `commit_rejected` and terminal `stopped`.

`commit_id` is passed unchanged as `InputRequest.listening_utterance_id`; standard frontend input additionally supplies the current controller `activity_seq` and presentation cutoff. Tokens are sent only in the initial WebSocket frame after Origin/Host validation, never in a URL. Audio is headerless mono PCM16LE at 16 kHz; clients keep sending silence and prefer roughly 100 ms chunks.

## Provider offsets

Google V2 `speech_event_offset` is a duration offset from stream start marking event emission. `StreamingRecognitionResult.result_end_offset` is the end offset of one result, also relative to stream start. The adapter preserves per-result offsets and `SPEECH_ACTIVITY_BEGIN/END` event offsets, and uses integer sample conversion for installed SDK proto-plus `timedelta` values while checking field presence. Offsets need not be equal; endpoint hints require a final inside the same VAD interval with <=3s lag. The server never treats that hint as a final conversation boundary. `END_OF_SINGLE_UTTERANCE` and `voice_activity_timeout` are not used because they close the stream.

Primary sources: [Google V2 StreamingRecognize RPC](https://cloud.google.com/speech-to-text/v2/docs/reference/rpc/google.cloud.speech.v2) and [VAD events sample](https://docs.cloud.google.com/speech-to-text/docs/samples/speech-transcribe-streaming-voice-activity-events). Pinned installed SDK descriptor/object conversion was tested offline. Live/model VAD quality and real microphone/browser behavior remain unverified.

## Consumers/resources

- Consumer: frontend `SessionController.input()` after user commit; existing receipt-prefix barrier remains authoritative.
- Ports/service: `ContinuousSpeechRecognitionBackend`, `ContinuousListeningRegistry`, `ListeningLease`, one-use commit bindings.
- HTTP: separate WebSocket route and global Stop/delete/app-close lifecycle hooks.
- Ordinary PTT: unchanged `MediaOperation`/`open_microphone` validation.
- Tests: synthetic buffers, fake SDK-shaped messages and ASGI/WebSocket only; no live accounts, credentials or devices.
