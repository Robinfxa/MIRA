# Prepare a local public Codex runtime

MIRA's regular text-development entry reads a private admission file generated from your own official Codex installation and current local policy environment. The helper does not ask you to handwrite config hashes, copy cloud paths, copy login files, or supply a JEV key. It never reads `.env` or the JEV key; MIRA's normal local configuration loader handles Google and JEV settings when the app runs.

The no-argument command is inert:

```bash
python tools/prepare_runtime_admission.py
```

It reports `unarmed` and does not start Codex. `--help` only shows options. The explicit `--prepare` path starts the pinned native app-server and may cause ordinary account/catalog metadata traffic. It sends only initialize and config-read protocol messages; it performs no account lookup, model turn, tool call, or inference. This is a metadata setup action, not an offline configuration check.

Before any metadata request, the command requires both `--confirm-policy-environment` and `--authorize-codex-and-jev-content`, plus caller-selected finite request ceilings. The policy confirmation records that the applicable local proxy/certificate policy is understood. The separate content authorization acknowledges that later MIRA text entry sends entered dialogue and relevant prior application context to native Codex/OpenAI and TypeSafe/JEV, and sends the generated candidate to TypeSafe/JEV. JEV requests may be billable. The displayed request and turn ceilings are request counts, not dollar caps; they are enforced per app invocation in memory, so restarting the app with the same admission begins a fresh allowance. They are not a durable cross-restart ledger. MIRA does not send workspace files or authentication files through this workflow.

Example one-time preparation:

```bash
runtime_cwd="$(mktemp -d "$HOME/mira-codex-runtime.XXXXXX")"
python tools/prepare_runtime_admission.py \
  --prepare \
  --runtime-cwd "$runtime_cwd" \
  --codex-requests 2 \
  --session-turns 2 \
  --input-jev-requests 3 \
  --output-jev-requests 3 \
  --input-jev-timeout-seconds 10 \
  --output-jev-timeout-seconds 10 \
  --probe-timeout-seconds 10 \
  --confirm-policy-environment \
  --authorize-codex-and-jev-content \
  --write-admission "$HOME/mira-runtime-admission.json"
```

The helper finds `codex` on `PATH`, uses `CODEX_HOME` or `~/.codex`, and accepts explicit `--codex` and `--codex-home` paths if needed. The executable must match the pinned official Linux Codex CLI 0.159.2 build. Version or digest mismatch fails with a fixed diagnostic; the helper does not auto-update or re-pin. This implementation does not claim Mac or Windows support.

The runtime working directory must already exist, be private, and be empty. The output path must be absolute, new, outside the repository, and under existing safe directories. The helper creates only the new JSON file with mode 0600; it does not change directory modes, login state, settings, or grants. API-key and provider-route override environment variables fail by name-presence check, and their values are never inspected or printed. Proxy entries containing user information, query strings, or fragments are rejected.

The resulting public admission uses `route_kind=public` and `development_context=null`, and stores the exact config digest and selected non-secret runtime environment. Fingerprints and pinned-version checks describe observed metadata only. A successful declaration does not establish account entitlement, available quota, inference readiness, or dollar spend limits.
