# MIRA · 原创角色互动开发版

**可运行的零密钥演示；真实文字单轮已获得许可，完整语音与设备体验仍待验收。**
MIRA 是一位26岁的原创虚构摄影师，场景是雨夜咖啡馆。角色主绘制使用本地PixiJS高细节全帧PNG；原有SVG角色仍作为完整的渲染/资产失败fallback。应用保留四态、表情与受控动作、文字输入、可取消音频传输/播放、独立语义审核，以及有界脱敏诊断和显式开发录制。离线排练中的按住手势只提交固定合成文本，不采集麦克风；真实语音入口仍待授权后的设备验收。

## 当前实现与验收边界

以下为源码捕获时的能力与历史证据摘要；本包捕获后的最终完整测试/发布结果以同包START-HERE为准，本文不会为补记结果而改写已冻结源码。最新核对请见“当前阶段与剩余范围”。各次测试和真实调用绑定各自源码快照，不能跨阶段替代验收。

- 默认 `mock` / `replay` 可离线启动，不读取私密 `.env`，不调用模型或真实语音服务。另有显式 `rehearsal`：固定口令、多轮呈现历史、预录英文合成音频及双语字幕，真实麦克风始终关闭。
- 已批准的原生 `gpt-6-luna` 文字探针与4次JEV审核在6.332秒内正常封口，给出字幕和动作许可，但未呈现到屏幕。4.66秒合成英文经生产STT准确转写，随后生成与审核因两项低置信度正确走UNKNOWN系统托底，未调用TTS。独立生产TTS组件完整生成3.24秒中文音频，dispatch到首PCM为1.273694秒，没有实际播放；这些是分开的受控证据，不是自然连续语音会话。详见[精确provider证据](docs/mission/PROVIDER-EVIDENCE-20261004.md)。
- 字幕/动作通过应用生成的 cue 身份与对应语音关联。Stop、新输入和权限撤销先在本地阻断；软件渲染样本不证明用户听见，也不是逐字对齐。
- 普通日志无原文。开发原文录制需要单独开关与确认，保持可见标记；凭据结构与不确定内容拒绝记录。原始音频录制仍默认关闭，只在显式注入的开发语音模式中提供应用范围的开关；最多512 KiB、短时暂存，提供精确缓冲试听，由用户确认已审核、再单独确认排入本机私有诊断队列；软件不能证明人实际听过。ASR转写不能代替原音审核，也没有自动口述秘密检测；队列接收不代表已写入磁盘。默认 mock/replay/rehearsal 麦克风与录制保持关闭。
- 独立审查已发现并修复字幕提前呈现、嵌套凭据过滤、累计音频上下文、错误文案和异常 token 等问题。每个后续阶段须重新冻结源码验证，旧阶段的绿色测试不能替代新版本验收。
- 真实浏览器/手机/扬声器/麦克风、完整3–5分钟交互录屏、真实模型表现与中文审核校准尚未完成。没有云部署或正式产品就绪声明。

[项目北极星](docs/NORTH_STAR.md) · [最终需求与验收](docs/mission/requirements-and-acceptance.md) · [当前版本与缺口](docs/mission/CURRENT-ACCEPTANCE.md) · [离线启动快速指引](docs/development/QUICKSTART.md) · [测试政策](docs/development/TESTING.md)

## 服务配置准备

在既有loader中加入具名服务配置和私密模板；提供默认无网络检查、显式有界模型目录检查。
**适配器代码与接入参数不代表账户开通或 live 准入。** 默认应用仍是 mock/replay；真实服务只能在显式装配、授权、预算和对应验收通过后使用。
[API环境与一次性准备](docs/development/API_ENV.md) · [Provider Matrix](docs/development/PROVIDER_MATRIX.md) · [初始环境交接（历史）](docs/handoff/ENV-01.md) · [规格](specs/features/ENV-01-development-services/spec.md)

```bash
python tools/api_env.py init     # 创建空.env；已有文件拒绝覆盖
python tools/api_env.py check    # 默认不联网；字段缺失退出2，不表示MVP失败
python tools/check.py --lane env --jobs 2
```

密钥仅在本机私密文件／进程提供，不发送聊天，不写进spec、日志、前端或截图。

## 历史基础阶段：增量分块测试

以下数字保留原阶段的历史含义，不是当前完整实现的测试总数。

默认开发检查改为affected；定向RED/GREEN不必先跑全量。9个默认离线块可并行，package/smoke留发布。
[测试工作流](docs/development/TESTING.md) · [FND03规格](specs/features/FND-03-scoped-quality/spec.md) · [验证](docs/changes/FND-03/verification.md)

最终本地181 Python＋20 Node、18条规格映射通过；4组真实RED/GREEN。定向示例与分块收据均在验证目录，未选检查明确not_run。

## 继承的开发示范

[SDD/TDD示范手册](docs/development/TDD-SDD.md) · [功能规格](specs/features/FND-02-fixture-replay/spec.md) ·
[开发日志](docs/development/LOG.md) · [本轮验证](docs/changes/FND-02/verification.md) · [基础阶段交接（历史）](docs/handoff/FND-03.md)

FND-02是一个新adapter的完整例子，不是空目录：先写规格，真实RED/GREEN，再重构和集成。最终132 Python＋20前端通过；此前73 Python为基线，未伪造其TDD顺序。无新增依赖版本升级。

## 快速启动

需要 Python 3.11–3.13、Node.js 22.12+ 和锁文件声明的依赖。在工程根目录运行：

```bash
sh scripts/dev
```

此命令**不会安装依赖**。先验证 `.venv` 和当前解释器的实际应用导入能力；不完整的 `.venv` 不会遮住可用的当前解释器。
缺依赖会退出 2 并提示显式安装。首次准备需要包注册表：`python3 tools/bootstrap.py`，只写项目 `.venv` 和 `node_modules`。
如果已在其他隔离环境安装依赖，用显式解释器路径，不自动扫描或猜测虚拟环境名称：

```bash
sh scripts/dev --python /absolute/path/to/ready/python
# Windows尚未列入本轮受支持交付范围，见下方平台限制。
```

启动前检查合同、通过本地bundle构建前端，再以单进程提供 API 和静态工作台。浏览器手动打开 `http://127.0.0.1:8000`；可用 `--port 8123` 改端口。
**默认演示固定为 mock，忽略根 `.env` 和进程中的 MIRA 服务配置／常用凭据变量**；不启用 live provider、付费调用或原文记录。`--no-bootstrap` 保留兼容，但现在所有启动都不自动安装。
归档可没有脚本执行位，所以推荐 `sh scripts/dev`，不要求 `chmod`。

### 有声离线排练（推荐演示入口）

```bash
sh scripts/dev --profile rehearsal
# 已验证可用的其他解释器可追加 --python /absolute/path/to/ready/python
```

页面常显 `OFFLINE · 固定互动排练`。这条路线只有 7 个固定口令和一个失败注入，不支持自由对话；目录外文字只得到明确口令提示，不被假装识别或转述。真实麦克风按钮保持关闭，独立「按住演练输入 · 不录音」只展示 listening 状态，松开后提交固定的「照片里有什么」，不会调用录音或 STT。

原始音频/文字录制默认关闭。8 段预先生成的英文合成声音共约 52.56 秒，来自本地 Flite `slt`，不是 Google 语音、真人声音或中文发音验收；中文翻译与完整英文句子按现有语音 cue 显示，非逐字对齐。音频只经既有 Actor、有效许可、认证音频流和唯一取消安全播放队列进入页面。

12:56 历史归档存在图片未就绪就记录呈现回执的问题。当前源码已加入可取消的图片就绪等待、最新许可复核与失败重试修复，并通过独立软件层复验；旧归档保持原样并附已知问题说明。前端还会等待已有呈现回执同步后再提交下一轮，Stop 不等待网络。服务端也已加入缺失回执前缀的拒绝与同请求重试控制，独立11个场景和1843组合软件发布检查已通过。当前未验证浏览器实际绘制或用户看见。见[当前状态](docs/mission/CURRENT-ACCEPTANCE.md)。

按自己的节奏走一遍约 3–5 分钟的指引（包含观察、重复与停止，不是已录制的验收时长）：

1. 「你好」→「不要拍我」：观察好奇、微笑与相机放低。
2. 「看照片」：等语音与原创海岸/灯塔插画出现。
3. 「讲讲旅途」：讲话中点「停止回应」。声音、字幕不继续，已经看到的插画保留。
4. 按住「演练输入」，确认画面显示 listening 且没有麦克风请求；松开只发送「照片里有什么」。回应用实际呈现过的插画；新会话未看图就问，会先提示看图。
5. 「听雨」→「暖灯」：看环境和表情变化。用 `/fail` 测失败，再点「你好」恢复；输入目录外文字检查口令提示。

完整口令：`你好`、`不要拍我`、`看照片`、`照片里有什么`、`讲讲旅途`、`听雨`、`暖灯`、`/fail`。前后空格和改写也不会被当作识别成功。Stop、失焦、取消、关闭或更新的文字输入都会使待发送的合成输入失效。

这条路径用于验证受控体验，不证明真实模型、真实语音识别、物理扬声器听感、手机或真人 3–5 分钟互动录屏已经完成。[规格与实测边界](specs/features/DEMO-01-offline-rehearsal/spec.md) · [素材来源](docs/changes/DEMO-02-offline-speech-assets/README.md)

回放固定照片场景（不调用模型）：

```bash
sh scripts/dev --profile replay
# 其他现成 Python 环境同样追加 --python /absolute/path/to/ready/python
```

可以加 `--replay-scenario delayed-photo` 测停止，或 `--replay-scenario failed-tail` 测失败。
这只是固定生成夹具回放，不是自然语言理解或完整会话恢复。语音、账户、真实设备能力不能从本启动检查推出。

配置感知入口仍是 `PYTHONPATH=apps/api/src /path/to/ready/python -m mira`，它会按原 loader 读取根 `.env` 和进程配置；仅在已明确配置、授权和审核的开发流程中手动使用，不属于上述离线演示。live 工厂守卫不因启动工具改变而放宽。

离线 wheel 验证：`/path/to/ready/python tools/verify_package.py`。构建 Python 需要现成的 pip 与 `pyproject.toml` 固定版本的 setuptools、wheel（已列入开发锁文件）；必要时加 `--build-python /path/to/build/python`，运行烟测仍使用调用脚本的解释器。工具在临时副本编译前端、无网络构建／安装 wheel，并从安装目录验证配置、fixture、HTTP 与全部静态资源；不靠 checkout 的 PYTHONPATH 补资源。直接手动构建 wheel 前须先 `npm run build`，漏编译会明确失败。
实测和限制见 [STARTUP-01 验证](docs/verification/startup-01/verification.md)。

## 质量命令

```bash
python tools/check.py --list
python tools/check.py --files apps/api/src/mira/adapters/generation/replay/backend.py --plan
python tools/check.py --lane providers actor --jobs 2  # 精确相关块
python tools/check.py --affected --base <共同Git基点> --jobs 3  # 合并前
python tools/check.py --full --jobs 3      # 集成收口，不是每次修改
python tools/check.py --release --jobs 3   # 再加离线wheel与loopback
python tools/verify_tdd_evidence.py         # 原FND02历史完整性；公开归档不含其所需原日志
python tools/export_contracts.py --check
```

无Git的ZIP用`--files`或`--lane`；默认命令只检查Git工作区，已提交变更请带base。报告在`var/quality/<run>/summary.json`，未选块为not_run，没有测试结果缓存。

环境里同时存在多个 Python 时，用已验证且依赖完整的解释器绝对路径执行质量命令；不要仅凭 `.venv` 目录存在就认为可用。
14:48 已验证源码已完整展开至提交 `45b716d7ae80ce9d55934b81372dd1a7b411caf3`，543个源码文件的 Git blob 与模式逐项匹配，46个历史备份文件保留。其[首个真实远端 CI](https://github.com/Robinfxa/MIRA/actions/runs/37140155063)通过10个离线质量块；该次未跑 package/smoke。其后修复了发布任务缺少 Node/npm 的准备步骤；33410f5手动发布检查通过。1756阶段6ab19a8的推送与手动CI也已通过，手动检查包括package/smoke；结果仍绑定各自提交。更新中的源码必须重新冻结和验证。

## 工作台能验证什么

输入“不要拍我”“看照片”“听雨”进入固定Mock场景；`/fail`注入生成失败。
可查看activity/output/permit版本、有效集合和回执数。停止先在浏览器生效，旧结果不能恢复。
支持新请求、重复请求、会话能力token、范围累加、停止截止范围和迟到回执。

默认模式不会产生真实 ASR/TTS/LLM 请求。原创角色和旅行插画已实现，属于本地矢量素材，不能说成实时生图。真实语音代码、软件级取消测试和控制台能力标记，也不能代替账户、声卡、麦克风与完整需求验收。

## 目录入口

```text
apps/api/src/mira/
  domain/             纯模型、错误、状态转换
  application/        用例与会话生命周期；ports声明外部能力
  adapters/           Mock/回放、默认关闭的真实服务、私有诊断适配器
  config/             类型与唯一env读取入口
  bootstrap/          工厂、组合根、生命周期装配
  entrypoints/http/   DTO、映射、依赖、路由、app factory
apps/web/src/
  app/                浏览器组合根
  features/session/   transport与交互协调
  features/presentation/  本地许可门、cue身份与原创场景执行器
  features/audio/     唯一播放队列、可取消麦克风采集
  features/diagnostics/  实际录制状态与安全错误文案
  shared/             公开配置、协议验证、generated类型
config/               非秘密默认值与profile
packages/contracts/   自动导出的OpenAPI
requirements/         精确安装版本闭包
scripts/ tools/       启动、安装、合同导出、验证
tests/                unit、integration、architecture、web、browser
docs/                 50h计划、实施ADR、来源快照、交接与验证
```

完整文件树见 `docs/implementation/FILE_TREE.md`。

## 配置与抽象的约束

- `Settings`不可变；默认值→profile→显式dotenv→进程env→测试overrides；未知配置启动失败。
- 业务层不读env、不知道provider名称；仅 `bootstrap/providers.py` 选实现。
- `create_app(settings)`可注入依赖；没有全局容器、import-time连接或反射插件扫描。
- domain标准库限定，application不反向依赖adapters；有自动边界测试。
- 公共DTO单点定义，OpenAPI／TS只导出；新增schema先改owner，再跑drift check。
- live provider 不会因环境字段齐全而自行启用；显式装配仍须通过身份、质量、数据和预算准入，不会偷偷 Mock 或改走付费路线。

## 必读文档

[50小时计划](docs/plans/50-hour-delivery.md) · [实施ADR](docs/implementation/ADR-F001-foundation.md) ·
[配置约定](config/README.md) · [开发范例](docs/implementation/config-and-extension-guide.md) ·
[基础阶段交接（历史）](docs/handoff/FND-03.md) · [原架构/复用 v0.6](docs/reference/architecture-v0.6/MIRA_架构全书_v0.6.md)

## 运行与安全界限

仅loopback＋单worker，内存会话，有限容量；停止与实例隔离是基础子集，不是生产认证系统。
浏览器token只在内存，诊断不输出用户原文/凭据；只服务明确public/dist文件，不服务仓库根。
刷新不恢复旧会话，关闭按钮释放本地session；完整持久化/隐私清除在WP05后续实现。

依赖来源与素材见THIRD_PARTY.md；AI使用与未进行的人工验证见AI_USAGE.md。
已在同一 Linux 环境的新隔离目录验证46个固定 Python 依赖、TypeScript5.8.3和启动；远端固定提交的10块CI也已通过。它们不代表全新操作系统、Windows/macOS、手机或物理音频验收。详见[安装证据与限制](docs/verification/fresh-install/verification.md)。

## 为什么选择按住输入

本 MVP 选择明确的按住/松开与停止控制，而不是自动 VAD：移动端更容易看清何时开始采集，能够利用用户手势解锁音频，并避免把背景声误作打断。真实路径仍需验证麦克风许可、识别结果、释放和新一轮衔接。离线 rehearsal 用单独标记的合成输入演练这些状态，不把它称为真实语音识别。

## 当前阶段与剩余范围

状态核对：2026-10-04 09:52 UTC。最新目标以用户2026-10-04 02:58:44 UTC重新提出的10小时为准，截止 **2026-10-04 12:58:44 UTC（多伦多08:58:44）**。此前延长至18:53:50的目标已被替代；原始开发起点2026-10-03 08:53:50 UTC保留。外部权限和收费调用仍按明确批准的范围、上限和保守账本执行。

- **可恢复交付：** 0837源码与公开投影分别通过12项离线发布检查（1696 Python tests＋8 subtests、277 Node、打包与HTTP启动），853个文件以三份源码/美术ZIP及四个恢复说明文件备份至GitHub恢复分支，提交 `c39cf97d957cd0a2ae0a36fb77863143225bb0a4` 的7项远端字节已逐项核验。实际交付helper在python -O下还原全部853文件。main保留用户合并的 `26b5904cb0c60a2ba726080f7fd2a27061a0c509`，展开应用源码仍是旧基线；归档提交CI只验证展开树，不替代ZIP源码验收。
- **当前后续切片：** 新鲜0837安装的HTTP健康检查成功，但Uvicorn缺少WebSocket协议依赖，真实麦克风升级请求返回404；此前ASGI测试不能覆盖这个安装问题。仅补官方wsproto1.3.2的隔离候选已通过5项实现测试和8项独立真实TCP检查，包括101升级、认证/Origin拒绝、大小边界与断开清理。PyJWT2.15.1窄修已在完整隔离Python3.12环境通过21项auth测试与7项独立负控，原auth实现未改；本次完整发布结果仍待新冻结验收。已发布0837保持原样。
- **首次安装实测：** 在已有Python3.12.14、Node24.19.0/npm11.9.0的Linux主机上，新项目目录与冷项目缓存运行原bootstrap成功，安装54.837秒，随后rehearsal健康就绪3.518秒；整次操作至回收5分55秒。不是全新操作系统、用户Mac或浏览器验收。另一个Python3.13.5发行环境缺ensurepip，原一键安装在下载前失败，手动从现有受信pip给新venv补种属于额外步骤。[启动前置检查](docs/development/QUICKSTART.md)。
- **离线演示：** rehearsal为固定口令、预录英文合成音频、字幕和原创场景；无密钥可启动。现有场景执行器已组合，包含表情、动作、环境和视觉事件。Linux安装/打包/HTTP有证据；真实浏览器绘制、听感、用户麦克风和手机仍待用户实机验收。
- **Pixi角色渲染：** PixiJS 8.19.0与esbuild 0.28.2通过锁文件安装，构建为本地浏览器bundle，不使用CDN。`mira_manifest.json`记录12个准确action×expression全帧：camera_ready、camera_lowered、look_at_rain各自对应calm、warm、curious、reflective；图像互斥切换，不叠加核心人物/表情/动作素材。渲染前异步准备本地PNG，再由现有串行controller复核许可并同步应用、记录原有receipt；Stop/新输入/Close可打断准备，WebGL丢失/资源错误退回原SVG。12个PNG总计约28.54 MiB、按需加载、最多当前＋暂存各一张Texture；这比原计划的双atlas占用更多静态文件空间。12个全帧提供动作与表情，没有口型同步。新增CSS合成层按当前phase提供轻微idle呼吸、listening倾斜、speaking点头；thinking静态、reduced-motion关闭，未增加Pixi ticker。这些运动已进入0810的完整发布验收及远端归档；实际浏览器可见性与设备节流行为仍未验收。源画面logical 560×720，底部中心锚点、等比例720高；移动/桌面几何估算分别约103/136px脸高，仍未浏览器截图或用户真机验收。旅行照片仍是独立媒体许可门控。
- **渲染验证：** 0810完整离线web套件274项通过，三类phase运动独立14项fake-DOM/Pixi-runtime检查通过。早期首次启动独验在已备依赖的Linux副本中约3秒健康就绪，12张PNG、26个chunk与11份许可证经HTTP验证。它们不代替实际浏览器/GPU、手机、Safari或人眼观察。
- **新选定美术路线：** 用户03:08选择PixiJS，配合明确成年（26岁）的原创高细节角色。原设计逻辑画布560×720保持；PNG真实尺寸与source anchors记录在manifest，不再将未实现的1120×1440计划尺寸写成素材现状。
- **原生模型恢复：** 已在批准的既有云桌面原生登录上下文完成严格隔离metadata与实际结构化生成，固定 `gpt-6-luna`、零工作区/外部工具能力。exec只读上下文的历史错误不适用于这条原生路径。额度归属与其他机器可用性没有由此得到证明。
- **JEV真实增量：** 最新固定合成文字ASGI探针在6.332秒内完成正常准入：1次原生生成、4次JEV均HTTP200，ready且sealed，产生字幕“你好，我们一起听雨。”及look_at_rain动作两份许可，无错误并正常释放资源。实际wire公式不一致保留了可追踪警告；原始双≥0.6和其余门仍生效。本探针没有提交呈现回执、没有播放，也不是连续用户会话或实机验收。
- **语音：** 历史合成STT和精确Gemini3.8 Flash TTS曾成功；TTS3.4秒中文PCM的headers=14.7693秒、保存完成=16.0560秒，没有首PCM/可听延迟。Google凭据重连已验证；最新4.66秒英文合成样本经实际STT获得完全匹配转写，原生生成和4次JEV后在最终审核因两项confidence=.58/.55低于.6而正确进入UNKNOWN，未调用TTS、未播放或呈现。随后独立生产TTS组件测试完整返回3.24秒中文PCM，dispatch→首PCM为1.273694秒、保存完成为探针开始后2.966465秒；没有扬声器播放，不能称可听延迟。完整自然语音会话仍未完成。[精确接入证据与边界](docs/mission/PROVIDER-EVIDENCE-20261004.md)。默认关闭的显式语音CLI及清理/CA路径在0136离线验收通过；每次启动次数和时长上限不等于跨重启美元预算。[语音入口](docs/development/DEVELOPMENT_VOICE.md)
- **普通用户启动：** 使用自己的官方Codex登录及Google/JEV配置，metadata/声明预检不证明模型权限。启动前明确上下文发送目的地及费用限制。安装版 `mira` 的已知配置错误会在开服务前退出2，stderr给固定 `configuration_error`、本次启动编号和安全字段提示，不回显值；启动编号只关联这次stderr，不暗示已写入服务日志。[准备流程](docs/development/RUNTIME_PREPARATION.md) · [文字入口](docs/development/DEVELOPMENT_APP.md)
- **隐私与故障：** 原文/原音默认关闭，凭据不记录；原音须针对精确缓冲人工审查后另行保存。没有自动口述秘密识别保证。错误与系统提示分开，诊断ID可定位但不暴露provider正文或认证headers。
- **未完成验收：** 真实单轮文字已取得语义许可；屏幕实际呈现、连续真实会话、完整语音链路、真机麦克风/音频及3–5分钟互动录屏仍开放。架构书长期记忆学习、完整storylet、动态素材、生图等可选范围，只有最新PDF必需项完成并验收后才继续。

[重置恢复记录](docs/mission/reset-recovery-20261003.md) · [录制与设备走查](docs/development/DEMO-RECORDING.md) · [1756历史走查](docs/development/DEVICE-ACCEPTANCE.md)

## 实际投入与后续两周计划

本轮记录起点为2026-10-03 08:53:50 UTC；截至本次09:52 UTC说明，历时约24小时58分，期间包含并行开发、研究、账户接入、环境重置与恢复。此数为经过的日历时间，不是人力工时，也不把多个并行任务相加。实际人工工时未独立计量。

若继续开发两周，第一周先完成最新PDF必需验收：可操作的移动场景、完整连续文字/语音、准确中断、至少三种情绪与两种非说话状态、一个环境变化及对话视觉事件、Pixi资源/降级路径、可复现安装与真实3–5分钟录屏，并以用户设备反馈修复最影响体验的缺陷。第二周在核心验收通过后，按实测延迟与失败率改善语音首包/播放队列、移动端资源和恢复体验，补充有代表性的中英文语义评估与性能证据；随后再评估长期记忆/故事与动态素材的最小增量，范围由验收结果决定，不承诺两周内实现完整架构书。

### 构建输出目录保护

新构建仅清理已带本工具固定标记的输出目录；源码、祖先、符号链接和未标记非空目录会明确拒绝。若旧版留下未标记的 `apps/web/dist`，先检查并将该目录改名保留，或在新的源码目录构建；不要为绕过检查手工伪造标记。正常源码包不携带dist，构建会重新生成。

### 本地会话容量提示

若返回明确的 `429 session_capacity`，界面说明这是本地会话/轮次/录音流容量限制。请先点“结束本次会话”或关闭不用的会话，再刷新重建；连续重发当前输入不会解除该限制。其他429仍保留通用限流提示，不推断具体服务配额，也不自动重试。未知server正文不会显示到界面。

### 平台与依赖边界

[本轮运行依赖审查与限制](docs/development/RUNTIME-SECURITY-NOTES.md)

本轮安装与真实socket证据来自Linux；用户Mac仍需亲自验收。Windows尚未验证，锁定Starlette0.50.0的[Windows UNC StaticFiles公告](https://github.com/Kludex/starlette/security/advisories/GHSA-wqp7-x3pw-xc5r)涉及该平台的静态文件路径，不能把Linux结果当作Windows安全证明。当前不为未选平台跨栈升级；不要在Windows启用本开发服务器。可选ChatGPT登录helper已固定PyJWT2.15.1，精确版本与artifact来源见同包锁文件及provenance；全部原权限和RS256-only边界不变。
