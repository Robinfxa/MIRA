# Known gaps and historical defect closure: 20261003T1236Z

## Current stage

The immutable 12:36 candidate and this privacy-filtered, extracted source projection both passed the local automated release selection: **1,065 Python tests, 161 Node tests, 12 lanes**, including offline wheel build/install and a real local loopback HTTP smoke. This is a recoverable development checkpoint, not completed product acceptance.

## Earlier defects closed in this candidate

The 11:04 checkpoint and its known-issues note remain immutable historical evidence. Their defects are not described as still open in the new source:

- IA-01: structured/nested credential-shaped text filtering corrected. Independent final candidate privacy confirmation is in `docs/mission/integrated-audit-1104.md`, section “IA-01 最终修复哈希独立确认”; production privacy hash e02331f91faf7b04e6b75a986121e1fe80794b3af7bbb9617eec7b4df5678d7b. Default raw recording remains OFF; no new recording consent is implied.
- IA-02: future subtitle/visual cues now wait for the corresponding audio start. IA-04: safe recovery wording survives the actual entrypoint; prototype-property error-code lookup was also corrected. See `docs/mission/cue-independent-verification.md` and `docs/verification/wp07-cue-causality/verification.md`.
- IA-03: cumulative audio facts are projected per immutable effect into model context without discarding the authoritative ledger. See `docs/verification/wp08-audio-context/README.md` and the IA-03 follow-up in the historical audit.
- IA-05: non-ASCII session tokens are rejected safely before constant-time comparison. See `docs/verification/wp08-session-boundary/README.md` and the IA-05 follow-up in the historical audit.
- Deterministic microphone teardown: synchronous invalidation and raw queue clearing precede cancellable teardown; owned tasks remain bounded/accounted until completion. See `specs/features/WP03-microphone-teardown/spec.md` and its traceability tests. The release rerun includes these tests.

Some historical reports still say a later full/release was pending at their writing time. The two release receipts in this checkpoint establish the newer automated result without rewriting those historical findings.

## New completed work in this 12:36 candidate

- Async diagnostic locators: actual application failure correlation reaches the snapshot and safe UI output; TTS/STT/playback error paths retain validated identifiers, and Stop/new input clear stale errors. Ordinary sanitized events and visible IDs share the same hash convention. See `docs/verification/obs-02-async-error-locators/verification.md` and `specs/features/OBS-02-async-error-locators/traceability.json`. This closes the 11:58 checkpoint's dedicated asynchronous-locator gap for the tested software paths.
- Evaluation accounting root: immutable source/corpus checks remain bound to the frozen root while the approved accounting/config root explicitly supplies the shared existing budget ledger and lock. See `docs/changes/WP01-jev-evaluation-runner/verification.md` and `usage.md`. Offline tests do not authorize or establish a live evaluation, budget reset, threshold change or calibration admission.
- Audio interruption cause: an interruption report no longer invents USER_STOP. Playback records UNKNOWN; downstream cancellation records PERMIT_REVOKED; explicit Stop/new-input preserve USER_STOP/SUPERSEDED. See `docs/verification/obs-03-audio-interruption-causes/verification.md` and its feature spec.

The first whole-candidate release attempt failed the package lane because its local declared TypeScript dependency link was missing. That failed receipt is preserved. The same source digest passed all 12 lanes after reusing the existing dependency link; this public extracted projection then passed independently. No source fix, package download or fresh dependency installation is claimed for that environment correction.

Ongoing rehearsal work and documents written after the 12:36 freeze are deliberately not included.

## Still not established

- Real browser pixels, real mobile devices, microphone/speaker behavior, acoustic stop latency, actual intelligibility, or word-level synchronization.
- Continuous 3–5 minute interaction and a matching acceptance recording; the original complete product/architecture acceptance.
- Live-provider account/model/permission/budget readiness or live application admission. This checkpoint contains no credentials, OAuth state or private configuration.
- Production Chinese semantic-review calibration. Frozen evaluation cases and their original v1 integrity archive are preserved; synthetic expected cases are not measured live quality.
- Guaranteed durable diagnostic delivery/retention: asynchronous failure locators are now implemented and tested, but logging remains best-effort; see the closure below.
- Real media-resource failure/recovery, live network interruptions and real permission-refusal UX.
- Fresh dependency installation, all-platform compatibility, remote CI, deployment or merge success.

## Evidence intentionally excluded

Raw logs, generated test workspaces, private diagnostic/runtime files, authentication setup notes, the user-supplied PDF and duplicate source/build snapshots are not public. The historical `tools/verify_tdd_evidence.py` command requires excluded original FND-02 raw logs and is therefore **not runnable from this public checkpoint**. The current offline release suite is runnable and was rerun successfully.

Relative file links in the current README and setup/handoff documents were checked: 35 checked, 34 present. The sole missing directory is `docs/verification/fnd-02/runs/`, an intentional raw-evidence exclusion. Link anchors, plain code paths and all historical reference links were not exhaustively checked. No required startup/source/test fixture was removed.
