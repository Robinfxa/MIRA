# WP01 JEV output-review request bound

Status: bounded local serialization/transport contract. This is not a provider token
or cost ceiling and does not represent a live provider call.

### WP01JEVREQUESTBOUND-001 Output-review requests remain complete and byte-bounded

Given an output review request containing its exact current context, candidate, immutable
review contract, full question set and digests, the backend serializes canonical UTF-8
without projecting away context or evidence. Exactly 32,768 serialized bytes may be
sent. A request at 32,769 bytes returns UNKNOWN with the fixed `jev_request_too_large`
reason before transport invocation. The HTTP transport independently accepts exactly
32,768 bytes and rejects a larger body before creating an HTTP request. Limits are
measured in bytes, including multibyte UTF-8 characters.

Only the local output-review request envelope changes to 32 KiB. Input-review stays at
16 KiB; the existing 64 KiB response ceiling, question set, decision thresholds,
request-budget reservation, retries, provider token/cost limits and evidence binding
remain unchanged. An actual four-turn synthetic ASGI run retains complete input history,
presented effects, accepted prefix, snapshots, input observations and digest binding
with eight input-review requests, eight output-review requests and four fake generation
requests. This software-only result does not establish real UI presentation, human
understanding, provider account access, spend, network behavior or audio.
