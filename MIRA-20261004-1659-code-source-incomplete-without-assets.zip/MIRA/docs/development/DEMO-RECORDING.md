# MIRA 3–5 minute recording and first start

This is a human-run plan, not a video or test result. Use a verified published stage with its matching three-part restore pack and record that exact version. A newer candidate needs its own release before replacing an older verified delivery.

## Choose the mode honestly

**No-key rehearsal (recommended):** fixed commands, offline assets, bilingual cue subtitles and prerecorded Flite/slt synthetic English clips (8 clips, about 52.56s total); no provider calls. `按住演练输入 · 不录音` simulates listening, then submits fixed text `照片里有什么`. The real microphone is off. Say this on camera.

**Live user-configured route:** needs the user's own environment/admission and explicit content/spend authorization. Latest text probe: Luna generation + 4 JEV HTTP 200, sealed subtitle/pose grants after 6.332s, but zero presentations. A07:29 probe used4.66 seconds of synthetic English audio and obtained an exact79-character STT match. Generation and four JEV200 responses followed, then final review correctly returned UNKNOWN at confidence.58/.55 below.6. No TTS, playback or presentation. This is not a physical mic run and not a transport failure. Keep these separate from the no-key take; see [current acceptance](../mission/CURRENT-ACCEPTANCE.md).

## First start

Keep the current-stage code ZIP, both asset ZIPs, split manifest, matching restore helper, checksums and START-HERE together. Restore all three ZIPs to a new destination with that helper. Don't mix stages, manually merge, reuse another stage's helper, or hand-edit hashes/build markers. When the current package exists, run its exact START-HERE command. Pattern:

```sh
STAGE='exact-stage-token-from-START-HERE'
sha256sum -c "MIRA-${STAGE}-SHA256SUMS.txt"
python3 -O "./MIRA-${STAGE}-restore.py" restore \
  --delivery-dir . --target "../MIRA-${STAGE}-restored"
cd "../MIRA-${STAGE}-restored"
```

Choose a verified published stage. If the newest pack is pending, an older verified pack can be demonstrated under its own exact version label. Use only its matching helper/manifest/ZIPs; never substitute a development capture manifest for the delivered split ZIP manifest.

From the restored project root, record versions and install the locked dependencies:

```sh
python3 --version   # Python 3.11–3.13
node --version      # Node.js 22.12+
npm --version
python3 tools/bootstrap.py
sh scripts/dev --profile rehearsal
```

Bootstrap uses the project locks and needs the official package registries; it does not install Node/npm. If `venv` fails for missing `ensurepip`, use a supported Python with pip, not a global-package workaround. Open `http://127.0.0.1:8000` on the same computer; use `--port 8123` only if needed. Stop with Ctrl+C. Local server binds to loopback: don't expose it through a tunnel. A narrow desktop window is not phone acceptance. The earlier ~3s startup was measured after dependency setup, not a clean-machine ≤15-minute run.

Ready check: visible `OFFLINE · 固定互动排练`; session connected; `按住说话` disabled; rehearsal control says `不录音`; no mic/camera prompt. Keep secrets and private content out of screen and notes.

## Continuous 4:25 shot list

Start after the page is ready. Record one real take of 3–5 minutes; no invented footage or edits that hide a failure or lingering sound. If something fails, leave it visible and mark it.

- **0:00–0:20** Show offline badge/connected state. Say: “This is the fixed offline rehearsal. It uses prerecorded synthetic English audio and fixed commands; the microphone is off.”
- **0:20–0:50** Click `你好`, then `先放下相机吧` (`不要拍我`). Observe actual face/camera pose.
- **0:50–1:35** Click `给我看看你的旅行`; wait for the image to be visibly on-screen, then click `照片里有什么`. Record what was actually shown/heard.
- **1:35–2:30** Click `讲讲旅途`; only once the prerecorded audio is physically audible, click `停止回应` mid-playback. Stopwatch click-to-last-audible tail; check subtitle/phase stops and visible art remains. If not audible, mark `blocked`/`not_run`.
- **2:30–3:05** Hold `按住演练输入 · 不录音`, show `listening`, release, and verify the fixed prompt is submitted. Do not call it microphone recognition.
- **3:05–3:40** Click `一起听会儿雨`, then `暖灯`. Note actual Pixi expression/scene, crop, overlap, blank/fallback. Software asset tests do not prove browser pixels.
- **3:40–4:15** Click `测试一次失败` (`/fail`), leave the actual error readable, then click `你好` and check recovery. Note error code/diagnostic ID or “not shown.”
- **4:15–4:25** Leave offline badge visible and stop before 5:00. Record actual device, OS, browser/version and viewport. If no supported phone path, mark phone `blocked`; don't call a simulated viewport a phone.

Afterward record: exact source-pack stage; start time; versions/device/browser/viewport; video length; each step `pass/fail/blocked/not_run`; actual displayed text/scene; whether audio was heard; stop/tail time; recovery; visible diagnostic ID. Leave raw recording off. Never show/share `.env`, ADC/auth data, keys, tokens, headers, private dialogue or audio.

A successful rehearsal take can show fixed offline interaction, art, prerecorded playback interruption and failure recovery. It does not prove live model, real microphone, live STT/TTS, Chinese voice, continuous live dialogue, or phone/Safari acceptance. No actual video is present yet; D04 awaits the user recording. D01 awaits publication of the matching current source pack; D03 awaits a timed clean-machine start. See `CURRENT-ACCEPTANCE.md` for the full PDF item ledger.
