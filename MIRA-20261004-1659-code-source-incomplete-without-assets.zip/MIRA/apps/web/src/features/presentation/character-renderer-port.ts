import type { SceneState } from './scene-state.js';

/** Read-only resource preparation plus a synchronous, gate-following visual commit. */
export interface CharacterRendererPort {
  prepareState(state: SceneState, signal: AbortSignal): Promise<boolean>;
  render(state: SceneState): void;
  destroy(): void;
}
export type CharacterRendererFactory = (host: HTMLElement, signal: AbortSignal) => Promise<CharacterRendererPort | null>;
