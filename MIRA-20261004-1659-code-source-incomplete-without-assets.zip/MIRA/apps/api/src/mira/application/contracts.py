"""Transport-independent inputs/outputs of generation and review adapters."""
from dataclasses import asdict, dataclass, field
from enum import StrEnum

from mira.domain.models import AudioProgress, Effect, EffectKind
from mira.application.memory_context import ContextPacket


def audio_context_progress(progress: tuple[AudioProgress, ...]) -> tuple[AudioProgress, ...]:
    """Project cumulative latest facts for model context, preserving the owner's ledger.

    Samples and status are copied verbatim: partial rendering never becomes completed
    or heard words. Full immutable effect identity prevents collapsing conflicting
    imported identities. Presentation sequence gives deterministic cross-effect order.
    Provider byte/effect bounds remain enforced; this is not unbounded history storage.
    """
    latest = {}
    for fact in progress:
        latest[(fact.effect_id, fact.digest, fact.output_epoch, fact.activity_seq)] = fact
    return tuple(sorted(latest.values(), key=lambda fact: fact.presentation_seq))


@dataclass(frozen=True, slots=True)
class EffectProposal:
    kind: EffectKind
    value: str


@dataclass(frozen=True, slots=True)
class CandidateRange:
    """A complete fixture range, never a raw token delta or provider progress log."""
    effects: tuple[EffectProposal, ...]
    fixture_id: str


@dataclass(frozen=True, slots=True)
class GenerationContext:
    user_text: str
    user_inputs: tuple[str, ...]
    presented_effects: tuple[Effect, ...]
    output_epoch: int
    accepted_prefix: tuple[Effect, ...] = ()
    # Partial software rendering is not a claim that the entire speech text was heard.
    audio_progress: tuple[AudioProgress, ...] = ()
    # Explicitly opt-in; not authority, and excluded from raw diagnostics.
    memory_packet: ContextPacket | None = field(default=None, repr=False)


def generation_context_data(context: GenerationContext) -> dict[str, object]:
    """Canonical transport projection; absent memory preserves legacy wire bytes."""
    if type(context) is not GenerationContext:
        raise TypeError("generation_context_invalid")
    data = asdict(context)
    data.pop("memory_packet", None)
    if context.memory_packet is not None:
        # Use the packet's explicit, scope-free trust projection, not dataclass
        # field reflection. `memory_evidence` is omitted for old contexts.
        data["memory_evidence"] = context.memory_packet.as_dict()
    return data


class ReviewVerdict(StrEnum):
    ALLOW = "allow"
    REJECT = "reject"
    UNKNOWN = "unknown"


class ResponseValidationReason(StrEnum):
    """Closed parser categories suitable for local diagnostics."""

    ANSWER_COVERAGE = "answer_coverage"
    ANSWER_SHAPE = "answer_shape"
    BODY_SIZE = "body_size"
    CHOICE_NOT_MAXIMUM = "choice_not_maximum"
    DUPLICATE_KEY = "duplicate_key"
    INCONSISTENT_CONFIDENCE = "inconsistent_confidence"
    INVALID_UTF8 = "invalid_utf8"
    JSON_DECODE = "json_decode"
    MODEL_MISMATCH = "model_mismatch"
    NONFINITE_NUMBER = "nonfinite_number"
    NUMERIC_OVERFLOW = "numeric_overflow"
    PROBABILITIES = "probabilities"
    RESPONSE_SHAPE = "response_shape"
    UNKNOWN = "unknown"
    USAGE_SHAPE = "usage_shape"


class ResponseWireType(StrEnum):
    ARRAY = "array"
    BOOLEAN = "boolean"
    MISSING = "missing"
    NULL = "null"
    NUMBER = "number"
    OBJECT = "object"
    OTHER = "other"
    STRING = "string"


class ResponseChoice(StrEnum):
    ALLOW = "allow"
    REJECT = "reject"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class SafeResponseAnswerFacts:
    """Per-known-question facts only; suffix and categorical values are allowlisted."""

    question_suffix: str
    answer_wire_type: ResponseWireType
    answer_reason: ResponseValidationReason | None
    choice: ResponseChoice | None
    answer_field_count: int | None
    unexpected_answer_field_count: int | None
    expected_probability_count: int
    probability_field_count: int | None
    unexpected_probability_field_count: int | None
    valid_probability_count: int
    confidence: float | None
    selected_probability: float | None
    maximum_probability: float | None
    probability_sum: float | None
    selected_is_maximum: bool | None
    confidence_consistent: bool | None
    # Set only for the v3 completed-claim NOUL applicability fact. Kept at the end
    # with a default so existing choice-only producers and serialized records survive.
    noul_probability: float | None = None
    # Emitted only under reported-confidence-v2; the raw mismatch remains observable.
    confidence_mismatch_warning: bool | None = None


@dataclass(frozen=True, slots=True)
class SafeResponseValidation:
    """Small allowlisted structure summary; never contains provider-owned strings."""

    parser_reason: ResponseValidationReason
    response_wire_type: ResponseWireType
    response_bytes: int | None
    response_sha256: str | None
    expected_answer_count: int | None
    answer_count: int | None
    missing_answer_count: int | None
    unexpected_answer_count: int | None
    invalid_answer_count: int | None
    invalid_probability_count: int | None
    nonfinite_numeric_count: int | None
    oversized_integer_count: int | None
    selected_probability_range: tuple[float, float] | None = None
    confidence_range: tuple[float, float] | None = None
    probability_sum_range: tuple[float, float] | None = None
    answer_facts: tuple[SafeResponseAnswerFacts, ...] = ()
    # Omitted by the serializer for legacy strict records.
    choice_wire_policy_version: str | None = None


@dataclass(frozen=True, slots=True)
class ReportedConfidenceWarning:
    """Bounded numeric provenance for an accepted v2 input referent mismatch."""

    choice_wire_policy_version: str
    maximum_probability: float
    confidence: float
    probability_sum: float


@dataclass(frozen=True, slots=True)
class ReviewObservation:
    verdict: ReviewVerdict
    reason_code: str
    response_diagnostics: SafeResponseValidation | None = field(default=None, compare=False, repr=False)


@dataclass(frozen=True, slots=True)
class AuditEvent:
    sequence: int
    session_id: str
    kind: str
    state_revision: int
    output_epoch: int
    occurred_at: str
