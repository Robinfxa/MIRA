"""Strict metadata-only Codex setup handshake; never starts a thread or model turn."""
from __future__ import annotations

import asyncio
import hashlib
import re
from dataclasses import dataclass

from .payload import canonical, strict_json
from .process import StdioProcessTransport
from .protocol import _verify_config
from .types import CodexGenerationError, CodexLimits, CodexRuntime, PINNED_VERSION

_VERSION = PINNED_VERSION
_REQUESTS = (("initialize", {"clientInfo": {"name": "mira_metadata_setup", "version": "1.0"},
                              "capabilities": {"experimentalApi": True}}),
             ("config/read", {"includeLayers": False}))
_RESULT_FIELDS = frozenset(("jsonrpc", "id", "result"))
_UNSAFE_CONFIG_KEYS = frozenset((
    "api_key", "apikey", "openai_api_key", "openaiapikey", "access_token",
    "refresh_token", "authorization", "auth_headers", "headers", "credentials",
    "client_secret", "developer_instructions", "custom_instructions", "instructions_file",
))
_KNOWN_NOTIFICATION_METHODS = frozenset((
    # Exact event names accepted by the pinned local session protocol. These are
    # diagnostic labels only; metadata preflight still rejects every notification.
    "configWarning", "deprecationNotice", "account/rateLimits/updated",
    "turn/moderationMetadata", "thread/settings/updated", "account/updated",
    "remoteControl/status/changed", "warning", "thread/started",
    "thread/status/changed", "turn/started", "turn/completed", "item/started",
    "item/completed", "item/agentMessage/delta", "item/reasoning/textDelta",
    "item/reasoning/summaryTextDelta", "item/reasoning/summaryPartAdded",
    "item/plan/delta", "turn/plan/updated", "thread/tokenUsage/updated",
))
_EXPECTED_BODY_FIELDS = {
    "initialize": ("userAgent", "codexHome", "platformFamily", "platformOs"),
    "config/read": ("config", "origins", "layers"),
}
_OPTIONAL_BODY_FIELDS = {"initialize": (), "config/read": ("layers",)}


class PreflightDiagnosticError(CodexGenerationError):
    """Fixed reason plus protocol-envelope facts safe to show in local diagnostics."""

    def __init__(self, reason: str, details: dict):
        super().__init__(reason)
        # `details` is constructed only from fixed labels, bounded ints and bools.
        self.safe_details = details


@dataclass(frozen=True, slots=True)
class MetadataDeclaration:
    """Non-secret fingerprints describing observed setup metadata, not readiness."""

    executable_sha256: str
    config_sha256: str
    environment_sha256: str
    codex_version: str = _VERSION
    route_kind: str = "public"


class MetadataOnlyTransport:
    """Enforce the exact setup RPC sequence before sending anything to the process."""

    def __init__(self, transport: StdioProcessTransport, runtime: CodexRuntime):
        self._transport = transport
        self._runtime = runtime
        self._closed = False

    async def _response(self, request_id: int, method: str) -> dict:
        raw = await self._transport.receive()
        try:
            message = strict_json(raw)
        except CodexGenerationError as error:
            if str(error) != "codex_json_invalid":
                raise
            raise _diagnostic_error(method, "malformed_json", request_id) from None
        if type(message) is not dict:
            raise _diagnostic_error(method, "non_object", request_id)

        message_method = message.get("method")
        if type(message_method) is str:
            category = "server_request" if "id" in message else "notification"
            reported_method = (message_method if category == "notification"
                               and message_method in _KNOWN_NOTIFICATION_METHODS
                               else "unknown")
            raise _diagnostic_error(method, category, request_id,
                                    observed_id=message.get("id"),
                                    notification_method=reported_method)

        if "error" in message:
            error = message.get("error")
            code = error.get("code") if type(error) is dict else None
            if type(code) is not int or not -(2**31) <= code <= 2**31 - 1:
                code = None
            raise _diagnostic_error(method, "rpc_error", request_id,
                                    observed_id=message.get("id"),
                                    numeric_error_code=code)

        if set(message) - _RESULT_FIELDS:
            raise _diagnostic_error(method, "response_extra_fields", request_id)
        if (message.get("jsonrpc", "2.0") != "2.0"
                or type(message.get("id")) is not int or message["id"] != request_id):
            raise _diagnostic_error(method, "response_id_or_version_mismatch", request_id,
                                    observed_id=message.get("id"))
        if "result" not in message or type(message["result"]) is not dict:
            raise _diagnostic_error(method, "response_result_invalid", request_id)
        return message["result"]

    async def _request(self, request_id: int, method: str, params: dict) -> dict:
        if (request_id, method, params) not in ((1, _REQUESTS[0][0], _REQUESTS[0][1]),
                                               (2, _REQUESTS[1][0], _REQUESTS[1][1])):
            raise CodexGenerationError("codex_preflight_rpc_forbidden")
        await self._transport.send({"id": request_id, "method": method, "params": params})
        return await self._response(request_id, method)

    async def observe(self, timeout_seconds: float) -> MetadataDeclaration:
        if type(timeout_seconds) not in (int, float) or not 0 < timeout_seconds <= 30:
            raise CodexGenerationError("codex_preflight_timeout_invalid")
        if self._runtime.development_context is not None:
            raise CodexGenerationError("codex_preflight_route_unsupported")
        try:
            async with asyncio.timeout(timeout_seconds):
                initialized = await self._request(1, *_REQUESTS[0])
                if (set(initialized) - {"userAgent", "codexHome", "platformFamily", "platformOs"}
                        or initialized.get("codexHome") != str(self._runtime.codex_home)
                        or type(initialized.get("userAgent")) is not str
                        or not re.search(
                            rf"(?:^|/){re.escape(_VERSION)}(?:\s|\(|$)",
                            initialized["userAgent"],
                        )
                        or initialized.get("platformFamily") != self._runtime.platform_family
                        or initialized.get("platformOs") != self._runtime.platform_os):
                    raise CodexGenerationError("codex_preflight_profile_drift")
                await self._transport.send({"method": "initialized"})
                config_result = await self._request(2, *_REQUESTS[1])
                if set(config_result) - {"config", "origins", "layers"}:
                    raise CodexGenerationError("codex_preflight_profile_drift")
                if (type(config_result.get("origins", {})) is not dict
                        or config_result.get("layers") is not None
                        and type(config_result["layers"]) not in (dict, list)):
                    raise CodexGenerationError("codex_preflight_profile_drift")
                config = config_result.get("config")
                if type(config) is not dict:
                    raise CodexGenerationError("codex_preflight_profile_drift")
                _reject_unsafe_config_keys(config)
                _verify_config(config_result, self._runtime)
                config_digest = hashlib.sha256(canonical(config)).hexdigest()
                del config_result, config, initialized
                return MetadataDeclaration(
                    executable_sha256=self._runtime.executable_sha256,
                    config_sha256=config_digest,
                    environment_sha256=hashlib.sha256(
                        canonical(dict(self._runtime.environment))).hexdigest(),
                )
        except TimeoutError:
            raise CodexGenerationError("codex_preflight_timeout") from None
        except (TypeError, ValueError, RecursionError, UnicodeError):
            raise CodexGenerationError("codex_preflight_profile_drift") from None
        finally:
            await self.close()

    async def close(self) -> None:
        if not self._closed:
            self._closed = True
            await self._transport.close()


async def observe_public_metadata(runtime: CodexRuntime, *, timeout_seconds: float = 10.0,
                                  limits: CodexLimits | None = None) -> MetadataDeclaration:
    """Run the bounded public-route handshake and always reap its native child."""
    if runtime.development_context is not None:
        raise CodexGenerationError("codex_preflight_route_unsupported")
    from .process import open_stdio_preflight

    transport = await open_stdio_preflight(runtime, limits or CodexLimits(
        startup_seconds=timeout_seconds, turn_seconds=timeout_seconds))
    return await MetadataOnlyTransport(transport, runtime).observe(timeout_seconds)


def _reject_unsafe_config_keys(value: object) -> None:
    """Fail closed on credential-bearing or instruction injection config fields."""
    if type(value) is dict:
        for key, child in value.items():
            normalized = key.lower().replace("-", "_") if type(key) is str else ""
            if normalized in _UNSAFE_CONFIG_KEYS:
                raise CodexGenerationError("codex_preflight_profile_drift")
            _reject_unsafe_config_keys(child)
    elif type(value) is list:
        for child in value:
            _reject_unsafe_config_keys(child)


def _diagnostic_error(phase: str, category: str, request_id: int, *,
                      observed_id: object = None,
                      notification_method: str | None = None,
                      numeric_error_code: int | None = None) -> PreflightDiagnosticError:
    id_matches = (observed_id == request_id if type(observed_id) is int else None)
    details = {
        "phase": phase,
        "envelope_category": category,
        "request_id_match": id_matches,
        "expected_protocol_fields": ["jsonrpc", "id", "result"],
        "expected_body_fields": list(_EXPECTED_BODY_FIELDS[phase]),
        "optional_body_fields": list(_OPTIONAL_BODY_FIELDS[phase]),
    }
    if notification_method is not None:
        details["notification_method"] = notification_method
    if numeric_error_code is not None:
        details["numeric_error_code"] = numeric_error_code
    return PreflightDiagnosticError("codex_preflight_" + category, details)
