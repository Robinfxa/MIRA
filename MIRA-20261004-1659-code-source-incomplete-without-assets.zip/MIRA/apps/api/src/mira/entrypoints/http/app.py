"""Application factory; imports neither open sockets nor load configuration."""
from __future__ import annotations

from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from pathlib import Path
from uuid import uuid4
from time import monotonic
import asyncio
from typing import TYPE_CHECKING

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.openapi.utils import get_openapi
from fastapi.staticfiles import StaticFiles
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.datastructures import Headers

from mira.application.diagnostic_errors import classify_failure, public_error_code
from mira.application.diagnostic_events import (
    CancellationReason, DiagnosticCode, DiagnosticEvent, DiagnosticOutcome, DiagnosticStage,
    diagnostic_context, emit_safely, request_correlation,
)
from mira.application.ports.diagnostics import Diagnostics
from mira.application.ports.media import SpeechRecognitionBackend, SpeechSynthesisBackend
from mira.bootstrap.container import build_container
from mira.bootstrap.providers import GoogleVoiceProviders, Providers
from mira.config.loader import ConfigurationError, load_settings, project_root
from mira.config.settings import Settings
from mira.domain.errors import DomainError
from mira.entrypoints.http.routes import router
from mira.entrypoints.http.audio_review_routes import router as audio_review_router
from mira.entrypoints.http.media_routes import router as media_router
from mira.entrypoints.http.schemas import MEDIA_WIRE_MODELS
from mira.entrypoints.http.operator_routes import router as operator_router
from mira.entrypoints.http.operator_routes import COOKIE_NAME
from mira.entrypoints.http.operator_pairing import OperatorPairing

MEMORY_FACTORY_STARTUP_TIMEOUT_SECONDS = 5.0


class _OperatorWebSocketBoundary:
    """HTTP middleware skips WebSockets, so gate the private socket separately."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        owner = scope.get("app")
        pairing = getattr(getattr(owner, "state", None), "operator_pairing", None)
        if scope.get("type") == "websocket" and pairing is not None:
            headers = Headers(scope=scope)
            raw_cookie = headers.get("cookie", "")
            cookie = None
            for part in raw_cookie.split(";"):
                name, separator, value = part.strip().partition("=")
                if separator and name == COOKIE_NAME:
                    cookie = value
                    break
            if not pairing.is_authenticated(cookie, headers.get("origin"), headers.get("host"),
                                            app_id=getattr(getattr(owner, "state", None), "operator_app_id", None)):
                await send({"type": "websocket.close", "code": 4403})
                return
            try:
                await owner.state.ensure_runtime()
            except Exception:
                await send({"type": "websocket.close", "code": 1011})
                return
        await self.app(scope, receive, send)

if TYPE_CHECKING:
    from mira.application.actor_memory import SessionMemoryBinding
    from mira.application.memory_management import MemoryManagement


def create_app(settings: Settings | None = None, *, providers: Providers | None = None,
               web_root: Path | None = None,
               speech_synthesis: SpeechSynthesisBackend | None = None,
               speech_recognition: SpeechRecognitionBackend | None = None,
               media_shutdown: Callable[[], Awaitable[None]] | None = None,
               voice_factory: Callable[[], GoogleVoiceProviders] | None = None,
               diagnostics: Diagnostics | None = None,
               memory_factory: Callable[[], Awaitable[SessionMemoryBinding]] | None = None,
               memory_management_factory: Callable[[], Awaitable[MemoryManagement]] | None = None,
               operator_pairing: OperatorPairing | None = None) -> FastAPI:
    configured = settings if settings is not None else load_settings()
    if configured.providers.generation == "rehearsal" and any(value is not None for value in (
            providers, speech_synthesis, speech_recognition, media_shutdown, voice_factory,
            memory_factory, memory_management_factory)):
        raise ConfigurationError("Offline rehearsal cannot be combined with injected providers or media.")
    if voice_factory is not None and any(value is not None for value in (
            speech_synthesis, speech_recognition, media_shutdown)):
        raise ConfigurationError("Use voice_factory or explicit media injection, not both.")
    if memory_factory is not None and (
            not callable(memory_factory) or configured.runtime.max_sessions != 1):
        raise ConfigurationError("memory_recall_requires_single_operator")
    if memory_factory is not None and operator_pairing is None:
        raise ConfigurationError("memory_operator_pairing_required")
    if memory_management_factory is not None and (
            not callable(memory_management_factory) or memory_factory is None):
        raise ConfigurationError("memory_management_requires_recall_mode")
    if operator_pairing is not None:
        if memory_factory is None:
            raise ConfigurationError("operator_pairing_requires_memory_mode")
        if operator_pairing.expected_origins != frozenset(configured.http.allowed_origins):
            raise ConfigurationError("memory_operator_origins_mismatch")
    if memory_factory is not None and any(value is not None for value in (
            voice_factory, speech_synthesis, speech_recognition, media_shutdown)):
        # This first recall entry discloses only Codex/JEV recipients. Sending
        # recalled details in generated speech to a TTS provider needs its own
        # explicit disclosure, rather than inheriting the text-only admission.
        raise ConfigurationError("memory_recall_text_only")

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        # SDK async channels must be created on this running app loop.
        voice = None
        memory_binding = None
        memory_management = None
        container = None
        runtime_lock = asyncio.Lock()
        late_memory_tasks: set[asyncio.Task] = set()
        late_management_tasks: set[asyncio.Task] = set()
        late_management_close_tasks: set[asyncio.Task] = set()

        def close_late_memory_binding(task: asyncio.Task) -> None:
            late_memory_tasks.discard(task)
            if task.cancelled():
                return
            try:
                binding = task.result()
            except BaseException:
                return
            from mira.application.actor_memory import SessionMemoryBinding
            if type(binding) is SessionMemoryBinding:
                async def close_reader() -> None:
                    try:
                        await binding.reader.aclose()
                    except Exception:
                        pass
                asyncio.create_task(close_reader())

        def close_late_management(task: asyncio.Task) -> None:
            late_management_tasks.discard(task)
            if task.cancelled():
                return
            try:
                manager = task.result()
            except BaseException:
                return
            from mira.application.memory_management import MemoryManagement
            if type(manager) is MemoryManagement:
                async def close_manager() -> None:
                    try:
                        await manager.aclose()
                    except Exception:
                        pass
                close_task = asyncio.create_task(close_manager())
                late_management_close_tasks.add(close_task)
                close_task.add_done_callback(late_management_close_tasks.discard)

        async def close_runtime() -> None:
            nonlocal container, memory_binding, memory_management
            async with runtime_lock:
                close_failed = False
                if container is not None:
                    try:
                        await container.close()
                    except Exception:
                        close_failed = True
                    finally:
                        container = None
                if memory_binding is not None:
                    from mira.application.actor_memory import SessionMemoryBinding
                    if type(memory_binding) is SessionMemoryBinding:
                        try:
                            await memory_binding.reader.aclose()
                        except Exception:
                            close_failed = True
                    memory_binding = None
                if memory_management is not None:
                    try:
                        await memory_management.aclose()
                    except Exception:
                        close_failed = True
                    finally:
                        memory_management = None
                if memory_factory is not None:
                    app.state.container = None
                if memory_management_factory is not None:
                    app.state.memory_management = None
                for task in tuple(late_memory_tasks):
                    task.cancel()
                for task in tuple(late_management_tasks):
                    task.cancel()
                if late_management_close_tasks:
                    done, pending = await asyncio.wait(
                        tuple(late_management_close_tasks), timeout=1.0
                    )
                    for task in pending:
                        task.cancel()
                    late_management_close_tasks.difference_update(done)
                if close_failed:
                    raise RuntimeError("operator_runtime_close_failed") from None

        async def ensure_runtime() -> None:
            nonlocal voice, memory_binding, memory_management, container
            if container is not None:
                return
            async with runtime_lock:
                if container is not None:
                    return
                try:
                    voice = voice_factory() if voice_factory is not None else None
                    if voice_factory is not None and voice is None:
                        raise ConfigurationError("The explicit voice factory returned no providers.")
                    if memory_factory is not None:
                        from mira.application.actor_memory import SessionMemoryBinding
                        factory_task = asyncio.create_task(memory_factory())
                        try:
                            done, _pending = await asyncio.wait(
                                {factory_task}, timeout=MEMORY_FACTORY_STARTUP_TIMEOUT_SECONDS)
                        except BaseException:
                            late_memory_tasks.add(factory_task)
                            factory_task.add_done_callback(close_late_memory_binding)
                            factory_task.cancel()
                            raise
                        if not done:
                            late_memory_tasks.add(factory_task)
                            factory_task.add_done_callback(close_late_memory_binding)
                            factory_task.cancel()
                            raise TimeoutError("memory_factory_startup_timeout") from None
                        memory_binding = factory_task.result()
                        if (type(memory_binding) is not SessionMemoryBinding
                                or memory_binding.close_reader_on_actor_close):
                            raise ConfigurationError("memory_reader_ownership_invalid")
                    if memory_management_factory is not None:
                        from mira.application.memory_management import MemoryManagement
                        factory_task = asyncio.create_task(memory_management_factory())
                        try:
                            done, _pending = await asyncio.wait(
                                {factory_task}, timeout=MEMORY_FACTORY_STARTUP_TIMEOUT_SECONDS)
                        except BaseException:
                            late_management_tasks.add(factory_task)
                            factory_task.add_done_callback(close_late_management)
                            factory_task.cancel()
                            raise
                        if not done:
                            late_management_tasks.add(factory_task)
                            factory_task.add_done_callback(close_late_management)
                            factory_task.cancel()
                            raise TimeoutError("memory_management_factory_startup_timeout") from None
                        memory_management = factory_task.result()
                        if (type(memory_management) is not MemoryManagement
                                or not memory_management.is_open):
                            raise ConfigurationError("memory_management_ownership_invalid")
                        app.state.memory_management = memory_management
                    container = build_container(configured, providers=providers,
                        speech_synthesis=voice.speech_synthesis if voice else speech_synthesis,
                        speech_recognition=voice.speech_recognition if voice else speech_recognition,
                        media_shutdown=voice.close if voice else media_shutdown, diagnostics=diagnostics,
                        **({"memory_binding": memory_binding} if memory_binding is not None else {}))
                    app.state.container = container
                except BaseException:
                    # If the reader opened but container construction failed, close it
                    # before exposing an unauthenticated/unready app state.
                    if memory_binding is not None:
                        from mira.application.actor_memory import SessionMemoryBinding
                        if type(memory_binding) is SessionMemoryBinding:
                            await memory_binding.reader.aclose()
                        memory_binding = None
                    if memory_management is not None:
                        await memory_management.aclose()
                        memory_management = None
                        app.state.memory_management = None
                    if voice is not None:
                        await voice.close()
                        voice = None
                    raise
        try:
            app.state.close_runtime = close_runtime
            app.state.ensure_runtime = ensure_runtime
            if memory_factory is None:
                await ensure_runtime()
            yield
        finally:
            try:
                if operator_pairing is not None:
                    operator_pairing.revoke()
                await close_runtime()
            finally:
                if memory_factory is not None:
                    app.state.container = None

    app = FastAPI(title="MIRA Foundation", version="0.1.0", lifespan=lifespan)
    app.state.container = None
    app.state.operator_pairing = operator_pairing
    app.state.memory_mode = memory_factory is not None
    app.state.memory_management_enabled = memory_management_factory is not None
    app.state.memory_management = None
    app.state.operator_app_id = str(uuid4()) if operator_pairing is not None else None
    if operator_pairing is not None:
        try:
            operator_pairing.bind_app(app.state.operator_app_id)
        except ValueError:
            raise ConfigurationError("memory_operator_pairing_already_bound") from None
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "testserver"])
    if operator_pairing is not None:
        app.add_middleware(_OperatorWebSocketBoundary)
    app.add_middleware(CORSMiddleware, allow_origins=list(configured.http.allowed_origins),
                       allow_methods=["GET", "POST", "DELETE"],
                       allow_headers=["Content-Type", "X-Mira-Session-Token"])

    @app.middleware("http")
    async def local_boundary(request: Request, call_next):
        request.state.request_id = str(uuid4())
        context_token = request_correlation.set(request.state.request_id)
        started = monotonic()
        response = None
        outcome, code, reason = DiagnosticOutcome.FAILED, None, None
        try:
            origin = request.headers.get("origin")
            host = request.headers.get("host")
            pairing = getattr(request.app.state, "operator_pairing", None)
            operator_control = request.url.path in {
                "/api/v1/operator/status", "/api/v1/operator/pair", "/api/v1/operator/revoke"}
            if pairing is not None and request.url.path.startswith("/api/v1/"):
                if request.method not in {"GET", "HEAD", "OPTIONS"} and not origin:
                    response = JSONResponse({"code": "origin_required", "message": "Origin header required.",
                        "request_id": request.state.request_id}, status_code=403)
                elif not operator_control:
                    if not pairing.is_authenticated(request.cookies.get(COOKIE_NAME), origin, host,
                                                    app_id=request.app.state.operator_app_id,
                                                    method=request.method,
                                                    sec_fetch_site=request.headers.get("sec-fetch-site"),
                                                    referer=request.headers.get("referer")):
                        response = JSONResponse({"code": "operator_authorization_required",
                            "message": "Pair with the local operator first.",
                            "request_id": request.state.request_id}, status_code=401)
                    else:
                        try:
                            await request.app.state.ensure_runtime()
                        except Exception:
                            response = JSONResponse({"code": "operator_runtime_unavailable",
                                "message": "The local service is unavailable.",
                                "request_id": request.state.request_id}, status_code=503)
            if response is None and ((origin := request.headers.get("origin"))
                    and origin not in configured.http.allowed_origins):
                response = JSONResponse({"code": "origin_denied", "message": "此来源不被允许。",
                    "request_id": request.state.request_id}, status_code=403)
            elif response is None:
                try:
                    size = int(request.headers.get("content-length", "0"))
                except ValueError:
                    size = 1_000_000
                if size < 0 or size > 32768 or request.headers.get("transfer-encoding"):
                    response = JSONResponse({"code": "body_limit", "message": "输入超出大小限制，请缩短后重试。",
                        "request_id": request.state.request_id}, status_code=413)
                else:
                    response = await call_next(request)
            outcome = DiagnosticOutcome.SUCCEEDED if response.status_code < 400 else DiagnosticOutcome.FAILED
            code = None if response.status_code < 400 else classify_failure(
                http_status=response.status_code).code
        except asyncio.CancelledError:
            outcome, code, reason = (DiagnosticOutcome.CANCELLED, DiagnosticCode.CANCELLED,
                                     CancellationReason.DISCONNECT)
            raise
        except Exception:
            # The exception string/body may carry credentials or dialogue. Never reflect it.
            code = DiagnosticCode.UNKNOWN
            response = JSONResponse({"code": "internal_error", "message": "服务未完成操作，请重试或导出脱敏诊断。",
                "request_id": request.state.request_id}, status_code=500)
        finally:
            container = getattr(request.app.state, "container", None)
            emit_safely(container.diagnostics if container else None, DiagnosticEvent(
                DiagnosticStage.HTTP, outcome,
                diagnostic_context(session_id=request.path_params.get("session_id"),
                                   effect_id=request.path_params.get("effect_id")),
                code=code, cancellation_reason=reason,
                duration_ms=(monotonic() - started) * 1000,
                http_status=response.status_code if response is not None else None))
            request_correlation.reset(context_token)
        response.headers["X-Request-ID"] = request.state.request_id
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    @app.exception_handler(DomainError)
    async def domain_error(request: Request, error: DomainError) -> JSONResponse:
        status = 404 if error.code == "session_not_found" else (
            503 if error.code in {"speech_unavailable", "microphone_unavailable"} else
            429 if error.code in {"session_capacity", "busy"} else 409
        )
        safe = classify_failure(error)
        return JSONResponse({"code": public_error_code(error.code), "message": safe.message + safe.action,
                             "request_id": request.state.request_id}, status_code=status)

    @app.exception_handler(RequestValidationError)
    async def invalid_input(request: Request, error: RequestValidationError) -> JSONResponse:
        # No reflected raw input, credentials, or complete validation error bodies.
        return JSONResponse({"code": "invalid_request", "message": "Request does not match the contract.",
                             "request_id": request.state.request_id}, status_code=422)

    app.include_router(router)
    app.include_router(audio_review_router)
    app.include_router(media_router)
    from mira.entrypoints.http.memory_management_routes import router as memory_management_router
    app.include_router(memory_management_router)
    if operator_pairing is not None:
        app.include_router(operator_router)

    def public_openapi():
        if app.openapi_schema is None:
            schema = get_openapi(title=app.title, version=app.version, routes=app.routes)
            components = schema.setdefault("components", {}).setdefault("schemas", {})
            for model in MEDIA_WIRE_MODELS:
                shape = model.model_json_schema(ref_template="#/components/schemas/{model}")
                components.update(shape.pop("$defs", {}))
                components[model.__name__] = shape
            app.openapi_schema = schema
        return app.openapi_schema

    app.openapi = public_openapi
    root = web_root if web_root is not None else project_root() / "apps/web"
    if (root / "index.html").is_file():
        # Serve only public files and compiled JS, never project root or .env.
        app.mount("/assets", StaticFiles(directory=root / "public"), name="assets")
        app.mount("/dist", StaticFiles(directory=root / "dist", check_dir=False), name="dist")
        from fastapi.responses import FileResponse

        @app.get("/", include_in_schema=False)
        async def index():
            if operator_pairing is None and memory_management_factory is None:
                return FileResponse(root / "index.html")
            html = (root / "index.html").read_text(encoding="utf-8")
            body_start = html.lower().find("<body")
            if body_start < 0:
                raise RuntimeError("memory_operator_page_missing_body") from None
            tag_end = html.find(">", body_start)
            if tag_end < 0:
                raise RuntimeError("memory_operator_page_invalid") from None
            attributes = []
            if operator_pairing is not None:
                attributes.append(' data-operator-pairing="required"')
            if memory_management_factory is not None:
                attributes.append(' data-memory-management="enabled"')
            html = html[:tag_end] + "".join(attributes) + html[tag_end:]
            return HTMLResponse(html)
    return app
