"""Wire v0.1.0-foundation; deliberately NOT the full voice-v0.2 protocol.

Canonical public schemas live here. Generated OpenAPI/TypeScript are read-only.
"""
from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from mira.domain.models import AudioStatus, EffectKind, Phase

WIRE_VERSION = "0.1.0-foundation"
DiagnosticId = Annotated[str, Field(pattern=r"^h_[0-9a-f]{32}$", min_length=34, max_length=34)]


class WireModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class OperatorPairRequest(WireModel):
    code: Annotated[str, Field(min_length=1, max_length=128, pattern=r"^[\x21-\x7e]+$")]


class OperatorPairStatus(WireModel):
    required: bool
    paired: bool
    revoked: bool


ManagementEntryId = Annotated[str, Field(
    min_length=1, max_length=128, pattern=r"^[^\s\x00-\x1f\x7f]+$"
)]
ManagementOperationId = UUID


class MemoryManagementStatusView(WireModel):
    enabled: bool
    revision: Annotated[int, Field(strict=True, ge=0)] | None


class MemoryManagementEntryView(WireModel):
    entry_id: ManagementEntryId
    text: Annotated[str, Field(min_length=1, max_length=16384)]
    kind: Literal["episodic", "boundary"]
    source: Literal["user_statement"] = "user_statement"
    source_version: Annotated[int, Field(strict=True, ge=1)]
    recorded_at: Annotated[str, Field(min_length=20, max_length=64)]
    active: bool
    forget_event_id: ManagementEntryId | None
    forgotten_at: Annotated[str, Field(min_length=20, max_length=64)] | None


class MemoryManagementPageView(WireModel):
    revision: Annotated[int, Field(strict=True, ge=0)]
    entries: Annotated[list[MemoryManagementEntryView], Field(max_length=20)]
    next_cursor: Annotated[str, Field(max_length=64)] | None


class MemoryManagementOperationRequest(WireModel):
    operation_id: ManagementOperationId
    expected_revision: Annotated[int, Field(strict=True, ge=0)]
    operation: Literal["record", "correct", "forget", "restore"]
    confirmed: Literal[True]
    text: Annotated[str, Field(min_length=1, max_length=4096, pattern=r"\S")] | None = None
    kind: Literal["episodic", "boundary"] | None = None
    entry_id: ManagementEntryId | None = None
    forget_event_id: ManagementEntryId | None = None

    @field_validator("confirmed", mode="before")
    @classmethod
    def strict_confirmation(cls, value):
        if type(value) is not bool or value is not True:
            raise ValueError("operation confirmation must be the boolean true")
        return value

    @model_validator(mode="after")
    def exact_operation_fields(self):
        if self.confirmed is not True:
            raise ValueError("operation confirmation must be true")
        if self.operation == "record":
            valid = (self.text is not None and self.kind is not None
                     and self.entry_id is None and self.forget_event_id is None)
        elif self.operation == "correct":
            valid = (self.text is not None and self.kind is None
                     and self.entry_id is not None and self.forget_event_id is None)
        elif self.operation == "forget":
            valid = (self.text is None and self.kind is None
                     and self.entry_id is not None and self.forget_event_id is None)
        else:
            valid = (self.text is None and self.kind is None
                     and self.entry_id is None and self.forget_event_id is not None)
        if not valid:
            raise ValueError("operation fields do not match the selected memory action")
        return self


class MemoryManagementOperationView(WireModel):
    status: Literal["committed"] = "committed"
    operation_id: str
    revision: Annotated[int, Field(strict=True, ge=0)]
    entry_id: ManagementEntryId | None = None
    event_id: ManagementEntryId | None = None
    replayed: bool = False


class MemoryManagementErrorView(WireModel):
    code: str
    message: str
    request_id: str
    current_revision: Annotated[int, Field(strict=True, ge=0)] | None = None


class CreateSessionRequest(WireModel):
    client_instance_id: UUID


class InputRequest(WireModel):
    request_id: UUID
    activity_seq: Annotated[int, Field(strict=True, ge=1)]
    presentation_cutoff: Annotated[int, Field(strict=True, ge=0)]
    text: Annotated[str, Field(min_length=1, max_length=2000, pattern=r"\S")]
    source_audio_stream_id: UUID | None = None


class StopRequest(WireModel):
    activity_seq: Annotated[int, Field(strict=True, ge=1)]
    presentation_cutoff: Annotated[int, Field(strict=True, ge=0)]


class ReceiptRequest(WireModel):
    effect_id: UUID
    digest: Annotated[str, Field(pattern=r"^[a-f0-9]{64}$")]
    output_epoch: Annotated[int, Field(strict=True, ge=1)]
    activity_seq: Annotated[int, Field(strict=True, ge=1)]
    presentation_seq: Annotated[int, Field(strict=True, ge=1)]


class AudioProgressRequest(ReceiptRequest):
    sample_rate_hz: Annotated[int, Field(strict=True, ge=8000, le=48000)]
    rendered_samples: Annotated[int, Field(strict=True, ge=0, le=48000 * 300)]
    status: AudioStatus


class AudioProgressView(WireModel):
    effect_id: str
    digest: str
    output_epoch: int
    activity_seq: int
    presentation_seq: int
    sample_rate_hz: int
    rendered_samples: int
    status: AudioStatus


class EffectView(WireModel):
    id: str
    kind: EffectKind
    value: str
    digest: str
    output_epoch: int
    activity_seq: int
    cue_id: str | None = None
    cue_speech_id: str | None = None


class SessionView(WireModel):
    schema_version: Literal["0.1.0-foundation"] = WIRE_VERSION
    session_id: str
    client_instance_id: str
    revision: int
    activity_seq: int
    input_epoch: int
    output_epoch: int
    permit_revision: int
    phase: Phase
    request_id: str | None
    sealed: bool
    active_grants: list[EffectView]
    presented_effects: list[EffectView]
    audio_progress: list[AudioProgressView]
    last_error: str | None
    last_error_diagnostic_id: DiagnosticId | None = None


class CreateSessionResponse(WireModel):
    session: SessionView
    session_token: str


class AuditEventView(WireModel):
    sequence: int
    kind: str
    state_revision: int
    output_epoch: int
    occurred_at: str


class HealthResponse(WireModel):
    status: Literal["ok"] = "ok"
    mode: Literal["mock", "replay", "rehearsal", "injected"] = "mock"
    schema_version: str = WIRE_VERSION
    live_llm: bool | None = False
    live_audio: bool | None = False
    live_images: bool = False


class ErrorResponse(WireModel):
    code: str
    message: str
    request_id: str


class DiagnosticsStatusResponse(WireModel):
    available: bool
    recording_active: bool
    notice: str
    dropped_events: int
    dropped_recordings: int
    io_failures: int
    pending_records: int


class ReviewedAudioRecordingRequest(WireModel):
    enabled: Annotated[bool, Field(strict=True)]
    consent: Annotated[bool, Field(strict=True)] = False


class ReviewedAudioStatusResponse(WireModel):
    scope: Literal["application"] = "application"
    recording_active: bool
    has_pending_audio: bool
    staged_bytes: Annotated[int, Field(ge=0)]
    max_audio_bytes: Annotated[int, Field(ge=2, le=512 * 1024)]
    expires_in_seconds: Annotated[float, Field(ge=0, le=60)]
    pending_stream_id: UUID | None = None
    pending_kind: Literal["audio_input", "audio_output"] | None = None
    input_completion_ready: bool
    notice: str
    scope_notice: str


class ReviewedAudioReviewResponse(WireModel):
    scope: Literal["application"] = "application"
    scope_notice: str
    review_id: Annotated[str, Field(pattern=r"^[a-f0-9]{32}$")]
    digest: Annotated[str, Field(pattern=r"^[a-f0-9]{64}$")]
    kind: Literal["audio_input", "audio_output"]
    sample_rate_hz: Literal[16000, 24000, 48000]
    byte_count: Annotated[int, Field(strict=True, ge=2, le=512 * 1024)]
    expires_in_seconds: Annotated[float, Field(ge=0, le=60)]
    preview_path: str
    notice: str


class ReviewedAudioConfirmRequest(WireModel):
    reviewed_digest: Annotated[str, Field(pattern=r"^[a-f0-9]{64}$")]
    review: Literal["approved", "rejected", "uncertain"]
    persist_consent: Annotated[bool, Field(strict=True)]


class ReviewedAudioActionResponse(WireModel):
    scope: Literal["application"] = "application"
    scope_notice: str
    ok: bool
    code: str
    message: str
    recording_active: bool
    accepted_for_queue: bool = False


class VoiceCapabilities(WireModel):
    generation_mode: Literal["mock", "replay", "rehearsal", "injected"]
    speech_enabled: bool
    microphone_enabled: bool
    speech_sample_rate_hz: Literal[24000] = 24000
    microphone_sample_rate_hz: Literal[16000] = 16000
    qualification: Literal["injected_unverified", "unavailable", "offline_fixture"]


class SpeechStreamRequest(WireModel):
    digest: Annotated[str, Field(pattern=r"^[a-f0-9]{64}$")]
    output_epoch: Annotated[int, Field(strict=True, ge=1)]
    activity_seq: Annotated[int, Field(strict=True, ge=1)]


class SpeechOriginView(WireModel):
    effect_id: str
    digest: str
    output_epoch: int
    activity_seq: int
    stream_id: str


class SpeechAudioFrame(SpeechOriginView):
    type: Literal["audio"] = "audio"
    sequence: int
    first_sample: int
    sample_rate_hz: Literal[24000] = 24000
    pcm_base64: str


class SpeechCompleteFrame(SpeechOriginView):
    type: Literal["complete"] = "complete"
    total_samples: int


class SpeechErrorFrame(SpeechOriginView):
    type: Literal["error"] = "error"
    code: str
    diagnostic_id: DiagnosticId | None = None


class MicrophoneStart(WireModel):
    type: Literal["start"]
    session_token: Annotated[str, Field(min_length=1, max_length=128, repr=False)]
    stream_id: UUID
    activity_seq: Annotated[int, Field(strict=True, ge=0)]
    input_epoch: Annotated[int, Field(strict=True, ge=0)]
    sample_rate_hz: Literal[16000]


class MicrophoneAudio(WireModel):
    type: Literal["audio"]
    sequence: Annotated[int, Field(strict=True, ge=1, le=6100)]
    first_sample: Annotated[int, Field(strict=True, ge=0, le=16000 * 60)]
    pcm_base64: Annotated[str, Field(min_length=4, max_length=16000)]


class MicrophoneControl(WireModel):
    type: Literal["finish", "cancel"]


class MicrophoneReady(WireModel):
    type: Literal["ready"] = "ready"
    stream_id: str
    activity_seq: int
    input_epoch: int


class MicrophoneTranscript(WireModel):
    type: Literal["transcript"] = "transcript"
    stream_id: str
    revision: int
    text: str
    is_final: bool


class MicrophoneComplete(WireModel):
    type: Literal["complete"] = "complete"
    stream_id: str
    revision: int
    text: str
    had_final: bool


class MicrophoneError(WireModel):
    type: Literal["error"] = "error"
    code: str
    diagnostic_id: DiagnosticId | None = None


# WebSocket/NDJSON models are exported with the HTTP schemas; no hand-written TS copy.
MEDIA_WIRE_MODELS = (SpeechAudioFrame, SpeechCompleteFrame, SpeechErrorFrame,
                     MicrophoneStart, MicrophoneAudio, MicrophoneControl, MicrophoneReady,
                     MicrophoneTranscript, MicrophoneComplete, MicrophoneError)
