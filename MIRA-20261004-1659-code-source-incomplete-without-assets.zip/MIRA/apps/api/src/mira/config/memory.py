"""Explicit private local-memory transmission configuration; no import-time IO.

This is separate from local recording consent. An operator must explicitly choose
the existing database/scope and allow its selected evidence to be sent to the
already admitted Codex generation and TypeSafe JEV review providers.
"""
from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass, field
from pathlib import Path

from mira.config.loader import ConfigurationError
from mira.domain.memory import MemoryScope

MAX_SCOPE_CONFIG_BYTES = 16_384


@dataclass(frozen=True, slots=True)
class MemoryRecallOptions:
    database: Path = field(repr=False)
    scope: MemoryScope = field(repr=False)
    scope_alias: str = field(repr=False)
    authorized_transmission: bool
    timeout_ms: int = 200
    max_packet_bytes: int = 8_192


def _private_existing_file(path: Path, *, label: str, checkout_root: Path) -> Path:
    if (not isinstance(path, Path) or not path.is_absolute() or ".." in path.parts
            or not isinstance(checkout_root, Path)):
        raise ConfigurationError(f"memory_{label}_path_invalid")
    try:
        lexical = Path(os.path.abspath(path))
        resolved = path.resolve(strict=True)
        root = checkout_root.resolve()
        if (lexical == root or root in lexical.parents
                or resolved == root or root in resolved.parents):
            raise ConfigurationError(f"memory_{label}_outside_checkout_required")
        # Check every link component, not only the final file.
        current = Path(path.anchor)
        for part in path.parts[1:]:
            current /= part
            component = current.lstat()
            if stat.S_ISLNK(component.st_mode):
                raise ConfigurationError(f"memory_{label}_not_private")
            if current != path:
                # A different user must not be able to replace the private leaf
                # directory through a writable ancestor. Root/owner sticky temp
                # directories are safe for owner-only children; arbitrary shared
                # non-sticky locations and foreign-owned ancestors are not.
                if (not stat.S_ISDIR(component.st_mode)
                        or component.st_uid not in {0, os.geteuid()}
                        or (stat.S_IMODE(component.st_mode) & 0o022
                            and not component.st_mode & stat.S_ISVTX)):
                    raise ConfigurationError(f"memory_{label}_not_private")
        info = path.lstat()
        parent = path.parent.lstat()
        if (resolved != lexical or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                or not stat.S_ISDIR(parent.st_mode) or not hasattr(os, "geteuid")
                or info.st_uid != os.geteuid() or parent.st_uid != os.geteuid()
                or stat.S_IMODE(info.st_mode) & 0o077
                or stat.S_IMODE(parent.st_mode) & 0o077):
            raise ConfigurationError(f"memory_{label}_not_private")
    except ConfigurationError:
        raise
    except (OSError, RuntimeError):
        raise ConfigurationError(f"memory_{label}_unavailable") from None
    return lexical


def _unique_object(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError("duplicate")
        obj[key] = value
    return obj


def _read_scope(path: Path, alias: str) -> MemoryScope:
    if type(alias) is not str or not alias or len(alias) > 64 or any(c.isspace() for c in alias):
        raise ConfigurationError("memory_scope_unavailable")
    descriptor = None
    try:
        before = path.lstat()
        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        info = os.fstat(descriptor)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1
                or (info.st_dev, info.st_ino) != (before.st_dev, before.st_ino)
                or info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) & 0o077):
            raise ConfigurationError("memory_scope_config_not_private")
        raw = os.read(descriptor, MAX_SCOPE_CONFIG_BYTES + 1)
        if not raw or len(raw) > MAX_SCOPE_CONFIG_BYTES:
            raise ValueError("size")
        document = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object,
                              parse_constant=lambda _: (_ for _ in ()).throw(ValueError("constant")))
        if (type(document) is not dict or set(document) != {"version", "scopes"}
                or type(document["version"]) is not int or document["version"] != 1
                or type(document["scopes"]) is not list or not 1 <= len(document["scopes"]) <= 32):
            raise ValueError("shape")
        result = None
        aliases = set()
        for row in document["scopes"]:
            if type(row) is not dict or set(row) != {"name", "user_id", "character_id", "world_id"}:
                raise ValueError("row")
            name = row["name"]
            if (type(name) is not str or not name or len(name) > 64
                    or any(c.isspace() for c in name) or name in aliases):
                raise ValueError("alias")
            aliases.add(name)
            scope = MemoryScope(row["user_id"], row["character_id"], row["world_id"])
            if name == alias:
                result = scope
        if result is None:
            raise ConfigurationError("memory_scope_unavailable")
        return result
    except ConfigurationError:
        raise
    except (OSError, UnicodeError, ValueError, TypeError, RecursionError):
        raise ConfigurationError("memory_scope_config_invalid") from None
    finally:
        if descriptor is not None:
            os.close(descriptor)


def load_memory_recall_options(*, database: Path, scope_config: Path, scope_alias: str,
                               authorized_transmission: bool, checkout_root: Path,
                               timeout_ms: int = 200,
                               max_packet_bytes: int = 8_192) -> MemoryRecallOptions:
    """Read bounded scope configuration only after separate transmission consent.

    The database is never opened here. Its schema and race-resistant filesystem
    identity are checked again by the read-only adapter during application startup.
    No scope ID or storage path is accepted from HTTP or model output.
    """
    if authorized_transmission is not True:
        raise ConfigurationError("memory_transmission_consent_required")
    if not hasattr(os, "geteuid"):
        raise ConfigurationError("memory_private_platform_unsupported")
    if (type(timeout_ms) is not int or not 10 <= timeout_ms <= 1_000
            or type(max_packet_bytes) is not int or not 1_024 <= max_packet_bytes <= 32_768):
        raise ConfigurationError("memory_limits_invalid")
    database = _private_existing_file(database, label="database", checkout_root=checkout_root)
    scope_config = _private_existing_file(scope_config, label="scope_config", checkout_root=checkout_root)
    scope = _read_scope(scope_config, scope_alias)
    return MemoryRecallOptions(database, scope, scope_alias, True, timeout_ms, max_packet_bytes)
