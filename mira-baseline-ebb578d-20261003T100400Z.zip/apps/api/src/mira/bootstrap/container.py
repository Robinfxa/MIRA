"""Composition root. No service locator, dynamic plugin loading, or global singleton."""
from dataclasses import dataclass

from mira.adapters.journal.memory import MemoryEventJournal
from mira.application.ports.journal import EventJournal
from mira.application.session_actor import RuntimeLimits, SessionActor
from mira.application.sessions import SessionRegistry
from mira.bootstrap.providers import Providers, create_providers
from mira.config.settings import Settings


@dataclass(frozen=True, slots=True)
class Container:
    settings: Settings
    sessions: SessionRegistry
    journal: EventJournal

    async def close(self) -> None:
        await self.sessions.close()


def build_container(settings: Settings, *, providers: Providers | None = None) -> Container:
    selected = providers or create_providers(settings.providers)
    journal = MemoryEventJournal(settings.runtime.journal_capacity)
    limits = RuntimeLimits(settings.runtime.timeout_seconds, settings.runtime.max_turns,
                           settings.runtime.max_effects)
    sessions = SessionRegistry(
        lambda state: SessionActor(state, selected.generation, selected.review, journal, limits),
        journal, settings.runtime.max_sessions,
    )
    return Container(settings, sessions, journal)
