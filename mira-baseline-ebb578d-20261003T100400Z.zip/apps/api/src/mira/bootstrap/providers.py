"""Explicit factories are the only place selecting concrete provider adapters."""
from dataclasses import dataclass

from mira.adapters.generation.mock import MockGenerationBackend
from mira.adapters.generation.replay.backend import ReplayGenerationBackend
from mira.adapters.generation.replay.script import ReplayScriptError, load_script
from mira.adapters.review.mock import FixtureReviewBackend
from mira.application.ports.generation import GenerationBackend
from mira.application.ports.review import ReviewBackend
from mira.config.loader import ConfigurationError
from mira.config.settings import ProviderSettings


@dataclass(frozen=True, slots=True)
class Providers:
    generation: GenerationBackend
    review: ReviewBackend


def create_providers(settings: ProviderSettings) -> Providers:
    if settings.generation not in {"mock", "replay"} or settings.review != "fixture":
        raise ConfigurationError(
            "Selected live backend is not implemented. No automatic Mock or paid-API fallback."
        )
    if settings.allow_external_calls or settings.allow_paid_api:
        raise ConfigurationError("Foundation profile does not enable external calls or paid APIs.")
    if settings.generation == "replay":
        try:
            script = load_script(settings.replay_scenario)
        except ReplayScriptError as error:
            raise ConfigurationError(str(error)) from None
        return Providers(ReplayGenerationBackend(script), FixtureReviewBackend())
    return Providers(MockGenerationBackend(settings.mock_delay_ms), FixtureReviewBackend())
