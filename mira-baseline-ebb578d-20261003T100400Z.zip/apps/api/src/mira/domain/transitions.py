"""Pure, replayable transitions for the foundation's *instant mock* effects.

This is not the complete G02/G04 wire or a sample-accurate audio implementation.
All future audio/video progress must extend, not reinterpret, Receipt.
"""
from dataclasses import replace

from mira.domain.errors import DomainError
from mira.domain.models import Effect, Fence, Phase, Receipt, SessionState


def _cutoff(state: SessionState, value: int) -> None:
    known = max((r.presentation_seq for r in state.receipts), default=0)
    previous = state.last_presentation_cutoff
    if value < max(known, previous):
        raise DomainError("invalid_cutoff", "Presentation cutoff cannot move backwards.")


def _fences_after_stop(state: SessionState, cutoff: int) -> tuple[Fence, ...]:
    # An empty branch has no receipts to validate. Do not retain an unbounded
    # collection of fences when a user repeatedly presses Stop.
    if any(effect.output_epoch == state.output_epoch for effect in state.issued_effects):
        return state.fences + (Fence(state.output_epoch, cutoff),)
    return state.fences


def begin_input(
    state: SessionState, *, activity_seq: int, cutoff: int, request_id: str, text: str
) -> SessionState:
    if activity_seq <= state.activity_seq:
        raise DomainError("stale_activity", "A new request needs a newer local activity.")
    _cutoff(state, cutoff)
    return replace(
        state, revision=state.revision + 1, activity_seq=activity_seq,
        input_epoch=state.input_epoch + 1, output_epoch=state.output_epoch + 1,
        permit_revision=state.permit_revision + 1, phase=Phase.THINKING,
        request_id=request_id, sealed=False, active_grants=(), last_error=None,
        fences=_fences_after_stop(state, cutoff), last_presentation_cutoff=cutoff,
        user_inputs=state.user_inputs + (text,),
    )


def stop(state: SessionState, *, activity_seq: int, cutoff: int) -> SessionState:
    # Retransmission does not produce a new transition or undo a later input.
    if activity_seq <= state.activity_seq:
        return state
    _cutoff(state, cutoff)
    return replace(
        state, revision=state.revision + 1, activity_seq=activity_seq,
        output_epoch=state.output_epoch + 1, permit_revision=state.permit_revision + 1,
        phase=Phase.STOPPED, request_id=None, active_grants=(), sealed=False,
        fences=_fences_after_stop(state, cutoff), last_presentation_cutoff=cutoff, last_error=None,
    )


def accept_range(
    state: SessionState, *, output_epoch: int, effects: tuple[Effect, ...]
) -> SessionState:
    if output_epoch != state.output_epoch or state.request_id is None or state.sealed:
        return state  # A late provider result cannot reopen a branch.
    if any(e.output_epoch != output_epoch or e.activity_seq != state.activity_seq for e in effects):
        raise DomainError("invalid_effect", "Effect origin does not match this branch.")
    ids = [e.id for e in state.issued_effects] + [e.id for e in effects]
    if len(ids) != len(set(ids)):
        raise DomainError("duplicate_effect", "An effect identity cannot be reused.")
    return replace(
        state, revision=state.revision + 1, permit_revision=state.permit_revision + 1,
        phase=Phase.READY, active_grants=state.active_grants + effects,
        issued_effects=state.issued_effects + effects,
    )


def seal(state: SessionState, *, output_epoch: int) -> SessionState:
    if output_epoch != state.output_epoch or state.request_id is None:
        return state
    received = {r.effect_id for r in state.receipts}
    finished = all(e.id in received for e in state.active_grants)
    return replace(state, revision=state.revision + 1, sealed=True,
                   phase=Phase.IDLE if finished else Phase.READY)


def fail(state: SessionState, *, output_epoch: int, code: str) -> SessionState:
    if output_epoch != state.output_epoch or state.request_id is None:
        return state
    return replace(state, revision=state.revision + 1,
                   permit_revision=state.permit_revision + 1, phase=Phase.ERROR,
                   active_grants=(), request_id=None, last_error=code)


def record_receipt(state: SessionState, receipt: Receipt) -> SessionState:
    effect = next((e for e in state.issued_effects if e.id == receipt.effect_id), None)
    if effect is None:
        raise DomainError("unknown_effect", "Receipt has no issued effect.")
    if (effect.digest, effect.output_epoch, effect.activity_seq) != (
        receipt.digest, receipt.output_epoch, receipt.activity_seq
    ):
        raise DomainError("receipt_mismatch", "Receipt identity differs from the issued effect.")
    previous = next((r for r in state.receipts if r.effect_id == receipt.effect_id), None)
    if previous is not None:
        if previous == receipt:
            return state
        raise DomainError("receipt_conflict", "A presentation cannot be rewritten.")
    if receipt.presentation_seq <= 0 or any(
        r.presentation_seq == receipt.presentation_seq for r in state.receipts
    ):
        raise DomainError("receipt_sequence", "Presentation sequence must identify one effect.")
    fence = next((f for f in state.fences if f.output_epoch == effect.output_epoch), None)
    if fence is not None and receipt.presentation_seq > fence.presentation_cutoff:
        raise DomainError("after_stop_fence", "Old receipt claims presentation after its stop fence.")
    # An old valid receipt only adds history; it does not alter grants or restart the phase.
    receipts = state.receipts + (receipt,)
    phase = state.phase
    received = {r.effect_id for r in receipts}
    if state.sealed and state.request_id is not None and all(
        e.id in received for e in state.active_grants
    ):
        phase = Phase.IDLE
    return replace(state, revision=state.revision + 1, receipts=receipts, phase=phase)
