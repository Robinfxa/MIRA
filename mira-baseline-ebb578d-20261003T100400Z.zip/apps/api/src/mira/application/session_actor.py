"""One state writer per session. Provider waits never hold the transition lock.

This is a small application coordinator, not a general actor/FSM framework.
All transitions are synchronous while the lock is held. The in-memory journal
is deliberately nonblocking; durable state/outbox is a separate WP05 migration.
"""
import asyncio
from dataclasses import dataclass, replace
from datetime import UTC, datetime

from mira.application.compiler import compile_range
from mira.application.contracts import AuditEvent, GenerationContext, ReviewVerdict
from mira.application.ports.generation import GenerationBackend
from mira.application.ports.journal import EventJournal
from mira.application.ports.review import ReviewBackend
from mira.domain import transitions
from mira.domain.errors import DomainError
from mira.domain.models import Receipt, SessionState


@dataclass(frozen=True, slots=True)
class RuntimeLimits:
    timeout_seconds: float
    max_turns: int
    max_effects: int


class SessionActor:
    def __init__(self, state: SessionState, generation: GenerationBackend,
                 review: ReviewBackend, journal: EventJournal, limits: RuntimeLimits) -> None:
        self._state = state
        self._generation = generation
        self._review = review
        self._journal = journal
        self._limits = limits
        self._lock = asyncio.Lock()
        self._tasks: set[asyncio.Task[None]] = set()
        self._request_fingerprints: dict[str, tuple[int, int, str]] = {}
        self._closed = False

    def _commit(self, state: SessionState, kind: str) -> None:
        if state is self._state:
            return
        self._state = state
        self._journal.append(AuditEvent(
            sequence=state.revision, session_id=state.session_id, kind=kind,
            state_revision=state.revision, output_epoch=state.output_epoch,
            occurred_at=datetime.now(UTC).isoformat(),
        ))

    async def snapshot(self) -> SessionState:
        async with self._lock:
            return self._state

    def _cancel_tasks(self) -> None:
        for task in tuple(self._tasks):
            task.cancel()

    async def submit(self, *, request_id: str, activity_seq: int,
                     cutoff: int, text: str) -> SessionState:
        async with self._lock:
            if self._closed:
                raise DomainError("session_closed", "Session has closed.")
            fingerprint = (activity_seq, cutoff, text)
            previous = self._request_fingerprints.get(request_id)
            if previous is not None:
                if previous != fingerprint:
                    raise DomainError("request_conflict", "Request ID was reused with different data.")
                return self._state
            if len(self._request_fingerprints) >= self._limits.max_turns:
                raise DomainError("session_capacity", "Foundation turn budget reached; create a new session.")
            # Cancellation-resistant providers are not allowed to create an unbounded task set.
            if len(self._tasks) >= 4:
                raise DomainError("busy", "Previous work is still terminating.")
            state = transitions.begin_input(self._state, activity_seq=activity_seq,
                                             cutoff=cutoff, request_id=request_id, text=text)
            self._cancel_tasks()
            self._request_fingerprints[request_id] = fingerprint
            self._commit(state, "input_committed")
            context = GenerationContext(text, state.user_inputs, state.presented_effects,
                                        state.output_epoch)
            task = asyncio.create_task(self._generate(context, activity_seq))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
            return state

    async def stop(self, *, activity_seq: int, cutoff: int) -> SessionState:
        async with self._lock:
            state = transitions.stop(self._state, activity_seq=activity_seq, cutoff=cutoff)
            if state is not self._state:
                self._cancel_tasks()
                self._commit(state, "stopped")
            return self._state

    async def receipt(self, receipt: Receipt) -> SessionState:
        async with self._lock:
            self._commit(transitions.record_receipt(self._state, receipt), "receipt_recorded")
            return self._state

    async def _generate(self, context: GenerationContext, activity_seq: int) -> None:
        try:
            async with asyncio.timeout(self._limits.timeout_seconds):
                count = 0
                async for candidate in self._generation.generate(context):
                    async with self._lock:
                        if self._closed or self._state.output_epoch != context.output_epoch:
                            return
                        review_context = replace(context, accepted_prefix=self._state.active_grants,
                                                 presented_effects=self._state.presented_effects)
                    observation = await self._review.review(review_context, candidate)
                    if observation.verdict != ReviewVerdict.ALLOW:
                        raise DomainError("review_not_allowed", "Candidate did not pass review.")
                    effects = compile_range(candidate, epoch=context.output_epoch, activity=activity_seq)
                    async with self._lock:
                        if self._closed or self._state.output_epoch != context.output_epoch:
                            return
                        if len(self._state.issued_effects) + len(effects) > self._limits.max_effects:
                            raise DomainError("effect_capacity", "Foundation effect budget reached.")
                        self._commit(transitions.accept_range(
                            self._state, output_epoch=context.output_epoch, effects=effects
                        ), "range_accepted")
                        count += 1
                if not count:
                    raise DomainError("empty_generation", "Provider returned no complete range.")
                async with self._lock:
                    self._commit(transitions.seal(self._state, output_epoch=context.output_epoch),
                                 "plan_sealed")
        except asyncio.CancelledError:
            # Local stop owns invalidation. Cancellation is not natural PlanEnd.
            raise
        except Exception as error:
            code = error.code if isinstance(error, DomainError) else (
                "generation_timeout" if isinstance(error, TimeoutError) else "generation_failed"
            )
            async with self._lock:
                self._commit(transitions.fail(self._state, output_epoch=context.output_epoch,
                                              code=code), "generation_failed")

    async def close(self) -> None:
        async with self._lock:
            self._closed = True
            self._cancel_tasks()
            tasks = tuple(self._tasks)
        if tasks:
            await asyncio.wait(tasks, timeout=1.0)
