"""Wire v0.1.0-foundation; deliberately NOT the full voice-v0.2 protocol.

Canonical public schemas live here. Generated OpenAPI/TypeScript are read-only.
"""
from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from mira.domain.models import EffectKind, Phase

WIRE_VERSION = "0.1.0-foundation"


class WireModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class CreateSessionRequest(WireModel):
    client_instance_id: UUID


class InputRequest(WireModel):
    request_id: UUID
    activity_seq: Annotated[int, Field(strict=True, ge=1)]
    presentation_cutoff: Annotated[int, Field(strict=True, ge=0)]
    text: Annotated[str, Field(min_length=1, max_length=2000, pattern=r"\S")]


class StopRequest(WireModel):
    activity_seq: Annotated[int, Field(strict=True, ge=1)]
    presentation_cutoff: Annotated[int, Field(strict=True, ge=0)]


class ReceiptRequest(WireModel):
    effect_id: UUID
    digest: Annotated[str, Field(pattern=r"^[a-f0-9]{64}$")]
    output_epoch: Annotated[int, Field(strict=True, ge=1)]
    activity_seq: Annotated[int, Field(strict=True, ge=1)]
    presentation_seq: Annotated[int, Field(strict=True, ge=1)]


class EffectView(WireModel):
    id: str
    kind: EffectKind
    value: str
    digest: str
    output_epoch: int
    activity_seq: int


class SessionView(WireModel):
    schema_version: Literal["0.1.0-foundation"] = WIRE_VERSION
    session_id: str
    client_instance_id: str
    revision: int
    activity_seq: int
    input_epoch: int
    output_epoch: int
    permit_revision: int
    phase: Phase
    request_id: str | None
    sealed: bool
    active_grants: list[EffectView]
    presented_effects: list[EffectView]
    last_error: str | None


class CreateSessionResponse(WireModel):
    session: SessionView
    session_token: str


class AuditEventView(WireModel):
    sequence: int
    kind: str
    state_revision: int
    output_epoch: int
    occurred_at: str


class HealthResponse(WireModel):
    status: Literal["ok"] = "ok"
    mode: Literal["mock"] = "mock"
    schema_version: str = WIRE_VERSION
    live_llm: bool = False
    live_audio: bool = False
    live_images: bool = False


class ErrorResponse(WireModel):
    code: str
    message: str
    request_id: str
