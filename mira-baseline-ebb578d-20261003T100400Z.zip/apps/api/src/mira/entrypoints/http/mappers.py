from dataclasses import asdict

from mira.domain.models import SessionState
from mira.entrypoints.http.schemas import EffectView, SessionView


def session_view(state: SessionState) -> SessionView:
    return SessionView(
        session_id=state.session_id, client_instance_id=state.client_instance_id,
        revision=state.revision, activity_seq=state.activity_seq, input_epoch=state.input_epoch,
        output_epoch=state.output_epoch, permit_revision=state.permit_revision,
        phase=state.phase, request_id=state.request_id, sealed=state.sealed,
        active_grants=[EffectView(**asdict(e)) for e in state.active_grants],
        presented_effects=[EffectView(**asdict(e)) for e in state.presented_effects],
        last_error=state.last_error,
    )
