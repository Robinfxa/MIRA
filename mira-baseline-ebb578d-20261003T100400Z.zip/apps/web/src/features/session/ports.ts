import type { CreateSessionResponse, InputRequest, ReceiptRequest, SessionView, StopRequest } from '../../shared/generated/contracts.js';

/** The session use case depends on this port, not fetch or a specific transport. */
export interface SessionTransport {
  create(clientInstanceId: string): Promise<CreateSessionResponse>;
  snapshot(): Promise<SessionView>;
  input(request: InputRequest): Promise<SessionView>;
  stop(request: StopRequest): Promise<SessionView>;
  receipt(request: ReceiptRequest): Promise<SessionView>;
  close(): Promise<void>;
}
