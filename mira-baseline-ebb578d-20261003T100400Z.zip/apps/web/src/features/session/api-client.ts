import type { PublicConfig } from '../../shared/config.js';
import type { CreateSessionResponse, InputRequest, ReceiptRequest, SessionView, StopRequest } from '../../shared/generated/contracts.js';
import { parseCreated, parseSession } from '../../shared/protocol.js';

import type { SessionTransport } from './ports.js';

export class MiraApiClient implements SessionTransport {
  private sessionId: string | null = null;
  private token: string | null = null;
  constructor(private readonly config: PublicConfig) {}

  private async request<T>(path: string, method: string, body: unknown,
                           parse: (raw: unknown) => T): Promise<T> {
    const response = await fetch(this.config.apiBase + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(this.token ? { 'X-Mira-Session-Token': this.token } : {}) },
      body: body === undefined ? null : JSON.stringify(body),
      signal: AbortSignal.timeout(5000),
      cache: 'no-store',
    });
    if (!response.ok) throw new Error(`Request failed (${response.status}); local output stays blocked.`);
    return parse(await response.json());
  }

  async create(clientInstanceId: string): Promise<CreateSessionResponse> {
    const created = await this.request('/sessions', 'POST', { client_instance_id: clientInstanceId }, parseCreated);
    this.sessionId = created.session.session_id;
    this.token = created.session_token; // In memory only; no localStorage, URL or logs.
    return created;
  }
  private path(suffix = ''): string {
    if (!this.sessionId) throw new Error('Session not connected');
    return `/sessions/${this.sessionId}${suffix}`;
  }
  snapshot(): Promise<SessionView> { return this.request(this.path(), 'GET', undefined, parseSession); }
  input(body: InputRequest): Promise<SessionView> { return this.request(this.path('/inputs'), 'POST', body, parseSession); }
  stop(body: StopRequest): Promise<SessionView> { return this.request(this.path('/stop'), 'POST', body, parseSession); }
  receipt(body: ReceiptRequest): Promise<SessionView> { return this.request(this.path('/receipts'), 'POST', body, parseSession); }
  async close(): Promise<void> {
    if (this.sessionId && this.token) {
      await fetch(this.config.apiBase + this.path(), {
        method: 'DELETE', headers: { 'X-Mira-Session-Token': this.token }, keepalive: true,
      });
    }
    this.sessionId = null;
    this.token = null;
  }
}
