import type { PublicConfig } from '../../shared/config.js';
import type { SessionView } from '../../shared/generated/contracts.js';
import type { EffectExecutor } from '../presentation/ports.js';
import { PresentationGate } from '../presentation/permit-gate.js';
import type { SessionTransport } from './ports.js';

export interface SessionViewPort {
  connected(): void;
  update(view: SessionView): void;
  error(message: string): void;
  localStop(): void;
}

export class SessionController {
  private gate: PresentationGate | null = null;
  private running = false;
  constructor(private readonly api: SessionTransport, private readonly effects: EffectExecutor,
              private readonly view: SessionViewPort, private readonly config: PublicConfig) {}

  async connect(): Promise<void> {
    const clientId = crypto.randomUUID();
    const created = await this.api.create(clientId);
    this.gate = new PresentationGate(created.session.session_id, clientId);
    this.running = true;
    this.view.connected();
    this.install(created.session);
    void this.poll();
  }
  private install(snapshot: SessionView): void {
    const gate = this.gate;
    if (!gate || !gate.install(snapshot)) return;
    if (snapshot.activity_seq !== gate.currentActivity()) return;
    this.view.update(snapshot);
    for (const effect of snapshot.active_grants) {
      if (!gate.allows(effect)) continue;
      try {
        this.effects.apply(effect);
        // Foundation evidence is a DOM-applied receipt, not proof of GPU/audio output.
        const receipt = gate.consume(effect);
        if (receipt) void this.api.receipt(receipt).catch(error => this.report(error));
      } catch (error) { gate.block(); this.report(error); }
    }
  }
  async input(text: string): Promise<void> {
    if (!this.gate || !text.trim()) return;
    const id = crypto.randomUUID();
    const basis = this.gate.beginInput(id);
    this.effects.prepareInput();
    try { this.install(await this.api.input({ ...basis, request_id: id, text })); }
    catch (error) { if (this.gate.currentActivity() === basis.activity_seq) this.report(error); }
  }
  async stop(): Promise<void> {
    if (!this.gate) return;
    const basis = this.gate.stop(); // local latch first, network second
    this.effects.stop();
    this.view.localStop();
    try { this.install(await this.api.stop(basis)); }
    catch (error) { this.report(error); }
  }
  private async poll(): Promise<void> {
    while (this.running) {
      try {
        const snapshot = await this.api.snapshot();
        if (this.running) this.install(snapshot);
      } catch (error) { this.gate?.block(); this.report(error); }
      await new Promise(resolve => setTimeout(resolve, this.config.pollIntervalMs));
    }
  }
  private report(error: unknown): void {
    this.view.error(error instanceof Error ? error.message : 'Transport unavailable');
  }
  async close(): Promise<void> {
    this.running = false;
    this.gate?.block();
    await this.api.close();
  }
}
