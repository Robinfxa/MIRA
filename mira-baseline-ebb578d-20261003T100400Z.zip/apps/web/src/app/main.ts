import { loadPublicConfig } from '../shared/config.js';
import { DomEffectExecutor } from '../features/presentation/dom-executor.js';
import { MiraApiClient } from '../features/session/api-client.js';
import { SessionController } from '../features/session/controller.js';

function element<T extends HTMLElement>(selector: string): T {
  const value = document.querySelector<T>(selector);
  if (!value) throw new Error(`Missing application element ${selector}`);
  return value;
}
const config = loadPublicConfig();
const status = element('[data-status]');
const diagnostic = element('[data-diagnostic]');
const error = element('[data-error]');
const controller = new SessionController(
  new MiraApiClient(config), new DomEffectExecutor(element('[data-stage]')), {
    connected() { element<HTMLFieldSetElement>('fieldset').disabled = false; },
    update(view) {
      status.textContent = view.phase;
      diagnostic.textContent = JSON.stringify({
        state: view.revision, activity: view.activity_seq, output: view.output_epoch,
        permit: view.permit_revision, grants: view.active_grants.length,
        presented: view.presented_effects.length, sealed: view.sealed,
      }, null, 2);
      if (view.last_error) error.textContent = view.last_error;
    },
    error(message) { error.textContent = message; },
    localStop() { status.textContent = 'stopped · 本地已制止'; },
  }, config,
);

element<HTMLFormElement>('form').addEventListener('submit', event => {
  event.preventDefault();
  const input = element<HTMLInputElement>('[name=message]');
  error.textContent = '';
  void controller.input(input.value);
  input.value = '';
});
element('[data-stop]').addEventListener('click', () => { void controller.stop(); });
for (const button of document.querySelectorAll<HTMLButtonElement>('[data-command]')) {
  button.addEventListener('click', () => {
    error.textContent = '';
    void controller.input(button.dataset.command ?? '');
  });
}
element('[data-close]').addEventListener('click', () => {
  element<HTMLFieldSetElement>('fieldset').disabled = true;
  void controller.close().then(() => { status.textContent = 'closed · 刷新可新建'; });
});
window.addEventListener('pagehide', () => { void controller.close(); });
void controller.connect().catch(value => { error.textContent = String(value); });
