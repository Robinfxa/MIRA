"""ENV-02: the approved MVP provider matrix is explicit and fail-closed."""
from pathlib import Path

import pytest
from pydantic import ValidationError

from mira.config.loader import load_settings
from mira.config.service_settings import SpeechSettings
from tools.api_environment import inspect_services

ROOT = Path(__file__).resolve().parents[2]


def load_dev(**overrides):
    return load_settings(root=ROOT, environ={"MIRA_PROFILE": "development"}, overrides=overrides)


def test_development_profile_freezes_openai_family_and_google_speech_matrix():
    settings = load_dev()
    assert settings.services.routes.text == "codex_native"
    assert settings.services.routes.image == "codex_native"
    assert settings.services.routes.vision == "codex_native"
    assert settings.services.speech.asr_provider == "google_cloud"
    assert settings.services.speech.tts_provider == "google_cloud"


def test_review_route_remains_jev_and_is_not_silently_folded_into_main_llm():
    report = inspect_services(load_dev())
    assert report["capabilities"]["review"]["route"] == "jev"


def test_speech_report_comes_from_typed_provider_fields():
    report = inspect_services(load_dev())
    assert report["capabilities"]["asr"]["route"] == "google_cloud_stt_v2"
    assert report["capabilities"]["tts"]["route"] == "google_cloud_tts"


def test_google_speech_provider_is_currently_intentional_not_arbitrary_string():
    with pytest.raises(ValidationError):
        SpeechSettings(asr_provider="other")
    with pytest.raises(ValidationError):
        SpeechSettings(tts_provider="other")


def test_openai_api_stays_explicit_alternative_not_automatic_fallback():
    settings = load_dev(services={"routes": {"text": "openai_api", "image": "openai_api", "vision": "openai_api"}})
    report = inspect_services(settings)
    assert report["capabilities"]["text"]["route"] == "openai_api"
    assert report["capabilities"]["image"]["route"] == "openai_api"
    assert report["capabilities"]["vision"]["route"] == "openai_api"
    assert not settings.providers.allow_paid_api
    assert report["live_ready"] is False
