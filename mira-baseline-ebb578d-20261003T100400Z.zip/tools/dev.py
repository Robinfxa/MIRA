"""One command to build the static workbench and serve the local mock API.

Uses an existing environment when the required packages are available; otherwise
creates an isolated .venv via bootstrap. Does not invoke any model or media API.
"""
import argparse
import importlib.util
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-bootstrap", action="store_true")
    args = parser.parse_args()
    environment_python = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    current_ready = all(importlib.util.find_spec(name) for name in ["fastapi", "pydantic", "uvicorn", "dotenv"])
    compiler = ROOT / "node_modules/typescript/bin/tsc"
    tsc = str(compiler) if compiler.is_file() else shutil.which("tsc")
    if not (environment_python.is_file() or current_ready) or tsc is None:
        if args.no_bootstrap:
            raise SystemExit("Missing dependencies. Run python tools/bootstrap.py first.")
        subprocess.run([sys.executable, str(ROOT / "tools/bootstrap.py")], cwd=ROOT, check=True)
        tsc = str(compiler)
    python = str(environment_python) if environment_python.is_file() else sys.executable
    subprocess.run([python, str(ROOT / "tools/export_contracts.py"), "--check"], cwd=ROOT, check=True)
    command = ["node", tsc] if compiler.is_file() else [tsc]
    subprocess.run([*command, "-p", "apps/web/tsconfig.json"], cwd=ROOT, check=True)
    env = dict(os.environ)
    env["PYTHONPATH"] = str(ROOT / "apps/api/src")
    print("MIRA: fixed fixtures only (mock/replay); listening address comes from validated root config.", flush=True)
    try:
        subprocess.run([python, "-m", "mira"], cwd=ROOT, env=env, check=True)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
