# MIRA 当前云环境基线报告

- 执行日期：2026-10-03 UTC；本次证据窗口 09:02:50–09:05:30。
- 范围：当前共享工程的依赖准备、现有离线检查；不是功能开发 RED/GREEN，不是原始 164 条产品验收。
- 结论：**环境阻塞，不能宣称完整基线通过。** 官方 PyPI/npm 域名解析失败；pytest 与 TypeScript 编译器缺失。现有运行时的合同检查另发现 Python 版本相关描述差异。
- 源码在本次检查前后未变化；没有改生产代码、测试、规格、配置或生成合同。
- 唯一证据目录：[baseline-20261003T090250Z-09dfad3d](../../var/mission/baseline-20261003T090250Z-09dfad3d/)。原始 stdout、stderr、实际命令、退出码和时间分别留档；没有覆盖旧运行记录。
- 质量 runner 收据：[summary.json](../../var/quality/baseline-selected-930246bdd77048889b04fd5431c397b4/summary.json)。

## 已读与安全边界

已读 AGENTS.md、README、CONTRIBUTING、50-hour-delivery、ENV-01 handoff、API_ENV、TESTING、TDD-SDD、tests/quality.toml、声明锁文件及 check/quality_plan/quality_run/check_web/check_specs/export_contracts 实现；进一步检查了配置 loader、HTTP app/composition 和相关合成测试子进程。

未运行自动 bootstrap/dev 脚本、API 环境初始化、元数据探针、模型/API、真实音视频、服务登录或外部产品请求。未读取根 .env、认证缓存或私人凭据。离线测试使用最小无凭据环境，HOME/TMPDIR 指向证据目录。质量 runner 对公开 .env 模板作摘要；env 相关测试未执行。依赖准备使用经授权的官方 PyPI/npm，未尝试绕过网络限制。npm 生命周期脚本禁用；未做全局安装。

## 运行时与依赖

| 项目 | 实际环境 | 声明/说明 |
|---|---|---|
| 主 Python | 3.12.14 | 满足 pyproject 的 >=3.11,<3.14；与 .python-version 3.13 和原锁实测 3.13.5 不同 |
| 系统 Python | 3.13.5 | pytest 及主要应用依赖同样缺失 |
| Node.js | 24.19.0 | 满足 package.json >=22.12.0；.node-version 为 22.16.0 |
| npm | 11.9.0 | 已存在 |
| TypeScript | 缺失 | 锁定 5.8.3；无项目安装和全局 tsc |
| Python 开发锁 | 25 个声明分发包 | 主运行时 7 个版本匹配、12 个版本不同、6 个缺失 |

缺失：coverage、iniconfig、pluggy、pytest、pytest-asyncio、pytest-cov。
关键不匹配包括 FastAPI 0.141.1（锁 0.128.2）、Starlette 1.6.0（锁 0.50.0）、uvicorn 0.52.1（锁 0.48.0）。完整版本证据见 [environment-inventory.json](../../var/mission/baseline-20261003T090250Z-09dfad3d/environment-inventory.json)。

已创建项目 .venv（Python 3.12.14，创建命令退出 0），但依赖安装失败。该 .venv **不是可用开发环境**；不得因为目录存在就宣称准备完成。npm 未成功安装任何依赖。

## 实际命令与结果

下表中的 python 指主运行时 /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python。JSON 收据保存了完整 argv，包括全部安装隔离、网络超时、输出路径参数。

| 检查 | 命令摘要 | 退出码 | 实际结论 |
|---|---|---:|---|
| 创建隔离环境 | python -m venv .venv | 0 | 只完成空环境准备 |
| 精确 Python 锁安装 | .venv/bin/python -m pip --isolated install --index-url https://pypi.org/simple --retries 0 --timeout 15 -r requirements/dev.lock | 1 | 首个 annotated-doc 下载发现失败；后续诊断确认 DNS 错误，不是证明版本不存在 |
| PyPI 定位 | .venv/bin/python -m pip --isolated index versions annotated-doc --index-url https://pypi.org/simple --retries 0 --timeout 15 -vv | 1 | pypi.org: Temporary failure in name resolution |
| npm 首次准备 | npm ci --ignore-scripts … | 1 | 本次操作错误：userconfig/globalconfig 同为 /dev/null；未发起下载 |
| npm 更正重试 | npm ci --ignore-scripts --registry=https://registry.npmjs.org … | 1 | 两个独立空配置文件；registry.npmjs.org: EAI_AGAIN |
| 块目录 | python tools/check.py --list | 0 | 12 块已列出，不代表执行 |
| full 计划 | python tools/check.py --full --plan | 0 | 目录/owner/选择计划有效，不代表执行 |
| Python 收集 | python -m pytest --collect-only -q -p no:cacheprovider | 1 | No module named pytest；未收集任何 node |
| 只读合同检查 | python tools/export_contracts.py --check | 1 | openapi.json 描述漂移，见下一节；没有生成或覆盖文件 |
| 选定块 | python tools/check.py --lane architecture providers web --jobs 2 --output-dir <唯一目录> | 1 | architecture/providers 缺 pytest；web 缺 tsc；三块均 failed |
| 纯架构断言 | python -c "runpy…" | 0 | 直接调用 5 个现有纯架构检查函数；不是 pytest lane 通过 |

直接调用通过的函数：
- test_domain_has_no_framework_config_or_adapter_dependencies
- test_application_never_imports_adapters_bootstrap_or_transport
- test_environment_reads_only_in_configuration_loader
- test_provider_construction_only_in_composition_root
- test_reference_test_catalogue_not_marked_passed

完整命令、结果与源码快照见 [checks-summary.json](../../var/mission/baseline-20261003T090250Z-09dfad3d/checks-summary.json)、source-before.json、source-after.json。前后 changed_during_checks=[]；quality runner 的 changed_during_run=[]。未将收集/依赖失败当作功能 TDD RED，也未把这 5 次直接断言混入 pytest 通过数量。

## 合同差异定位

[只读差异](../../var/mission/baseline-20261003T090250Z-09dfad3d/contracts-diff.stdout.txt) 只有 8 处 HTTP 422 的 description：已提交 “Unprocessable Content”，当前运行时 “Unprocessable Entity”。派生 TypeScript 文本完全相同。

当前 FastAPI 的 openapi/utils.py 从 http.client.responses 取得附加响应的默认描述。实测主 Python 3.12 的 http.client.responses[422] 是 “Unprocessable Entity”，系统 Python 3.13 为 “Unprocessable Content”，与提交文件吻合。此证据支持 Python 版本导致文本漂移；精确锁依赖下尚未复验，不能进一步宣称全部版本组合已验证。

**不要为适配未锁定的 3.12 环境而覆盖生成合同。** 优先恢复 Python 3.13 的锁定开发环境后重跑；若继续声称支持 3.11–3.13，应由集成负责人决定是否为合同导出明确固定响应描述并补测试。

## 明确未执行

- pytest：0 个测试成功执行；没有当前 fresh 的 181/其他 Python 总通过数。
- Node 测试：0 个执行；没有继承 README 的 20 通过结论。
- full/release：not_run。full 是依赖阻塞；release 的 package/smoke 不属于本次已执行范围。
- 未选择块：domain、env、config、actor、http、tooling、specs、package、smoke，全部 not_run。
- 浏览器/真机/实际音频、外部服务/账号/真实模型、远端 CI、原 164 条产品验收：not_run。
- 模块 import 无环境/网络副作用的完整现有 architecture 测试未执行；不能由 5 个静态断言替代。

## 最小恢复路线

1. 在支持官方 PyPI/npm 访问的受准入环境恢复 registry DNS/网络能力，或由集成负责人提供经批准、来源已验证的离线锁定包；不绕过当前网络限制。
2. 优先使用 Python 3.13 的项目隔离环境安装现有 requirements/dev.lock，使用 npm ci --ignore-scripts 安装现有 TypeScript 锁；不要全局安装或静默改锁。
3. 在稳定源码快照上先运行 collection、只读合同和 architecture/providers/web，再按唯一集成时隙执行一次 full；保持固定输出目录和真实退出码。
4. 当前报告只证明环境与基线阻塞，不等于实现代码失败。实现可继续并行准备，但收口应等待可执行的锁定测试环境。
