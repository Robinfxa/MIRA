# MIRA source checkpoint

Imported foundation baseline. Original source snapshot was verified locally with 245 Python and 20 Node tests. Public projection excludes private/nonessential artifacts and has not been rerun as a full release.

Source import commit: `ebb578dde665c9c7269e4a64b508182680b2fa66`.

Captured at 2026-10-03 10:04 UTC. The working-tree checkpoint was captured under a coordinated write freeze and all source hashes matched before/after capture. Files in this public projection are byte-identical to the captured source unless listed as publication metadata.

Excluded from capture: private `.env` files, credentials/auth stores, runtime state, dependency folders, Git internals, and caches. Blank public environment templates are included. The public projection additionally omits raw source PDFs, historical document copies/screenshots, raw logs, and files containing machine-specific private paths. See `publication-exclusions.json`.

No deployment or merge is implied. No paid fallback or live-provider verification is claimed. Future stages should be uploaded as non-force, separately verifiable commits.
