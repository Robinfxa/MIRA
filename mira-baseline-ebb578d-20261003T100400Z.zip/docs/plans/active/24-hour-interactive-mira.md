# MIRA 24 小时交付阶段

## 目标与边界

本阶段从 2026-10-03 08:53:50 UTC 起，截止 2026-10-04 08:53:50 UTC。这是用户最新明确窗口，替代本次执行沿用旧 50 小时计划的时间推算；旧计划保留为历史参考。

在已提供 foundation v0.4.1 上交付移动端优先的原创成年角色互动场景。必须区分真实能力、固定演示、离线自动检查与未执行的账户/设备验收。所有开发在本云端工程完成。

优先级已更新：先打通受支持的 ChatGPT/Codex 登录额度路径和真实语音接入，再形成完整互动体验。STT 为 Google Speech-to-Text V2；TTS 为用户最新指定的 gemini-3.8-flash-tts。JEV/TypeSafe 的输入/输出判断职责保留。不得静默改用收费 OpenAI API、其他语音模型或浏览器 TTS 作为真实路线。

## 事实与决策引用

- 用户最终需求 PDF：6 页候选需求；提取验收见 docs/mission/requirements-and-acceptance.md。
- 基础工程与现状：README.md、AGENTS.md、docs/handoff/ENV-01.md、docs/development/API_ENV.md。
- 现有行为约束：docs/reference/architecture-v0.6/docs/architecture/modules/01–10 与对应 ADR。
- 当前任务直接采用已有 specs/features 与 docs/changes 的规格体系，不引入并行 OpenSpec 账本。
- 现有 provider matrix 在语音型号和认证承载方面只作为历史基线；上述用户最新选择优先。实际支持路径必须经官方文档与受控实测核实。

## 切片与依赖

1. 身份与服务就绪：受支持订阅登录、Google 两项语音端点/授权/型号、JEV 接入条件；安全登录和账户权限由用户确认。能力分别验收，不能相互代偿。
2. 场景与资产：原创角色、响应式场景、四态、至少三种表情与两种非说话动作、环境变化和内容触发视觉事件。独立于服务认证并行开发。
3. 可取消输入/呈现：单一音频播放主控，麦克风明确按住说话/点击输入，许可检查、本地 stop 优先、旧回调不复活、真实呈现回执与保留事实。
4. 服务适配：独立 ports/adapters 下接入已核实且被授权的文本、语音与判断能力；真实/fixture 路线显式区分，未知与失败关闭放行。
5. 集成与历史：输入→生成→审核→许可→实际呈现→回执→中断→后续多轮。共享合同由集成人串行修改。
6. 交付：无密钥同协议演示、启动流程、故障负控、桌面/移动视口检查、实际可录制的 3–5 分钟演示、README、AI_USAGE、测试与已知限制、授权的 Robinfxa/MIRA 上传。

## 文件所有权

集成人唯一修改：HTTP schemas、domain 模型与转换、application contracts/compiler/session actor、bootstrap、config loader、generated 合同导出、tests/quality.toml。

表现实现拥有独立的场景 renderer、公开原创资产及其测试；语音实现拥有独立音频/录音模块与测试。session/controller、presentation/ports、permit-gate、app/main 的写入由集成人明确分配后串行整合。并行不意味着允许重叠写入或用变化中的快照证明验证通过。

## 验证与收口

定向 RED→GREEN 优先；多个独立结果可以汇总后集中做 affected 集成。测试运行期间继续不冲突的开发，已验证源码必须用快照/摘要对应证据。全量与发布尾检只在集成候选上运行；不得以忙碌或文档数量代替进展。

每个阶段记录真实命令、退出码、日志、源码/输入标识以及未覆盖范围。原 164 条历史用例不自动标为通过。真实麦克风/音频、账户推理与最终录屏均需独立实测；模拟与 DOM 回执不得冒充它们。

## 当前阻断

- 云端 PyPI/npm 域名解析失败，锁版本 pytest 与 TypeScript 尚未安装；现有 runtime 检查不能证明完整锁环境通过。
- 登录授权、Google 身份与预算、JEV 权限尚未完成实测；代码实现不构成真实能力就绪。

## 退出条件

需求映射、源码、可复现启动、可执行测试与演示证据齐备，未完成项明确。授权 GitHub 目的地为 Robinfxa/MIRA；上传前检查密钥/私密数据与准确能力说明。截止前保留充足的集成、失败修复与交付时间，不以新增低优先级功能挤占收口。
