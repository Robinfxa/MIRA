# MIRA current acceptance boundaries — 2026-10-04 08:37 UTC

This is a capture-time source/evidence record. Final checks performed after capture are reported in the matching delivery START-HERE; they supersede pending wording here without rewriting frozen source. The0810 source/public release passed all12 lanes (1,690 Python tests plus8 subtests,274 Node,package/smoke), restored852 files exactly, and its seven-file archive was remotely verified at d57d6995479e0338474ea07bdbc7cd4054825b50. Expanded repository code remains older; use the matching restore pack.

The current later slice only improves known configuration-error startup diagnostics and local-session-capacity recovery text. Independent installed-entry and bounded HTTP-transport checks passed; its own full release is still separate. No model policy, budget, service authorization or frame semantics changed.

Normal text generation/review sealed subtitle+pose grants without presentation. Synthetic audio completed STT and generation/review but correctly stopped as UNKNOWN before TTS. Separately, fixed production TTS yielded3.24 seconds of complete PCM with1.274-second dispatch-to-first-PCM timing and no playback. See [exact provider evidence](PROVIDER-EVIDENCE-20261004.md); none is a human device test.

## PDF core requirements

| Item | Implemented or actual evidence | Still unaccepted |
|---|---|---|
| PDF-01 continuous 3–5 min session | Interactive scene, text/voice seams and offline rehearsal exist. | No human-recorded continuous live session. |
| PDF-02 scene is visual focus | Pixi full-frame adult character and scene integration in source. | No human browser/phone pixels checked. |
| PDF-03 background, character, captions, text and voice entry | UI and controls implemented; rehearsal supports fixed text. | Real-browser controls not user-verified; rehearsal input is simulated. |
| PDF-04 mobile-first and desktop | Responsive rules and 390×844 checklist exist. | No real-phone/Safari check; narrow desktop is only emulation. |
| PDF-05 idle/listen/think/speak states | Phase labels and character mappings with software tests. | User-perceived distinctions unverified; rehearsal listen is simulated. |
| PDF-06 text chat | One native Luna text probe sealed after 4 JEV 200 checks in 6.332s, with subtitle+pose grants. | Zero presentation receipts; no user-visible continuous live text session. |
| PDF-07 real microphone | Capture/PTT path exists. | No human microphone/device input accepted. 07:29 synthetic-audio STT probe is not a user mic. |
| PDF-08 audible speech + matching subtitle | Offline cue subtitles and 8 prerecorded synthetic English Flite/slt clips (~52.56s total); historical TTS produced one complete 3.4s Chinese PCM artifact. | Independent production TTS succeeded; human playback/audibility/subtitle and natural whole-session checks remain open. 07:29 probe did not call TTS. |
| PDF-09 multi-turn continuity | Finite rehearsal steps and scene state exist. | No continuous human live multi-turn session. |
| PDF-10 interrupt by starting new speech | PTT/capture and software stop paths exist. | No real new-speech interruption while audible playback is occurring. |
| PDF-11 stop sound immediately | Local-first stop code/tests. | No physical acoustic tail measurement. |
| PDF-12 cancel/invalidate reply | Software cancellation/stale-result tests. | No human live-provider delay/interrupt result. |
| PDF-13 block pending caption/action/media | Gate and stale-callback tests. | No live browser/audio/media observation. |
| PDF-14 return to listen and handle new input | UI phases and PTT path exist. | Real microphone continuation after interruption untested. |
| PDF-15 late/rapid replies never revive | Race/cancellation tests. | No user-observed real-service race. |
| PDF-16 clear interrupt gesture/reason | README explains hold-to-talk/Stop. | User understanding of live control untested. |
| PDF-17 structured effects drive image | Sealed text probe granted subtitle and look-at-rain pose. | That probe presented zero effects; no human-observed live effect. |
| PDF-18 ≥3 expressions | 12 Pixi action×expression frames include 4 expressions; mapping tests. | No human browser/phone visual check. |
| PDF-19 ≥2 non-speaking actions | Camera-lowered and look-at-rain states are implemented. | Actual pixels/legibility unverified. |
| PDF-20 environment change | Rain/window and warm-light commands exist with tests. | Human visual observation pending. |
| PDF-21 content-driven visual event | Fixed photo event is tied to approved interaction; gate tests exist. | No live presented browser event verified. |
| PDF-22 one multimodal branch | Selected branch: Pixi character CSS motion plus state-driven12 full frames, with animated SVG fallback. Idle/listening/speaking compositor motion has no mouth-sync; software integration is accepted on0810, actual browser perception remains open. | Browser/GPU/phone/user perception still open. |
| PDF-23 video lifecycle | Video branch not selected. | N/A for selected animation branch. |
| PDF-24 generated-media lifecycle | Runtime generated media not selected. | N/A for selected animation branch. |
| PDF-25 page→server→model | One Luna+JEV text probe sealed permits in 6.332s, no presentation. | No successful user-visible live loop. **07:29 separately source-bound probe:** a 4.66-second synthetic English audio input produced the exact 79-character transcript. Native generation and four JEV HTTP 200 responses followed; final review returned UNKNOWN because o1/o2 confidence was .58/.55 (<.6). No TTS, playback or presentation; this was not a transport failure. |
| PDF-26 failure/recovery | `/fail`, error handling, and offline fallback have software tests. | No human live timeout/network/audio/media recovery accepted. |
| PDF-27 no-key demo | Fixed offline rehearsal is explicitly labeled and makes no provider calls. | User-run human browser/speaker observation remains to be recorded. |
| PDF-28 sources/secrets | `THIRD_PARTY.md`, asset notes, templates and secret exclusion are present. | Audit the final exact delivery bundle before release. |

## PDF delivery items

| Item | State | Needed to close |
|---|---|---|
| PDF-D01 source | **Verified0810 archive backup available:**852 files, source/public12-lane release and exact restore passed; remote commitd57d6997. Expanded repository code remains older. The subsequent small error-usability fixes need their own matching release. | Publish exact current source with matching three-part code/assets bundle and pair its ID with the video. |
| PDF-D02 startup route | **Documented:** matching restore manifests/helpers ship beside, not inside, each three-part source pack. | Verify the same-stage pack and instructions from a new destination. |
| PDF-D03 ≤15-minute clean start | **Not run** on the user's clean machine. Earlier ~3s was server-ready after dependencies existed. | Time restore, locked install, server-ready, browser open separately; record OS and tool versions. |
| PDF-D04 3–5-minute video | **Not run; no video file.** | User records an actual playable 3–5-minute take with interaction, changes, audible interruption, Pixi branch, and failure/recovery. |
| PDF-D05 README | **Present:** README links this current matrix and labels the older device checklist historical; elapsed calendar time is not human labor. | Keep the final stage and actual release result current; do not claim measured labor hours. |
| PDF-D06 AI_USAGE.md | **Present/candid:** AI work, examples, and no human acceptance recorded. | Add only actual human device/browser observations after run. |
| PDF-D07 gap disclosure | **Present:** README lists open browser, phone, audio, mic, live session and recording. | Update with observed results and next steps. |

## Current closing conditions

1. The new frozen stage must pass its own full source/public release and restore checks before publication. Existing05:43 is a usable, explicitly dated no-key rehearsal; it is not the latest semantic-policy code.
2. Use one matching delivery's manifest/helper and all three ZIPs. Sidecars ship beside the ZIPs; a source tree does not contain its own self-referential archive manifest. Do not mix stages or hand-edit checksums.
3. Human browser/device acceptance and an actual 3–5-minute recording remain open. Follow [the recording guide](../development/DEMO-RECORDING.md). Software state, an ASGI response, or a permit does not prove human perception. Never bypass a browser/network access restriction.

The07:17 failed receipt is retained: Python/spec lanes passed; web build refused its in-project artifact path; package/smoke were not run. The repair moves disposable web output outside the project, preserving the guard. Read the matching delivery START-HERE for the subsequent full release result. Older DEVICE-ACCEPTANCE and19:27 reports remain historical.
