# Architecture coverage: stable0952 and the next memory slice

Status reviewed2026-10-04 12:07 UTC. This is a source/spec comparison, not a claim that the whole architecture book is complete. The0952 source/archive is immutable and is the version currently recommended for device testing. Later memory work is a separate candidate until it passes its own integration and delivery checks.

| Module | Existing implemented slice | Important remaining scope |
| --- | --- | --- |
| M01 state/authority | In-process Actor, revisions, epochs, grants, receipts and bounded diagnostic journal | Durable Actor source-event/outbox/state recovery and restart-safe causal history |
| M02 decisions/contract | Typed decision snapshots, JEV input/output gates, fixed author policy, versioned uncertainty handling | Complete memory/disclosure provenance in the shared generation/review context |
| M03 plan/completion | Compiled candidate ranges/effects and accepted-prefix control | Rich authored storylet/OpenIntent lifecycle and memory-backed planning |
| M04 permits/interruption | Local-first Stop, stale-output fences, permit validation, receipt-prefix barriers | Durable recovery across process loss and full authored scene/intent continuation |
| M05 voice | Real STT/TTS adapters, software capture/playback/cancellation, component provider evidence | Human microphone/speaker/browser acceptance and a continuous natural voice session |
| M06 character/memory/scene | Fixed typed AuthorPolicy, original adult character,12 Pixi frames, scene/receipt lifecycle, session-local history | Cross-session conversational memory, full Canon/LearnedStance, storylet memory and controlled dynamic-media review |
| M07 failure/routines | Bounded timeouts, structured errors, UNKNOWN system notice, capacity and recovery paths | Authored recurring-scene/routine subsystem; no generic scheduler is claimed |
| M08 evaluation/delivery | Layered tests, exact manifests, source/public releases, install/restore checks | Real3–5 minute recording, phone/browser interaction and natural-language quality evaluation |
| M09 provider/auth/usage | Explicit native Codex, Google and JEV adapters; scoped real-call receipts and budgets | Portable user-environment acceptance, integrated generated-image plus direct-image-review path |
| M10 reuse/integration | Layered ports/adapters/bootstrap, locked dependencies and notices | Remaining memory/outbox/story/media integrations described by the book |

## What “memory” means in0952

`adapters/journal/memory.py` contains a bounded, transient diagnostic deque. Its port explicitly says it is not a durable transaction log. `SessionState.user_inputs`, receipts and audio progress support continuity inside the current process/session; they do not survive a new process as an application memory database. Separately, `mira26_author_policy()` supplies typed fixed character facts and allowed controls. These are useful existing pieces, but neither is a full long-term persona or memory system.

## Bounded next-stage target

The next candidate now implements a local, explicit-consent evidence store and local operator workflow: source/version/scope labels, persistence across restart, correction/supersession, reversible soft forgetting, provenance-aware bounded recall and a structured context packet. It uses local SQLite rather than creating an external memory account. Defaults do not record actual conversations. Recalled text is untrusted data and does not grant actions, override current permissions or prove that a proposed action happened. The CLI cannot fabricate presentation receipts.

This target does **not** claim automatic ingestion from the Actor, automatic cross-session model recall, personality learning, Hindsight integration or completed shared story state. Those require their own reliable source-event production, matching generation/review projection, explicit privacy configuration and tests. The test results and exact implemented subset will be recorded in the next matching delivery, without rewriting0952 evidence.

Primary architecture references: [M01](../reference/architecture-v0.6/docs/architecture/modules/01-state-and-authority.md), [M06](../reference/architecture-v0.6/docs/architecture/modules/06-character-memory-and-scene.md), [M10](../reference/architecture-v0.6/docs/architecture/modules/10-reuse-integration-and-work-packages.md). Device and PDF acceptance remain in [CURRENT-ACCEPTANCE](CURRENT-ACCEPTANCE.md).

Focused implementation evidence:43 combined architecture/store/CLI/subprocess tests passed on stable source, plus12 independent synthetic safety controls. The actual CLI opens a real SQLite store across separate processes; it is not a mocked persistence demonstration. Full candidate release and publication remain separately recorded in the corresponding delivery. Mac platform pin compatibility is also included in that next candidate, with no actual Mac runtime claim.
