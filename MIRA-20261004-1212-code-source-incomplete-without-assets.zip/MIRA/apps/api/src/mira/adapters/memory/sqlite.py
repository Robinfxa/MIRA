"""Opt-in, synchronous SQLite evidence store with explicit private-file checks.

The default application never constructs this adapter. Call ``open()`` only
after an explicit local workflow chooses to use it. Data is retained in a
bounded append-only ledger; ``forget`` suppresses records but does not erase
their original text from the local database.
"""

from __future__ import annotations

import os
import re
import sqlite3
import stat
import time
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from unicodedata import name as unicode_name
from uuid import uuid4

from mira.adapters.diagnostics.privacy import PrivacyFilter
from mira.adapters.memory.errors import (
    MemoryConflictError,
    MemoryDeadlineExceededError,
    MemoryEntryNotFoundError,
    MemoryPrivacyError,
    MemoryResultTooLargeError,
    MemoryStoreClosedError,
    MemoryStoreError,
    MemoryStoreFullError,
    UnknownMemoryDatabaseError,
    UnsafeMemoryPathError,
)
from mira.application.ports.memory import MemoryPort
from mira.domain.memory import (
    MemoryEntry,
    MemoryHistoryItem,
    MemoryKind,
    MemoryMutation,
    MemoryMutationKind,
    MemoryQuery,
    MemoryScope,
    MemorySource,
)

_APPLICATION_ID = int.from_bytes(b"MIRA", "big")
_SCHEMA_VERSION = 1
_MAX_CURRENT_BOUNDARIES = 64
_MAX_CURRENT_BOUNDARY_CHARS = 32_768
_QUERY_TERMS = re.compile(r"[^\W_]+", re.UNICODE)
_TABLES = {
    "memory_entries": {
        "id", "user_id", "character_id", "world_id", "source", "kind", "text",
        "source_event_id", "source_version", "recorded_at", "supersedes_id",
    },
    "memory_links": {
        "memory_id", "user_id", "character_id", "world_id", "ancestor_id", "relation",
    },
    "memory_mutations": {
        "id", "user_id", "character_id", "world_id", "kind", "target_entry_id",
        "reverses_id", "recorded_at",
    },
    "memory_history": {
        "seq", "event_id", "user_id", "character_id", "world_id", "event_kind",
        "recorded_at",
    },
}

_CREATE_SCHEMA = (
    """CREATE TABLE memory_entries (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        character_id TEXT NOT NULL,
        world_id TEXT NOT NULL,
        source TEXT NOT NULL,
        kind TEXT NOT NULL,
        text TEXT NOT NULL,
        source_event_id TEXT NOT NULL,
        source_version INTEGER NOT NULL CHECK(source_version > 0),
        recorded_at TEXT NOT NULL,
        supersedes_id TEXT,
        UNIQUE(id, user_id, character_id, world_id),
        UNIQUE(user_id, character_id, world_id, source_event_id, source_version),
        FOREIGN KEY(supersedes_id, user_id, character_id, world_id)
            REFERENCES memory_entries(id, user_id, character_id, world_id)
    )""",
    """CREATE TABLE memory_links (
        memory_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        character_id TEXT NOT NULL,
        world_id TEXT NOT NULL,
        ancestor_id TEXT NOT NULL,
        relation TEXT NOT NULL CHECK(relation IN ('supersedes', 'depends_on')),
        PRIMARY KEY(memory_id, ancestor_id, relation),
        FOREIGN KEY(memory_id, user_id, character_id, world_id)
            REFERENCES memory_entries(id, user_id, character_id, world_id),
        FOREIGN KEY(ancestor_id, user_id, character_id, world_id)
            REFERENCES memory_entries(id, user_id, character_id, world_id)
    )""",
    """CREATE TABLE memory_mutations (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        character_id TEXT NOT NULL,
        world_id TEXT NOT NULL,
        kind TEXT NOT NULL CHECK(kind IN ('forget', 'restore')),
        target_entry_id TEXT NOT NULL,
        reverses_id TEXT,
        recorded_at TEXT NOT NULL,
        UNIQUE(id, user_id, character_id, world_id),
        FOREIGN KEY(target_entry_id, user_id, character_id, world_id)
            REFERENCES memory_entries(id, user_id, character_id, world_id),
        FOREIGN KEY(reverses_id, user_id, character_id, world_id)
            REFERENCES memory_mutations(id, user_id, character_id, world_id)
    )""",
    """CREATE TABLE memory_history (
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        event_id TEXT NOT NULL UNIQUE,
        user_id TEXT NOT NULL,
        character_id TEXT NOT NULL,
        world_id TEXT NOT NULL,
        event_kind TEXT NOT NULL CHECK(event_kind IN ('entry', 'forget', 'restore')),
        recorded_at TEXT NOT NULL
    )""",
    "CREATE INDEX memory_entries_scope ON memory_entries(user_id, character_id, world_id, kind)",
    "CREATE INDEX memory_links_scope_ancestor ON memory_links(user_id, character_id, world_id, ancestor_id)",
    "CREATE INDEX memory_mutations_scope_target ON memory_mutations(user_id, character_id, world_id, target_entry_id)",
    "CREATE INDEX memory_history_scope_seq ON memory_history(user_id, character_id, world_id, seq)",
    "CREATE UNIQUE INDEX memory_one_restore_per_forget ON memory_mutations(reverses_id) WHERE kind='restore'",
)


def _scope_values(scope: MemoryScope) -> tuple[str, str, str]:
    if not isinstance(scope, MemoryScope):
        raise ValueError("an explicit MemoryScope is required")
    return scope.user_id, scope.character_id, scope.world_id


def _time_text(value: str | None) -> str:
    if value is None:
        value = datetime.now(UTC).isoformat(timespec="microseconds")
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("memory timestamp must include a timezone")
    return parsed.astimezone(UTC).isoformat(timespec="microseconds")


def _parse_time(value: str) -> str:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("invalid stored memory timestamp")
    return parsed.astimezone(UTC).isoformat(timespec="microseconds")


def _cjk_term(term: str) -> bool:
    return any("CJK" in unicode_name(char, "") for char in term)


def _tokens(value: str) -> set[str]:
    return {part.casefold() for part in _QUERY_TERMS.findall(value)}


class SQLiteMemoryStore(MemoryPort):
    """Bounded, owner-private SQLite evidence store; constructor performs no I/O."""

    def __init__(
        self,
        path: str | os.PathLike[str],
        *,
        max_records: int = 2_048,
        max_entry_chars: int = 4_096,
    ) -> None:
        self.path = Path(path)
        if not self.path.is_absolute() or ".." in self.path.parts:
            raise ValueError("memory path must be absolute and normalized")
        if (isinstance(max_records, bool) or not isinstance(max_records, int)
                or not 1 <= max_records <= 10_000):
            raise ValueError("max_records must be an integer between 1 and 10000")
        if (isinstance(max_entry_chars, bool) or not isinstance(max_entry_chars, int)
                or not 128 <= max_entry_chars <= 16_384):
            raise ValueError("max_entry_chars must be an integer between 128 and 16384")
        self.max_records = max_records
        self.max_entry_chars = max_entry_chars
        self.max_events = max_records * 3
        self._connection: sqlite3.Connection | None = None

    def open(self) -> SQLiteMemoryStore:
        if self._connection is not None:
            return self
        self._ensure_private_parent()
        created = False
        try:
            try:
                os.lstat(self.path)
            except FileNotFoundError:
                flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
                flags |= getattr(os, "O_NOFOLLOW", 0)
                descriptor = os.open(self.path, flags, 0o600)
                os.close(descriptor)
                created = True
            self._check_private_regular_file(self.path, expected_mode=0o600)
            for suffix in ("-journal", "-wal", "-shm"):
                sidecar = Path(str(self.path) + suffix)
                if os.path.lexists(sidecar):
                    self._check_private_regular_file(sidecar, expected_mode=0o600)

            if not created:
                self._verify_existing_database()

            connection = sqlite3.connect(
                str(self.path), timeout=0.1, isolation_level=None, check_same_thread=True
            )
            connection.row_factory = sqlite3.Row
            try:
                connection.execute("PRAGMA busy_timeout=100")
                connection.execute("PRAGMA foreign_keys=ON")
                connection.execute("PRAGMA trusted_schema=OFF")
                connection.execute("PRAGMA journal_mode=DELETE")
                connection.execute("PRAGMA synchronous=FULL")
                page_count = int(connection.execute("PRAGMA page_count").fetchone()[0])
                page_size = int(connection.execute("PRAGMA page_size").fetchone()[0])
                max_pages = max(1, (64 * 1024 * 1024) // page_size)
                if page_count > max_pages:
                    raise MemoryStoreFullError("local memory database exceeds its storage bound")
                connection.execute(f"PRAGMA max_page_count={max_pages}")
                if created:
                    connection.execute("BEGIN IMMEDIATE")
                    try:
                        for statement in _CREATE_SCHEMA:
                            connection.execute(statement)
                        connection.execute(f"PRAGMA application_id={_APPLICATION_ID}")
                        connection.execute(f"PRAGMA user_version={_SCHEMA_VERSION}")
                        connection.execute("COMMIT")
                    except Exception:
                        connection.execute("ROLLBACK")
                        raise
                self._check_private_regular_file(self.path, expected_mode=0o600)
                self._connection = connection
            except Exception:
                connection.close()
                raise
            return self
        except (UnsafeMemoryPathError, UnknownMemoryDatabaseError, MemoryStoreFullError):
            raise
        except OSError:
            raise UnsafeMemoryPathError("unsafe local memory path") from None
        except sqlite3.Error:
            raise UnknownMemoryDatabaseError("local memory database is unavailable") from None

    def _ensure_private_parent(self) -> None:
        current = Path(self.path.anchor)
        parts = self.path.parts[1:-1]
        euid = getattr(os, "geteuid", lambda: None)()
        for index, part in enumerate(parts):
            current = current / part
            try:
                info = os.lstat(current)
            except FileNotFoundError:
                try:
                    os.mkdir(current, 0o700)
                except FileExistsError:
                    pass
                info = os.lstat(current)
            if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode):
                raise UnsafeMemoryPathError("unsafe local memory path")
            if info.st_mode & 0o022 and not info.st_mode & stat.S_ISVTX:
                raise UnsafeMemoryPathError("unsafe local memory path")
            if euid is not None and index == len(parts) - 1 and info.st_uid != euid:
                raise UnsafeMemoryPathError("unsafe local memory path")
            if index == len(parts) - 1 and stat.S_IMODE(info.st_mode) != 0o700:
                raise UnsafeMemoryPathError("unsafe local memory path")
        if not parts:
            raise UnsafeMemoryPathError("unsafe local memory path")

    @staticmethod
    def _check_private_regular_file(path: Path, *, expected_mode: int) -> None:
        try:
            info = os.lstat(path)
        except OSError:
            raise UnsafeMemoryPathError("unsafe local memory path") from None
        euid = getattr(os, "geteuid", lambda: None)()
        if (stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode)
                or euid is not None and info.st_uid != euid
                or info.st_nlink != 1
                or stat.S_IMODE(info.st_mode) != expected_mode):
            raise UnsafeMemoryPathError("unsafe local memory path")

    def _verify_existing_database(self) -> None:
        try:
            uri = self.path.as_uri() + "?mode=ro"
            connection = sqlite3.connect(uri, uri=True, timeout=0.1)
            try:
                app_id = int(connection.execute("PRAGMA application_id").fetchone()[0])
                version = int(connection.execute("PRAGMA user_version").fetchone()[0])
                if app_id != _APPLICATION_ID or version != _SCHEMA_VERSION:
                    raise UnknownMemoryDatabaseError("unrecognized local memory database")
                actual_tables = {
                    row[0] for row in connection.execute(
                        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
                }
                if actual_tables != set(_TABLES):
                    raise UnknownMemoryDatabaseError("unrecognized local memory database")
                for table, columns in _TABLES.items():
                    actual_columns = {
                        row[1] for row in connection.execute(f"PRAGMA table_info({table})")
                    }
                    if actual_columns != columns:
                        raise UnknownMemoryDatabaseError("unrecognized local memory database")
                check = connection.execute("PRAGMA quick_check(1)").fetchone()
                if check is None or check[0] != "ok":
                    raise UnknownMemoryDatabaseError("unrecognized local memory database")
            finally:
                connection.close()
        except UnknownMemoryDatabaseError:
            raise
        except sqlite3.Error:
            raise UnknownMemoryDatabaseError("unrecognized local memory database") from None

    def close(self) -> None:
        connection, self._connection = self._connection, None
        if connection is not None:
            connection.close()

    def __enter__(self) -> SQLiteMemoryStore:
        return self.open()

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        self.close()

    def _db(self) -> sqlite3.Connection:
        if self._connection is None:
            raise MemoryStoreClosedError("local memory store is not open")
        return self._connection

    def scope_revision(self, scope: MemoryScope) -> int:
        """Return the latest append-only history sequence within this exact scope."""
        connection = self._db()
        row = connection.execute(
            """SELECT coalesce(max(seq),0) FROM memory_history
               WHERE user_id=? AND character_id=? AND world_id=?""",
            _scope_values(scope),
        ).fetchone()
        return int(row[0])

    def _check_events_capacity(self, connection: sqlite3.Connection) -> None:
        events = int(connection.execute("SELECT count(*) FROM memory_history").fetchone()[0])
        if events >= self.max_events:
            raise MemoryStoreFullError("local memory event history reached its configured bound")

    def _check_records_capacity(self, connection: sqlite3.Connection) -> None:
        records = int(connection.execute("SELECT count(*) FROM memory_entries").fetchone()[0])
        if records >= self.max_records:
            raise MemoryStoreFullError("local memory reached its configured record bound")

    def _privacy_check(self, entry: MemoryEntry) -> None:
        if len(entry.text) > self.max_entry_chars:
            raise MemoryStoreFullError("memory entry exceeds its configured text bound")
        try:
            filtered = PrivacyFilter().text(entry.text)
        except Exception:
            raise MemoryPrivacyError("memory text is ineligible for private storage") from None
        if filtered != entry.text:
            raise MemoryPrivacyError("memory text is ineligible for private storage")

    def append(self, entry: MemoryEntry) -> MemoryEntry:
        connection = self._db()
        if not isinstance(entry, MemoryEntry):
            raise ValueError("a typed MemoryEntry is required")
        if entry.recorded_at is None:
            entry = replace(entry, recorded_at=_time_text(None))
        self._privacy_check(entry)
        if entry.kind is MemoryKind.BOUNDARY and entry.source is not MemorySource.USER_STATEMENT:
            raise ValueError("BOUNDARY entries require the user_statement source")
        try:
            connection.execute("BEGIN IMMEDIATE")
            existing = self._find_source_key(connection, entry)
            if existing is not None:
                if self._same_payload(existing, entry):
                    connection.execute("COMMIT")
                    return existing
                raise MemoryConflictError("source event version already has a different memory record")
            self._check_records_capacity(connection)
            self._check_events_capacity(connection)
            if connection.execute("SELECT 1 FROM memory_entries WHERE id=?", (entry.id,)).fetchone():
                raise MemoryConflictError("memory entry ID already exists")
            prior_version = connection.execute(
                """SELECT id,source_version,source FROM memory_entries
                   WHERE user_id=? AND character_id=? AND world_id=? AND source_event_id=?
                   ORDER BY source_version DESC LIMIT 1""",
                (*_scope_values(entry.scope), entry.source_event_id),
            ).fetchone()
            if prior_version is not None:
                if (entry.source_version != int(prior_version["source_version"]) + 1
                        or entry.supersedes_id != prior_version["id"]
                        or entry.source.value != prior_version["source"]):
                    raise MemoryConflictError(
                        "a new source-event version must supersede its prior version"
                    )
            suppressed, _ = self._suppression_state(connection, entry.scope)
            if entry.supersedes_id is not None:
                parent = self._get_entry(connection, entry.scope, entry.supersedes_id)
                if parent is None:
                    raise MemoryEntryNotFoundError("superseded entry was not found in this scope")
                if self._has_superseder(connection, entry.scope, parent.id):
                    raise MemoryConflictError("only the current correction head can be superseded")
                if parent.id in suppressed:
                    raise MemoryConflictError("suppressed memory cannot be superseded")
                if entry.kind is not parent.kind:
                    raise ValueError("supersession preserves the original memory kind")
                if entry.source is not parent.source:
                    raise MemoryConflictError("a correction cannot change its source authority")
            for ancestor_id in entry.depends_on:
                ancestor = self._get_entry(connection, entry.scope, ancestor_id)
                if ancestor is None:
                    raise MemoryEntryNotFoundError("dependent source was not found in this scope")
                if ancestor_id in suppressed:
                    raise MemoryConflictError("suppressed memory cannot support a new derivation")
            self._insert_entry(connection, entry)
            connection.execute("COMMIT")
            return entry
        except (MemoryStoreError, ValueError):
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except sqlite3.Error as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            if "full" in str(exc).casefold():
                raise MemoryStoreFullError("local memory reached its storage bound") from None
            raise MemoryStoreError("local memory operation failed") from None

    @staticmethod
    def _same_payload(existing: MemoryEntry, candidate: MemoryEntry) -> bool:
        return (
            existing.scope == candidate.scope
            and existing.source is candidate.source
            and existing.text == candidate.text
            and existing.source_event_id == candidate.source_event_id
            and existing.source_version == candidate.source_version
            and existing.kind is candidate.kind
            and existing.supersedes_id == candidate.supersedes_id
            and existing.depends_on == candidate.depends_on
        )

    def _find_source_key(
        self, connection: sqlite3.Connection, entry: MemoryEntry
    ) -> MemoryEntry | None:
        values = (*_scope_values(entry.scope), entry.source_event_id, entry.source_version)
        row = connection.execute(
            """SELECT * FROM memory_entries
               WHERE user_id=? AND character_id=? AND world_id=?
                 AND source_event_id=? AND source_version=?""",
            values,
        ).fetchone()
        return self._row_entry(row) if row is not None else None

    def _insert_entry(self, connection: sqlite3.Connection, entry: MemoryEntry) -> None:
        scope_values = _scope_values(entry.scope)
        connection.execute(
            """INSERT INTO memory_entries(
                 id,user_id,character_id,world_id,source,kind,text,source_event_id,
                 source_version,recorded_at,supersedes_id)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (entry.id, *scope_values, entry.source.value, entry.kind.value, entry.text,
             entry.source_event_id, entry.source_version, _time_text(entry.recorded_at),
             entry.supersedes_id),
        )
        if entry.supersedes_id is not None:
            connection.execute(
                """INSERT INTO memory_links(memory_id,user_id,character_id,world_id,ancestor_id,relation)
                   VALUES(?,?,?,?,?,'supersedes')""",
                (entry.id, *scope_values, entry.supersedes_id),
            )
        for ancestor_id in entry.depends_on:
            connection.execute(
                """INSERT INTO memory_links(memory_id,user_id,character_id,world_id,ancestor_id,relation)
                   VALUES(?,?,?,?,?,'depends_on')""",
                (entry.id, *scope_values, ancestor_id),
            )
        connection.execute(
            """INSERT INTO memory_history(event_id,user_id,character_id,world_id,event_kind,recorded_at)
               VALUES(?,?,?,?, 'entry', ?)""",
            (entry.id, *scope_values, _time_text(entry.recorded_at)),
        )

    def supersede(
        self, scope: MemoryScope, old_id: str, replacement: MemoryEntry
    ) -> MemoryEntry:
        if not isinstance(replacement, MemoryEntry) or replacement.scope != scope:
            raise ValueError("replacement must belong to the requested scope")
        old_id = str(old_id)
        connection = self._db()
        old = self._get_entry(connection, scope, old_id)
        if old is None:
            raise MemoryEntryNotFoundError("superseded entry was not found in this scope")
        candidate = replace(replacement, supersedes_id=old.id, kind=old.kind)
        return self.append(candidate)

    def _get_entry(
        self, connection: sqlite3.Connection, scope: MemoryScope, entry_id: str
    ) -> MemoryEntry | None:
        row = connection.execute(
            """SELECT * FROM memory_entries
               WHERE id=? AND user_id=? AND character_id=? AND world_id=?""",
            (entry_id, *_scope_values(scope)),
        ).fetchone()
        return self._row_entry(row) if row is not None else None

    def _has_superseder(
        self, connection: sqlite3.Connection, scope: MemoryScope, entry_id: str
    ) -> bool:
        return connection.execute(
            """SELECT 1 FROM memory_links WHERE ancestor_id=? AND relation='supersedes'
               AND user_id=? AND character_id=? AND world_id=? LIMIT 1""",
            (entry_id, *_scope_values(scope)),
        ).fetchone() is not None

    def _suppression_state(
        self, connection: sqlite3.Connection, scope: MemoryScope,
        deadline: float | None = None,
    ) -> tuple[set[str], list[MemoryMutation]]:
        values = _scope_values(scope)
        mutations = [self._row_mutation(row) for row in connection.execute(
            """SELECT * FROM memory_mutations
               WHERE user_id=? AND character_id=? AND world_id=? ORDER BY rowid""",
            values,
        )]
        restored = {item.reverses_id for item in mutations
                    if item.kind is MemoryMutationKind.RESTORE}
        active = [item for item in mutations
                  if item.kind is MemoryMutationKind.FORGET and item.id not in restored]
        children: dict[str, set[str]] = {}
        for child, ancestor in connection.execute(
            """SELECT memory_id,ancestor_id FROM memory_links
               WHERE user_id=? AND character_id=? AND world_id=? AND relation='depends_on'""",
            values,
        ):
            children.setdefault(ancestor, set()).add(child)
        suppressed = {item.target_entry_id for item in active}
        stack = list(suppressed)
        while stack:
            if deadline is not None and time.monotonic() >= deadline:
                raise MemoryDeadlineExceededError("local memory query exceeded its time bound")
            parent_id = stack.pop()
            for child_id in children.get(parent_id, ()):
                if child_id not in suppressed:
                    suppressed.add(child_id)
                    stack.append(child_id)
        return suppressed, mutations

    def _snapshot(
        self, connection: sqlite3.Connection, scope: MemoryScope,
        deadline: float | None = None,
    ) -> tuple[tuple[MemoryEntry, ...], dict[str, MemoryEntry], set[str]]:
        rows = connection.execute(
            """SELECT * FROM memory_entries
               WHERE user_id=? AND character_id=? AND world_id=?""",
            _scope_values(scope),
        ).fetchall()
        links = connection.execute(
            """SELECT memory_id,ancestor_id,relation FROM memory_links
               WHERE user_id=? AND character_id=? AND world_id=?""",
            _scope_values(scope),
        ).fetchall()
        dependencies: dict[str, list[str]] = {}
        superseded: set[str] = set()
        for link in links:
            if deadline is not None and time.monotonic() >= deadline:
                raise MemoryDeadlineExceededError("local memory query exceeded its time bound")
            if link["relation"] == "depends_on":
                dependencies.setdefault(link["memory_id"], []).append(link["ancestor_id"])
            else:
                superseded.add(link["ancestor_id"])
        entries: dict[str, MemoryEntry] = {}
        for row in rows:
            if deadline is not None and time.monotonic() >= deadline:
                raise MemoryDeadlineExceededError("local memory query exceeded its time bound")
            entries[row["id"]] = self._row_entry(
                row, depends_on=tuple(sorted(dependencies.get(row["id"], ())))
            )
        suppressed, _ = self._suppression_state(connection, scope, deadline)
        heads = [entry for entry_id, entry in entries.items()
                 if entry_id not in superseded and entry_id not in suppressed]
        current = tuple(sorted(heads, key=lambda item: (item.recorded_at, item.id)))
        return current, entries, suppressed

    @staticmethod
    def _obsolete_ancestors(
        entry: MemoryEntry,
        entries: dict[str, MemoryEntry],
        suppressed: set[str],
        *,
        include_interpretations: bool,
    ) -> tuple[MemoryEntry, ...]:
        ancestors: list[MemoryEntry] = []
        visited: set[str] = set()
        current_id = entry.supersedes_id
        while current_id is not None and current_id not in visited:
            visited.add(current_id)
            current = entries.get(current_id)
            if current is None:
                break
            if (current.id not in suppressed and
                    (include_interpretations or current.source is not MemorySource.INTERPRETATION)):
                ancestors.append(current)
            current_id = current.supersedes_id
        return tuple(ancestors)

    def recall(self, query: MemoryQuery) -> tuple[MemoryEntry, ...]:
        if not isinstance(query, MemoryQuery):
            raise ValueError("a typed MemoryQuery is required")
        connection = self._db()
        deadline = time.monotonic() + query.timeout_ms / 1_000
        connection.execute(f"PRAGMA busy_timeout={min(query.timeout_ms, 100)}")
        connection.set_progress_handler(lambda: int(time.monotonic() >= deadline), 500)
        try:
            connection.execute("BEGIN")
            try:
                candidates, entries, suppressed = self._snapshot(
                    connection, query.scope, deadline
                )
                connection.execute("COMMIT")
            except Exception:
                if connection.in_transaction:
                    connection.execute("ROLLBACK")
                raise
            query_text = " ".join(query.text.casefold().split())
            query_terms = _tokens(query.text)
            ranked: list[tuple[int, int, int, str, str, MemoryEntry]] = []
            for entry in candidates:
                if time.monotonic() >= deadline:
                    raise MemoryDeadlineExceededError("local memory query exceeded its time bound")
                if entry.source is MemorySource.INTERPRETATION and not query.include_interpretations:
                    continue
                versions = (entry,) + self._obsolete_ancestors(
                    entry, entries, suppressed,
                    include_interpretations=query.include_interpretations,
                )
                phrase = matched = 0
                for version in versions:
                    if time.monotonic() >= deadline:
                        raise MemoryDeadlineExceededError(
                            "local memory query exceeded its time bound"
                        )
                    normalized = " ".join(version.text.casefold().split())
                    version_phrase = int(bool(query_text) and query_text in normalized)
                    version_terms = _tokens(version.text)
                    version_matched = sum(
                        1 for term in query_terms
                        if term in version_terms or _cjk_term(term) and term in normalized
                    )
                    if (version_phrase, version_matched) > (phrase, matched):
                        phrase, matched = version_phrase, version_matched
                if not phrase and not matched:
                    continue
                source_rank = int(entry.source is MemorySource.INTERPRETATION)
                ranked.append((phrase, matched, source_rank,
                               _time_text(entry.recorded_at), entry.id, entry))
            ranked.sort(key=lambda row: (
                -row[0], -row[1], row[2], -_time_key(row[3]), row[4]
            ))
            results: list[MemoryEntry] = []
            chars = 0
            for _, _, _, _, _, entry in ranked:
                if time.monotonic() >= deadline:
                    raise MemoryDeadlineExceededError("local memory query exceeded its time bound")
                if len(results) >= query.limit:
                    break
                if chars + len(entry.text) > query.max_chars:
                    continue
                results.append(entry)
                chars += len(entry.text)
            return tuple(results)
        except sqlite3.OperationalError as exc:
            if time.monotonic() >= deadline or "interrupt" in str(exc).casefold():
                raise MemoryDeadlineExceededError("local memory query exceeded its time bound") from None
            raise MemoryStoreError("local memory query failed") from None
        except sqlite3.Error:
            raise MemoryStoreError("local memory query failed") from None
        finally:
            connection.set_progress_handler(None, 0)
            connection.execute("PRAGMA busy_timeout=100")

    def current_constraints(self, scope: MemoryScope) -> tuple[MemoryEntry, ...]:
        connection = self._db()
        connection.execute("BEGIN")
        try:
            boundaries = tuple(entry for entry in self._snapshot(connection, scope)[0]
                               if entry.kind is MemoryKind.BOUNDARY)
            connection.execute("COMMIT")
        except Exception:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        chars = sum(len(entry.text) for entry in boundaries)
        if len(boundaries) > _MAX_CURRENT_BOUNDARIES or chars > _MAX_CURRENT_BOUNDARY_CHARS:
            raise MemoryResultTooLargeError("effective boundary set exceeds its recall bound")
        return boundaries

    def forget(self, scope: MemoryScope, entry_id: str) -> MemoryMutation:
        connection = self._db()
        entry_id = str(entry_id)
        mutation = MemoryMutation(
            id=uuid4().hex,
            scope=scope,
            kind=MemoryMutationKind.FORGET,
            target_entry_id=entry_id,
            reverses_id=None,
            recorded_at=_time_text(None),
        )
        connection.execute("BEGIN IMMEDIATE")
        try:
            if self._get_entry(connection, scope, entry_id) is None:
                raise MemoryEntryNotFoundError("memory entry was not found in this scope")
            self._check_events_capacity(connection)
            self._insert_mutation(connection, mutation)
            connection.execute("COMMIT")
            return mutation
        except Exception:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise

    def undo_forget(self, scope: MemoryScope, forget_event_id: str) -> MemoryMutation:
        connection = self._db()
        forget_event_id = str(forget_event_id)
        connection.execute("BEGIN IMMEDIATE")
        try:
            row = connection.execute(
                """SELECT * FROM memory_mutations
                   WHERE id=? AND user_id=? AND character_id=? AND world_id=?""",
                (forget_event_id, *_scope_values(scope)),
            ).fetchone()
            if row is None:
                raise MemoryEntryNotFoundError("active forget event was not found in this scope")
            forget = self._row_mutation(row)
            if forget.kind is not MemoryMutationKind.FORGET:
                raise MemoryConflictError("only a forget event can be restored")
            if connection.execute(
                "SELECT 1 FROM memory_mutations WHERE reverses_id=?", (forget.id,)
            ).fetchone():
                raise MemoryConflictError("forget event has already been restored")
            self._check_events_capacity(connection)
            mutation = MemoryMutation(
                id=uuid4().hex,
                scope=scope,
                kind=MemoryMutationKind.RESTORE,
                target_entry_id=forget.target_entry_id,
                reverses_id=forget.id,
                recorded_at=_time_text(None),
            )
            self._insert_mutation(connection, mutation)
            connection.execute("COMMIT")
            return mutation
        except Exception:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise

    def _insert_mutation(self, connection: sqlite3.Connection, mutation: MemoryMutation) -> None:
        scope_values = _scope_values(mutation.scope)
        connection.execute(
            """INSERT INTO memory_mutations(
                 id,user_id,character_id,world_id,kind,target_entry_id,reverses_id,recorded_at)
               VALUES(?,?,?,?,?,?,?,?)""",
            (mutation.id, *scope_values, mutation.kind.value, mutation.target_entry_id,
             mutation.reverses_id, _time_text(mutation.recorded_at)),
        )
        connection.execute(
            """INSERT INTO memory_history(event_id,user_id,character_id,world_id,event_kind,recorded_at)
               VALUES(?,?,?,?,?,?)""",
            (mutation.id, *scope_values, mutation.kind.value, _time_text(mutation.recorded_at)),
        )

    def history(
        self, scope: MemoryScope, entry_id: str | None = None, limit: int = 100
    ) -> tuple[MemoryHistoryItem, ...]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1_000:
            raise ValueError("history limit must be an integer between 1 and 1000")
        connection = self._db()
        connection.execute("BEGIN")
        try:
            scope_values = _scope_values(scope)
            history_rows = connection.execute(
                """SELECT event_id,event_kind FROM memory_history
                   WHERE user_id=? AND character_id=? AND world_id=? ORDER BY seq""",
                scope_values,
            ).fetchall()
            if entry_id is None:
                rows = history_rows[:limit]
            else:
                requested_id = str(entry_id)
                entry = self._get_entry(connection, scope, requested_id)
                mutation = connection.execute(
                    """SELECT * FROM memory_mutations
                       WHERE id=? AND user_id=? AND character_id=? AND world_id=?""",
                    (requested_id, *scope_values),
                ).fetchone()
                target_id = entry.id if entry is not None else (
                    mutation["target_entry_id"] if mutation is not None else None
                )
                if target_id is None:
                    rows = []
                else:
                    links = connection.execute(
                        """SELECT memory_id,ancestor_id FROM memory_links
                           WHERE user_id=? AND character_id=? AND world_id=?
                             AND relation='supersedes'""",
                        scope_values,
                    ).fetchall()
                    adjacent: dict[str, set[str]] = {}
                    for child_id, ancestor_id in links:
                        adjacent.setdefault(child_id, set()).add(ancestor_id)
                        adjacent.setdefault(ancestor_id, set()).add(child_id)
                    lineage = {target_id}
                    pending = [target_id]
                    while pending:
                        current = pending.pop()
                        for neighbour in adjacent.get(current, ()):
                            if neighbour not in lineage:
                                lineage.add(neighbour)
                                pending.append(neighbour)
                    mutation_targets = {
                        row[0] for row in connection.execute(
                            """SELECT id,target_entry_id FROM memory_mutations
                               WHERE user_id=? AND character_id=? AND world_id=?""",
                            scope_values,
                        ) if row[1] in lineage
                    }
                    if mutation is not None:
                        mutation_targets.add(requested_id)
                    related_ids = lineage | mutation_targets
                    rows = [row for row in history_rows if row[0] in related_ids]
                    if len(rows) > limit:
                        raise MemoryResultTooLargeError(
                            "correction history exceeds its configured result bound"
                        )
            items: list[MemoryHistoryItem] = []
            for event_id, event_kind in rows:
                if event_kind == "entry":
                    row = connection.execute(
                        """SELECT * FROM memory_entries WHERE id=? AND user_id=?
                           AND character_id=? AND world_id=?""",
                        (event_id, *scope_values),
                    ).fetchone()
                    if row is not None:
                        items.append(self._row_entry(row))
                else:
                    row = connection.execute(
                        """SELECT * FROM memory_mutations WHERE id=? AND user_id=?
                           AND character_id=? AND world_id=?""",
                        (event_id, *scope_values),
                    ).fetchone()
                    if row is not None:
                        items.append(self._row_mutation(row))
            connection.execute("COMMIT")
            return tuple(items)
        except Exception:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise

    def _row_entry(
        self, row: sqlite3.Row, *, depends_on: tuple[str, ...] | None = None
    ) -> MemoryEntry:
        scope = MemoryScope(row["user_id"], row["character_id"], row["world_id"])
        supersedes_id = row["supersedes_id"]
        if depends_on is None:
            if self._connection is None:
                depends_on = ()
            else:
                depends_on = tuple(
                link[0] for link in self._connection.execute(
                    """SELECT ancestor_id FROM memory_links
                       WHERE memory_id=? AND relation='depends_on' ORDER BY ancestor_id""",
                    (row["id"],),
                )
                )
        return MemoryEntry(
            id=row["id"], scope=scope, source=MemorySource(row["source"]),
            text=row["text"], source_event_id=row["source_event_id"],
            source_version=int(row["source_version"]), recorded_at=_parse_time(row["recorded_at"]),
            supersedes_id=supersedes_id, depends_on=depends_on,
            kind=MemoryKind(row["kind"]),
        )

    @staticmethod
    def _row_mutation(row: sqlite3.Row) -> MemoryMutation:
        return MemoryMutation(
            id=row["id"],
            scope=MemoryScope(row["user_id"], row["character_id"], row["world_id"]),
            kind=MemoryMutationKind(row["kind"]), target_entry_id=row["target_entry_id"],
            reverses_id=row["reverses_id"], recorded_at=_parse_time(row["recorded_at"]),
        )

def _time_key(value: str) -> float:
    return datetime.fromisoformat(value).timestamp()
