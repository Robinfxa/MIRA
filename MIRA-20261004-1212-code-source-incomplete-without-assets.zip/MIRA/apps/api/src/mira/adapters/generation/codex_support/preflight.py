"""Strict metadata-only Codex setup handshake; never starts a thread or model turn."""
from __future__ import annotations

import asyncio
import hashlib
import re
from dataclasses import dataclass

from .payload import canonical, strict_json
from .process import StdioProcessTransport
from .protocol import _verify_config
from .types import CodexGenerationError, CodexLimits, CodexRuntime, PINNED_VERSION

_VERSION = PINNED_VERSION
_REQUESTS = (("initialize", {"clientInfo": {"name": "mira_metadata_setup", "version": "1.0"},
                              "capabilities": {"experimentalApi": True}}),
             ("config/read", {"includeLayers": False}))
_RESULT_FIELDS = frozenset(("jsonrpc", "id", "result"))
_UNSAFE_CONFIG_KEYS = frozenset((
    "api_key", "apikey", "openai_api_key", "openaiapikey", "access_token",
    "refresh_token", "authorization", "auth_headers", "headers", "credentials",
    "client_secret", "developer_instructions", "custom_instructions", "instructions_file",
))


@dataclass(frozen=True, slots=True)
class MetadataDeclaration:
    """Non-secret fingerprints describing observed setup metadata, not readiness."""

    executable_sha256: str
    config_sha256: str
    environment_sha256: str
    codex_version: str = _VERSION
    route_kind: str = "public"


class MetadataOnlyTransport:
    """Enforce the exact setup RPC sequence before sending anything to the process."""

    def __init__(self, transport: StdioProcessTransport, runtime: CodexRuntime):
        self._transport = transport
        self._runtime = runtime
        self._closed = False

    async def _response(self, request_id: int) -> dict:
        raw = await self._transport.receive()
        message = strict_json(raw)
        if type(message) is not dict or set(message) - _RESULT_FIELDS:
            raise CodexGenerationError("codex_preflight_rpc_forbidden")
        if (message.get("jsonrpc", "2.0") != "2.0"
                or type(message.get("id")) is not int or message["id"] != request_id):
            raise CodexGenerationError("codex_preflight_rpc_invalid")
        if "result" not in message or type(message["result"]) is not dict:
            raise CodexGenerationError("codex_preflight_rpc_invalid")
        return message["result"]

    async def _request(self, request_id: int, method: str, params: dict) -> dict:
        if (request_id, method, params) not in ((1, _REQUESTS[0][0], _REQUESTS[0][1]),
                                               (2, _REQUESTS[1][0], _REQUESTS[1][1])):
            raise CodexGenerationError("codex_preflight_rpc_forbidden")
        await self._transport.send({"id": request_id, "method": method, "params": params})
        return await self._response(request_id)

    async def observe(self, timeout_seconds: float) -> MetadataDeclaration:
        if type(timeout_seconds) not in (int, float) or not 0 < timeout_seconds <= 30:
            raise CodexGenerationError("codex_preflight_timeout_invalid")
        if self._runtime.development_context is not None:
            raise CodexGenerationError("codex_preflight_route_unsupported")
        try:
            async with asyncio.timeout(timeout_seconds):
                initialized = await self._request(1, *_REQUESTS[0])
                if (set(initialized) - {"userAgent", "codexHome", "platformFamily", "platformOs"}
                        or initialized.get("codexHome") != str(self._runtime.codex_home)
                        or type(initialized.get("userAgent")) is not str
                        or not re.search(
                            rf"(?:^|/){re.escape(_VERSION)}(?:\s|\(|$)",
                            initialized["userAgent"],
                        )
                        or initialized.get("platformFamily") != self._runtime.platform_family
                        or initialized.get("platformOs") != self._runtime.platform_os):
                    raise CodexGenerationError("codex_preflight_profile_drift")
                await self._transport.send({"method": "initialized"})
                config_result = await self._request(2, *_REQUESTS[1])
                if set(config_result) - {"config", "origins", "layers"}:
                    raise CodexGenerationError("codex_preflight_profile_drift")
                if (type(config_result.get("origins", {})) is not dict
                        or config_result.get("layers") is not None
                        and type(config_result["layers"]) not in (dict, list)):
                    raise CodexGenerationError("codex_preflight_profile_drift")
                config = config_result.get("config")
                if type(config) is not dict:
                    raise CodexGenerationError("codex_preflight_profile_drift")
                _reject_unsafe_config_keys(config)
                _verify_config(config_result, self._runtime)
                config_digest = hashlib.sha256(canonical(config)).hexdigest()
                del config_result, config, initialized
                return MetadataDeclaration(
                    executable_sha256=self._runtime.executable_sha256,
                    config_sha256=config_digest,
                    environment_sha256=hashlib.sha256(
                        canonical(dict(self._runtime.environment))).hexdigest(),
                )
        except TimeoutError:
            raise CodexGenerationError("codex_preflight_timeout") from None
        except (TypeError, ValueError, RecursionError, UnicodeError):
            raise CodexGenerationError("codex_preflight_profile_drift") from None
        finally:
            await self.close()

    async def close(self) -> None:
        if not self._closed:
            self._closed = True
            await self._transport.close()


async def observe_public_metadata(runtime: CodexRuntime, *, timeout_seconds: float = 10.0,
                                  limits: CodexLimits | None = None) -> MetadataDeclaration:
    """Run the bounded public-route handshake and always reap its native child."""
    if runtime.development_context is not None:
        raise CodexGenerationError("codex_preflight_route_unsupported")
    from .process import open_stdio_preflight

    transport = await open_stdio_preflight(runtime, limits or CodexLimits(
        startup_seconds=timeout_seconds, turn_seconds=timeout_seconds))
    return await MetadataOnlyTransport(transport, runtime).observe(timeout_seconds)


def _reject_unsafe_config_keys(value: object) -> None:
    """Fail closed on credential-bearing or instruction injection config fields."""
    if type(value) is dict:
        for key, child in value.items():
            normalized = key.lower().replace("-", "_") if type(key) is str else ""
            if normalized in _UNSAFE_CONFIG_KEYS:
                raise CodexGenerationError("codex_preflight_profile_drift")
            _reject_unsafe_config_keys(child)
    elif type(value) is list:
        for child in value:
            _reject_unsafe_config_keys(child)
