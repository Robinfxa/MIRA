import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import vm from 'node:vm';
const dist=process.env.MIRA_TEST_WEB_DIST?resolve(process.env.MIRA_TEST_WEB_DIST):resolve('apps/web/dist');
const source=(await readFile(resolve(dist,'app/main.js'),'utf8')).replace(/^import .*;\n/gm,'');
const markup=await readFile(new URL('../../apps/web/index.html',import.meta.url),'utf8');
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function deferred(){let resolve;const promise=new Promise(done=>{resolve=done;});return {promise,resolve};}
function app(){const calls=[],inputs=[];let inputResult=Promise.resolve({status:'submitted'}),captureFinishResult=Promise.resolve(undefined);const nodes=new Map();class Node {listeners={};disabled=false;hidden=false;checked=false;dataset={};value='';textContent='';addEventListener(name,fn){(this.listeners[name]??=[]).push(fn);}fire(name,patch={}){const e={defaultPrevented:false,preventDefault(){this.defaultPrevented=true;},button:0,pointerId:1,...patch};for(const fn of this.listeners[name]??[])fn(e);return e;}setAttribute(name,value){this[name]=value;}setPointerCapture(){}releasePointerCapture(){}hasPointerCapture(){return true;}}
for(const selector of ['[data-status]','[data-diagnostic]','[data-error]','[data-system-notice]','[data-system-notice-body]','[data-stage]','fieldset','form','[name=message]','[data-stop]','[data-close]','[data-ptt]','[data-voice-hint]','[data-mode-label]','[data-mode-description]','[data-recording-notice]','[data-review-audio-notice]','[data-review-audio-status]','[data-review-audio-scope]','[data-review-audio-eligibility]','[data-review-audio-consent]','[data-review-audio-enable]','[data-review-audio-disable]','[data-review-audio-review]','[data-review-audio-clip]','[data-review-audio-clip-metadata]','[data-review-audio-preview]','[data-review-audio-audition]','[data-review-audio-audition-status]','[data-review-audio-attestation]','[data-review-audio-confirm]','[data-review-audio-cancel]','[data-review-audio-result]','[data-rehearsal-banner]','[data-rehearsal-controls]','[data-rehearsal-input]','[data-rehearsal-hint]'])nodes.set(selector,new Node());
const window=new Node();const document={querySelector:s=>nodes.get(s),querySelectorAll:()=>[],visibilityState:'visible',addEventListener:()=>{}};let view;
class ReviewedAudioPanel {constructor(_api,_controller,_elements){this.calls=calls;}start(){this.calls.push('review-start');}setCanEnable(_value){this.calls.push('review-enable-allowed');}invalidateForNewInput(){this.calls.push('review-new-input');}invalidateForStop(){this.calls.push('review-stop');}inputSettled(){this.calls.push('review-settled');}close(){this.calls.push('review-close');}auditionState(_state){this.calls.push('review-audition');}}
class SessionController {constructor(_api,_effects,v){view=v;}connect(){calls.push('connect');view.connected();return Promise.resolve();}input(text){calls.push('input');inputs.push(text);return inputResult;}stop(){calls.push('stop');return Promise.resolve();}close(){calls.push('close');return Promise.resolve();}startMicrophone(){calls.push('start');return Promise.resolve();}finishMicrophone(){calls.push('finish');return captureFinishResult;}startRehearsalInput(){calls.push('rehearsal-start');return Promise.resolve();}finishRehearsalInput(){calls.push('rehearsal-finish');return captureFinishResult;}}
vm.runInNewContext(source,{document,window,globalThis:{AudioContext:class{},AudioWorkletNode:class{},isSecureContext:true},navigator:{mediaDevices:{getUserMedia(){}}},isSecureContext:true,loadPublicConfig:()=>({}),watchDiagnosticsStatus:()=>({close(){}}),recordingNotice:()=>({visible:false,text:"",state:"off"}),safeSessionError:()=>"safe error",MiraApiClient:class{},SessionController,ReviewedAudioPanel,DomEffectExecutor:class{constructor(){calls.push('dom');}},SceneEffectExecutor:class{constructor(){calls.push('scene');}}});
return {nodes,calls,inputs,view,window,setInputResult(value){inputResult=value;},setCaptureFinishResult(value){captureFinishResult=value;}};}
test('composition selects scene executor and labels actual backend capability',()=>{const h=app();assert.equal(h.calls.includes('scene'),true);assert.equal(h.calls.includes('dom'),false);h.view.capabilities({generation_mode:'replay',speech_enabled:false,microphone_enabled:false,qualification:'unavailable'});assert.match(h.nodes.get('[data-mode-label]').textContent,/Fixture/);assert.equal(h.nodes.get('[data-ptt]').disabled,true);});
test('PTT pointer and keyboard gestures start once and release once, cancellation stops',()=>{const h=app(),ptt=h.nodes.get('[data-ptt]');h.view.capabilities({generation_mode:'injected',speech_enabled:true,microphone_enabled:true,qualification:'injected_unverified'});ptt.fire('pointerdown');ptt.fire('pointerdown');ptt.fire('pointerup');assert.deepEqual(h.calls.filter(x=>['start','finish'].includes(x)),['start','finish']);ptt.fire('keydown',{key:' ',repeat:false});ptt.fire('keydown',{key:' ',repeat:true});ptt.fire('keyup',{key:' '});assert.equal(h.calls.filter(x=>x==='start').length,2);assert.equal(h.calls.filter(x=>x==='finish').length,2);ptt.fire('pointerdown');ptt.fire('pointercancel');assert.equal(h.calls.at(-1),'stop');});
test('empty text submission cannot orphan a held microphone gesture',()=>{const h=app(),ptt=h.nodes.get('[data-ptt]');h.view.capabilities({generation_mode:'injected',speech_enabled:true,microphone_enabled:true,qualification:'injected_unverified'});ptt.fire('pointerdown');h.nodes.get('[name=message]').value='   ';h.nodes.get('form').fire('submit');ptt.fire('pointerup');assert.equal(h.calls.filter(x=>x==='input').length,0);assert.equal(h.calls.filter(x=>x==='finish').length,1);});

test('an input blocked before dispatch restores the exact text only while the field is still empty',async()=>{const h=app(),field=h.nodes.get('[name=message]'),pending=deferred(),text='keep this exact phrasing';h.setInputResult(pending.promise);field.value=text;h.nodes.get('form').fire('submit');assert.equal(field.value,'');assert.deepEqual(h.inputs,[text]);pending.resolve({status:'not-sent',text,reason:'history-timeout'});await tick();assert.equal(field.value,text);});

test('a blocked older submission never overwrites newer typing or a newer submitted input',async()=>{const h=app(),field=h.nodes.get('[name=message]'),older=deferred();h.setInputResult(older.promise);field.value='older';h.nodes.get('form').fire('submit');field.value='newer draft';field.fire('input');older.resolve({status:'not-sent',text:'older',reason:'history-failed'});await tick();assert.equal(field.value,'newer draft');});

test('an older blocked outcome does not repopulate an empty field after a newer request was submitted',async()=>{const h=app(),field=h.nodes.get('[name=message]'),older=deferred();h.setInputResult(older.promise);field.value='older';h.nodes.get('form').fire('submit');field.value='newer';field.fire('input');h.setInputResult(Promise.resolve({status:'submitted'}));h.nodes.get('form').fire('submit');assert.equal(field.value,'');older.resolve({status:'not-sent',text:'older',reason:'history-timeout'});await tick();assert.equal(field.value,'');});

test('a microphone final withheld by history failure is restored only if no newer text was entered',async()=>{const h=app(),field=h.nodes.get('[name=message]'),pending=deferred(),ptt=h.nodes.get('[data-ptt]');h.view.capabilities({generation_mode:'injected',speech_enabled:true,microphone_enabled:true,qualification:'injected_unverified'});h.setCaptureFinishResult(pending.promise);ptt.fire('pointerdown');ptt.fire('pointerup');pending.resolve({status:'not-sent',text:'final recognized words',reason:'history-failed'});await tick();assert.equal(field.value,'final recognized words');});

test('explicit rehearsal shows honest banner, microphone off and synthetic hold input controls',()=>{const h=app();h.view.capabilities({generation_mode:'rehearsal',speech_enabled:true,microphone_enabled:false,qualification:'offline_fixture'});assert.equal(h.nodes.get('[data-rehearsal-banner]').hidden,false);assert.match(h.nodes.get('[data-mode-description]').textContent,/英文.*合成/);assert.equal(h.nodes.get('[data-ptt]').disabled,true);const button=h.nodes.get('[data-rehearsal-input]');button.fire('pointerdown');button.fire('pointerdown');button.fire('pointerup');assert.deepEqual(h.calls.filter(x=>x.startsWith('rehearsal')),['rehearsal-start','rehearsal-finish']);assert.equal(h.calls.includes('start'),false);button.fire('keydown',{key:' ',repeat:false});button.fire('keyup',{key:' '});assert.equal(h.calls.filter(x=>x==='rehearsal-finish').length,2);button.fire('pointerdown');h.window.fire('blur');assert.equal(h.calls.at(-1),'stop');button.fire('pointerup');assert.equal(h.calls.filter(x=>x==='rehearsal-finish').length,2);});


test('IME confirmation Enter and repeated events are intercepted; legacy 229 is covered',()=>{
 const h=app(),field=h.nodes.get('[name=message]');
 field.value='合成中的消息';
 const first=field.fire('keydown',{key:'Enter',code:'Enter',keyCode:13,isComposing:true,repeat:false});
 const repeated=field.fire('keydown',{key:'Enter',code:'Enter',keyCode:13,isComposing:true,repeat:true});
 const legacy=field.fire('keydown',{key:'Enter',code:'Enter',keyCode:229,isComposing:false,repeat:false});
 assert.equal(first.defaultPrevented,true,'IME confirmation must not trigger implicit submission');
 assert.equal(repeated.defaultPrevented,true,'repeated composition Enter must also be canceled');
 assert.equal(legacy.defaultPrevented,true,'legacy IME keyCode 229 must be canceled');
 assert.deepEqual(h.inputs,[],'composition text must not reach the controller');
});

test('composition state guards Enter until compositionend, then ordinary Enter still submits exact Chinese text',()=>{
 const h=app(),field=h.nodes.get('[name=message]'),form=h.nodes.get('form');
 field.value='明天去哪里？'; field.fire('compositionstart');
 const during=field.fire('keydown',{key:'Enter',code:'Enter',keyCode:13,isComposing:false,repeat:false});
 assert.equal(during.defaultPrevented,true,'composition event state protects platforms with incomplete key flags');
 assert.deepEqual(h.inputs,[]);
 field.fire('compositionend');
 const ordinary=field.fire('keydown',{key:'Enter',code:'Enter',keyCode:13,isComposing:false,repeat:false});
 assert.equal(ordinary.defaultPrevented,false,'ordinary Enter retains the current native submit behavior');
 form.fire('submit');
 assert.deepEqual(h.inputs,['明天去哪里？']);
});

test('Stop then newer text submission preserves the newer draft when an older blocked result settles',async()=>{
 const h=app(),field=h.nodes.get('[name=message]'),form=h.nodes.get('form'),older=deferred();
 h.setInputResult(older.promise); field.value='旧的输入'; form.fire('submit');
 h.nodes.get('[data-stop]').fire('click');
 field.value='新的输入'; field.fire('input');
 h.setInputResult(Promise.resolve({status:'submitted'})); form.fire('submit');
 older.resolve({status:'not-sent',text:'旧的输入',reason:'history-failed'}); await tick();
 assert.deepEqual(h.calls.filter(x=>x==='input'||x==='stop'),['input','stop','input']);
 assert.deepEqual(h.inputs,['旧的输入','新的输入']); assert.equal(field.value,'');
});

test('direct form submission still sends text without depending on the Enter key path',()=>{
 const h=app(),field=h.nodes.get('[name=message]'),form=h.nodes.get('form');
 field.value='按钮发送'; form.fire('submit');
 assert.deepEqual(h.inputs,['按钮发送']);
});

test('semantic uncertainty uses the dedicated status region and never the generic error alert',()=>{
 const h=app(),region=h.nodes.get('[data-system-notice]'),body=h.nodes.get('[data-system-notice-body]');
 h.view.systemNotice({label:'系统提示',body:'这部分我还不确定，先跳过。你可以补充说明，或继续聊。'});
 assert.equal(region.hidden,false); assert.equal(body.textContent,'这部分我还不确定，先跳过。你可以补充说明，或继续聊。');
 h.view.update({phase:'error',revision:2,activity_seq:1,output_epoch:1,permit_revision:2,active_grants:[],presented_effects:[],audio_progress:[],sealed:true,last_error:'review_uncertain'});
 assert.equal(h.nodes.get('[data-error]').textContent,'','The nonfatal review fallback must not populate the alert surface');
 h.view.systemNotice(null);
 assert.equal(region.hidden,true); assert.equal(body.textContent,'');
 assert.match(markup,/<aside class="system-notice" data-system-notice role="status" aria-live="polite" aria-atomic="true" hidden>/);
 assert.match(markup,/<strong>系统提示<\/strong>/);
 assert.match(markup,/<p data-system-notice-body><\/p>/);
});
